'''
ConvertOldAssignsToNew.py
 
Convert old (0.1 beta) style assignments directory to the new hdf5 
format used in MSMBuilder 1.0.

Please reference
Bowman GR, Huang X, Pande VS. Using generalized ensemble simulations and Markov state 
models to identify conformational states. Methods 2009;49:197-201.
 
Written by Gregory R. Bowman
Biophysics Program, Stanford University
Pande Group
12/01/09

Copyright (C) 2009  Stanford University

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

TODO:

CHANGE LOG:

'''

# global imports
import os
import os.path
import sys
from numpy import *
from optparse import OptionParser
from tables import *

# local imports
#import License

availableFormats = ["lzo", "zlib", "bzip2", None]

def run(assignments, dt, oldDir, compression):
  # find maximum length of any trajectory
  maxLen = 0
  nFiles = 0
  nMicro = 0
  for assignFn in os.listdir(oldDir):
    assignFn = os.path.join(oldDir, assignFn)
    try: 
      a = loadtxt(assignFn, dtype=int)
    except IOError: # add exception in case there are directories (.svn) in assignments directory
      continue
    aLen = len(a)
    if aLen > maxLen:
      maxLen = aLen
    maxStateInd = a.max()
    if maxStateInd > nMicro:
      nMicro = maxStateInd
    nFiles += 1
  nMicro += 1 # account for fact numbering of states starts at 0
    
  # setup filter to handle compression
  filters = None
  if compression != None:
    compression = compression.lower()
    if compression not in availableFormats:
      print "ERROR: compression format must be one of: ", availableFormats
      return
    filters = Filters(complevel=9, complib=compression)

    # make sure compression format specified in file name
    if compression not in assignments.lower():
      print "Adding compression format to assignments file name."
      assignments += ".%s" % compression
      print "New file name is %s." % assignments
    
  # create hdf5 file
  f = openFile(assignments, mode='w')
  f.createGroup("/", "data")
  assigns = f.createCArray("/data", "assignments", Int32Atom(dflt=-1), (nFiles, maxLen), filters=filters)
  assigns.attrs.dt = dt
  assigns.attrs.nMicro = nMicro
  lens = f.createCArray("/data", "lengths", Int32Atom(), (nFiles,), filters=filters)
  names = f.createCArray("/data", "names", StringAtom(256), (nFiles,), filters=filters)
  i = 0
  for assignFn in os.listdir(oldDir):
    try:
      a = loadtxt(os.path.join(oldDir, assignFn), dtype=int)
    except IOError:
      continue
    lens[i] = a.shape[0]
    names[i] = assignFn
  
    # store just first column (microstate assignments)
    if len(a.shape) == 1:
      assigns[i,0:lens[i]] = a[:]
    else:
      assigns[i,0:lens[i]] = a[:,0]
  
    i += 1
  
  f.flush()
  f.close()

if __name__ == "__main__":
  # setup option parser
  usage = "%prog [options]"
  parser = OptionParser(usage=usage)
  parser.add_option("-a", "--assignments", dest="assignments", action="store", 
                    type="string", default="assignments.h5", 
                    help="File name to write hdf5 assignments to. [default: assignments.h5]")
  parser.add_option("-d", "--dt", dest="dt", action="store", 
                    type="float", default=None, 
                    help="(required) Time that elapses (in ps) for each step in the assignments.")
  parser.add_option("-o", "--oldDir", dest="oldDir", action="store", 
                    type="string", default="assignments", 
                    help="Old assignments directory. [default: assignments/]")
  parser.add_option("-z", "--compression", dest="compression", action="store", 
                    type="string", default=None, 
                    help="Compression format to use for new assignments file. Can be one of: %s. [default: None]" % availableFormats)

  # parse option
  #License.printLicense()
  (options, args) = parser.parse_args()
  print sys.argv
  
  run(options.assignments, options.dt, options.oldDir, options.compression)
  
