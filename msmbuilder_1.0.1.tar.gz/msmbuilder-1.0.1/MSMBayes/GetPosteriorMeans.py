# GetPosteriorMeans.py 
# 
# Computes the posterior means of the specified functions of the transition 
# matrix of an MSM. The method is fully described in,
#
# "Bayesian comparison of Markov models of molecular dynamics with detailed balance 
# constraint" by S. Bacallado, J. Chodera, and V. Pande.
#
# Copyright (C) 2010 Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# Written by Sergio Bacallado, February 2010.

# Global imports
import os
from optparse import OptionParser
from multiprocessing import Pool

# Local imports
from MSMBayes import *
import MSMBayes
import license

# define options
usage = "%prog [options]"
parser = OptionParser(usage=usage)
# lag time to use
parser.add_option("-l", "--lag_time", dest="lagTime", action="store", type="int", default=1, help="Lag time in number of snapshots between observations. [default: 1]")
# assignments file
parser.add_option("-a", "--assignFn", dest="assignFn", action="store", type="string", default="noInput", help="Assignment file (HDF5 format) to be used as a dataset.")
# microstate to macrostate mapping file
parser.add_option("-m", "--mapMicroToMacro", dest="mapMicroToMacroFn", action="store", type="string", default="noInput", help="This is a single-column file mapping from microstates to macrostates.")
# prior counts for transition matrix prior
parser.add_option("-p", "--prior_tCount", dest="priorTransCount", action="store", type="float", default=-1, help="The analysis uses a prior for the transition matrix that is parametrized by a pseudo-count for each possible transition between two states. We recommend choosing an appropriate number of total pseudo-counts that is comparable to the number of transitions in the data. Then, divide the total prior pseudo-counts by the number of macrostates squared, to obtain a reasonable prior pseudo-count per transition [default: 1/number of macrostates]")
# initial state for transition matrix prior
parser.add_option("-i", "--initial_state", dest="initialState", action="store", type="int", default=0, help="The prior for the transition matrix is also parametrized by an 'initial state'. We recommend choosing a macrostate with high frequency or stationary probability [default:  0]")
# prior counts for microstate selection prior
parser.add_option("-c", "--prior_microCount", dest="priorMicroCount", action="store", type="float", default=0.5, help="A dirichlet prior is used for the stationary distribution of microstates within each macrostate. This parameter sets the prior pseudo-counts. By default, this is set to the Jeffreys prior. [default: 0.5]")
# number of samples for Monte Carlo integration
parser.add_option("-n", "--num_samples", dest="numSamples", action="store", type="int", default=0, help="The posterior means are obtained from a Monte Carlo algorithm that requires sampling a reinforced random walk. This parameter sets the number of new samples to be computed by the script. By default, we do not compute new samples and look for previously obtained samples in  '--sample_dir' [default: 0].")
# directory containing samples to be used in Monte Carlo integration
parser.add_option("-d", "--sample_dir", dest="sampleDir", action="store", type="string", default="noInput", help="Directory where we store samples of the reinforced random walk. The script may compute a number of new samples, but it ultimately uses all the samples in the directory.")
# number of parallel processes used in sampling reinforced RW for Monte Carlo integration
parser.add_option("-w", "--num_workers", dest="numWorkers", action="store", type="int", default=8, help="The reinforced random walk samples are obtained in parallel. This parameter sets the number of processes to be spawned [default: 8]")
# store whole transition matrix sample?
parser.add_option("-s", "--store_samples", dest="storeSamples", action="store_true", default=False, help="If this flag is set, the full transition matrix samples are stored, else only the specified functions are stored.")
# functions
parser.add_option("-f", "--functions",dest="functions", action="append", type="str", help="Specify a function defined in MSMBayes.py whose mean you want to compute (one at a time).")
# output file
parser.add_option("-o", "--output_file", dest="outputFn", action="store", type="string", default="function_means.pkl", help="Name of the output file (cPickled dictionary) [default: function_means.pkl]")


# parse option
(options, args) = parser.parse_args()

# define script inside a function
def function(options):
	"""Outputs a cPickled file with keys = function names, and values = means."""
	
	license.printLicense()
	
	if options.assignFn == "noInput" or options.sampleDir =="noInput":
		raise IOError("Missing an assignment file or sample directory.")
	if options.functions ==[]:
		raise IOError("No functions specified.")
	# Rewrite functions as function type objects
	functions = []
	for function in options.functions:
		functions.append(getattr(MSMBayes,function))
	
	# read in data
	microData = MicroData(1,1)
	microData.ReadData(options.assignFn,options.lagTime,options.mapMicroToMacroFn)

	# if prior pseudo-counts for transition matrix are not set, make them the default
	if options.priorTransCount == -1:
		options.priorTransCount = 1.0/microData.numStates

	# define initial graph weights for sampling reinforced random walk
	gw = GraphWeights(microData.numStates)
	gw.updateWithData(microData)

	# sample reinforced random walks and store specified functions
	if options.numSamples > 0:
		p = Pool(options.numWorkers)
	nStoredSamples = len(os.listdir(options.sampleDir))
	inputs = []
	randomSeeds = permutation(xrange(options.numSamples*10))
	for i in range(options.numSamples):
		inputs.append([gw,options.priorTransCount,options.initialState,\
			functions,options.sampleDir+'/Sample_'+str(i+nStoredSamples),\
			options.storeSamples, randomSeeds[i]])
	if options.numSamples > 0:
		p.map(SampleReinforcedRW,inputs)

	# obtain final list of filenames
	sampleFiles = os.listdir(options.sampleDir)
	for i,sampleFn in enumerate(sampleFiles):
		sampleFiles[i] = options.sampleDir+'/'+sampleFn

	# sample from the posterior
	posteriorMeans = PosteriorMeans(microData,sampleFiles,\
				options.initialState,functions)

	# write output	
	outFile = open(options.outputFn,'w')
	cPickle.dump(posteriorMeans,outFile)
	outFile.close()

# call function
function(options)



