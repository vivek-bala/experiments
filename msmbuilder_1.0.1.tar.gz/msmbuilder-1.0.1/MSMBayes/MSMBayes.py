# MSM Bayes module
#
# Implements Bayesian analysis of reversible Markov  models, using the conjugate
# prior described in:
#
# [1] "Bayesian analysis for reversible Markov chains"
# by S. Rolles, and P. Diaconis.
# 
# The module has functions to compare lumpings on the same microstate basis, as well
# as to perform Bayesian inference of the transition probability matrix and functions
# thereof. More information on these methods, and details on the numerical computations 
# performed by this module can be found in this paper, which we ask that you cite:
#
# [2] "Bayesian comparison of Markov models of molecular dynamics with detailed
# balance contraint"
# by S. Bacallado, J. Chodera, and V. Pande.
#
# Copyright (C) 2010 Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# Written on 1/26/10 by Sergio A. Bacallado.
#
#============================================================
# To do:
# 
#============================================================
# Change log:
#
#============================================================

# Global imports
from scipy import sparse
from scipy import special
import scipy.sparse.linalg.eigen
from numpy import *
from numpy.random import *
from tables import *
import numpy.linalg
import warnings
import cPickle
warnings.simplefilter("ignore",DeprecationWarning)

# Local imports


class Data:
	"""This class represents a dataset of transition counts for a Markov model
	and does not contain any information regarding microstates. It could be useful
	at some point if the data are being read from macrostate assignments. However, 
	the ReadData function is not currently implemented."""

	def __init__(self,numStates):
		self.numStates = numStates
		self.tCounts = []
		self.endStates = []	

	def ReadData(self):
		pass

class MicroData(Data):
	"""This class represents a dataset read from an MSMBuilder HDF5 assignment file.
	It stores transitions between macrostates, as well as the number of times
	each microstate occurs."""

	def __init__(self,numStates,numMicroStates):
		self.numStates = numStates
		self.tCounts = []
		self.endStates = []	
		self.mapMicroToMacro = array([])
		self.numMicroStates = numMicroStates
		self.microCounts = zeros(numMicroStates)

	def ReadData(self,filename,lagTime,mapMicroToMacroFilename):
		"""Reads data from an HDF5 assignment file. The trajectories are
		subsampled at the specified lag time.

		Input:
		'filename' (str) the name of the assignment file.
		'lagTime' (int) an integer which multiplied times the snapshot
		inteval (dt) gives the lag time of the model.
		'mapMicroToMacroFilename' (str) the name of a text file containing
		the mapping from microstates to macrostates. The n-th line in the
		file contains the macrostate assigned to microstate n-1."""

		file = openFile(filename, mode='r')
		# Adjust number of microstates if necessary
		self.numMicroStates = file.root.data.assignments.attrs.nMicro
		self.microCounts = zeros(self.numMicroStates)
		# Store time intervals
		self.dt = file.root.data.assignments.attrs.dt
		self.lagTime = lagTime
		# Read microstate to macrostate mapping
		mapFile = open(mapMicroToMacroFilename,'r')
		self.mapMicroToMacro =[]
		for line in mapFile:
			self.mapMicroToMacro.append(int(line.strip()))
		self.mapMicroToMacro = array(self.mapMicroToMacro)
		mapFile.close()
		# Adjust number of macrostates if necessary
		self.numStates = int(max(self.mapMicroToMacro)+1)
		# Read in data, subsampling at the lagTime
		assignments = file.root.data.assignments[:]
		trajLengths = file.root.data.lengths.read()
		for traj in range(len(trajLengths)):
			tCounts = sparse.lil_matrix((self.numStates,self.numStates))
			currTime = 0
			firstState = self.mapMicroToMacro[currTime]
			while currTime + self.lagTime <= trajLengths[traj]-1:
				oldTime = currTime
				currTime += self.lagTime
				oldState = self.mapMicroToMacro[assignments[traj,oldTime]]
				currState = self.mapMicroToMacro[assignments[traj,currTime]]
				tCounts[oldState,currState] += 1 
				self.microCounts[assignments[traj,currTime]] += 1
			self.tCounts.append(tCounts)
			self.endStates.append([firstState,currState])
		self.endStates = array(self.endStates)
		file.close()

				

class GraphWeights:
	"""Represents the state of an undirected edge-weighted graph. The matrix of
	edge weights is always symmetric."""

	def __init__(self,numStates):
		self.numStates = numStates
		self.weights = sparse.lil_matrix((numStates,numStates),dtype=float)

	def copy(self):
		newGraphWeights = GraphWeights(self.numStates)
		newGraphWeights.weights = self.weights.copy()
		return newGraphWeights
	
	def add(self,state1,state2):
		"""Adds a single observation, self weights are increased by 2."""
		self.weights[state1,state2] += 1
		self.weights[state2,state1] += 1

	def update(self,tCounts):
		"""Updates by a count matrix, self weights are reinforced by 2."""
		self.weights = add(self.weights,tCounts).tolil()
		self.weights = add(self.weights,tCounts.transpose()).tolil()

	def updateWithData(self,data):
		"""Updates by all the count matrices in a Data object."""
		for tCounts in data.tCounts:
			self.update(tCounts)

def MicroSelectionEvidence(microData,priorCount=0.5):
	"""Computes a part of the evidence for a lumped MSM that arises from
	the multinomial selection of microstates given the current macrostate
	(Eq. 6 in [2] or the law of a Polya-urn).

	Input:
	'priorCount' parametrizes a uniform Dirichlet distribution assigned to
	the stationary weights for microstates within each macrostate. The default
	value is 1/2, which makes this distribution the Jeffreys prior.
	
	Output:
	Logarithm of the evidence."""
	
	log_evd = 0
	for state in xrange(microData.numStates):
		currMicroCounts = microData.microCounts[microData.mapMicroToMacro==state]
		for count in currMicroCounts:
			log_evd += special.gammaln(count+priorCount)
			log_evd += -special.gammaln(priorCount)
		log_evd += special.gammaln(len(currMicroCounts)*priorCount)
		log_evd += -special.gammaln(sum(currMicroCounts) \
					+len(currMicroCounts)*priorCount)
	return log_evd	

def MultiChainEvidence(data,priorCount=0):
	"""Computes a part of the evidence of a lumped MSM due to the Markov
	chain of macrostates. This is the product of the evidence for every 
	separate trajectory, using for each one a conjugate prior with the
	the initial state set to that of each trajectory (first factor of 
	Eq. A5 in [2]).

	Input:
	'priorWeights' parametrizes the conjugate prior for reversible Markov chains.
	Its default value is set to 1/numStates for every edge on the graph.

	Output:
	Logarithm of the evidence, and updated GraphWeights to be used in 
	correcting the evidence and in posterior sampling."""

	if priorCount == 0:
		priorCount = 1.0/data.numStates
	priorWeights = GraphWeights(data.numStates)

	log_evd = 0
	for chainIndex,tCounts in enumerate(data.tCounts):
		log_evd += RevMarkovChainEvidence(data,chainIndex,priorWeights,priorCount)
		priorWeights.update(tCounts)
	
	return log_evd, priorWeights
 
def RevMarkovChainEvidence(data,chainIndex,priorWeights,priorCount):
	"""Computes the evidence for a single reversible Markov chain with a 
	conjugate prior parametrized by priorWeights + priorCount, and the 
	initial state of the chain (Eq. 4.13 in [1]). Outputs logarithm of 
	the evidence."""

	tCounts = data.tCounts[chainIndex]
	weights = priorWeights.weights

	log_evd = 0
	# Numerator of the evidence (edge weights)
	for row in range(data.numStates):
		for col in range(data.numStates):
			if row>col:
				continue
			if row==col:
				for i in xrange(tCounts[row,col]):
					log_evd += log(weights[row,col]+priorCount+2*i)
			else:
				for i in xrange(tCounts[row,col]+tCounts[col,row]):
					log_evd += log(weights[row,col]+priorCount+i)

	# Denominator of the evidence (vertex weights)
	countsFromStates = array(tCounts.sum(1)).flatten()
	vertexWeights = array(weights.sum(1)).flatten()
	for state, counts in enumerate(countsFromStates):
		if state==data.endStates[chainIndex][0]:
			for i in xrange(counts):
				log_evd += -log(vertexWeights[state]+ \
						priorCount*data.numStates+2*i)
		else:
			for i in xrange(counts):
				log_evd += -log(vertexWeights[state]+ \
						priorCount*data.numStates+1+2*i)
	return log_evd


def PrefactorToMultiChainEvidence(data,initialState,priorCount=0):
	"""Computes a product of gamma functions that is a prefactor to the evidence
	of multitrajectory data (first factor of Eq. A7 in [2]). 

	Input:
	'initialState' parametrizes the conjugate prior (choose native state)
	'priorCount' also parametrizes the conjugate prior.

	Output: 
	Logarithm of this factor of the evidence."""
	
	if priorCount == 0:
		priorCount = 1.0/data.numStates

	log_evd = 0
	f = initialState
	gw = GraphWeights(data.numStates)
	a = sparse.lil_matrix((3,3))
	c = priorCount*data.numStates
	for i,tCounts in enumerate(data.tCounts):
		o = data.endStates[i][0]
		vertexWeight_o = float(gw.weights[o,:].sum(1))
		vertexWeight_f = float(gw.weights[f,:].sum(1))
		log_evd += special.gammaln((vertexWeight_f + c)/2) \
			+  special.gammaln((vertexWeight_o + c)/2+0.5) \
			-  special.gammaln((vertexWeight_o + c)/2) \
			-  special.gammaln((vertexWeight_f + c)/2+0.5)
		f = data.endStates[i][1]
                gw.update(tCounts)
	return log_evd

def LogImportanceWeight(data,sample,initialState):
	"""Returns the logarithm of the function to be estimated by Monte Carlo 
	integration in computing the evidence with multi-trajectory data 
	(Eq. A8 in [2]).

	Input:
	The input 'sample' can be:
	* GraphWeights object with the final edge weights of a sample from a
	reinforced random walk, or
	* A list containing the stationary distribution of the sample."""	

	# Make the input sample an array with the stationary weights of the sample	
	try:
		if sample.__class__ == GraphWeights:
			sample = array(sample.weights.sum(1)).flatten()
			sample = sample/sum(sample)
	except NameError:
		sample = array(sample)

	# Compute the log of the importance weight
	numerator = hstack([sample[data.endStates[0:-1,1].astype(int)],\
			    sample[initialState]])
	numerator = add.reduce(log(numerator),0)
	denominator = sample[data.endStates[:,0].astype(int)]
	denominator = add.reduce(log(denominator),0)
	return (numerator-denominator)/2 	

def SampleReinforcedRW(inputs):
	"""Simulate an edge-reinforced random walk on a graph from initialState,
	with initial edge-weights defined by graphWeights + priorCount.

	Inputs:
	'functions' is a list of function names, which are applied to the sampled
	transition matrix. Each function should take as input a GraphWeights object and
	priorCount; the output is either a number or list.  
	'filename' (str) determines the location of the output.
	'storeSample' (bool) determines whether the sampled transition matrix is stored
	as a graphWeights object or not.
	'randomSeed' (int) a random number seed.

	Output:
	A cPickled dictionary containing:
	* 'statProbs' (array) the stationary probabilities of the sample
	* 'observables' (dict: 'function name' -> list or float), the values of the 
	   functions specified.
	* 'priorCount' (float) the prior count used.
	* 'graphWeights' only if storeSample=1. """

	# parse inputs
	graphWeights,priorCount,initialState,\
		functions,filename,storeSample,randomSeed = inputs
	
	seed(randomSeed)

	# Define number of steps of simulation
	numStates = graphWeights.numStates
	nSteps = 100*numStates**2
	
	# Simulate the ERRW without loops (applying the trick in Appendix C of [2])
	noLoopsGraph = graphWeights.weights.toarray() + priorCount
	noLoopsGraph = noLoopsGraph - eye(numStates)*noLoopsGraph.diagonal()
	currstate = initialState
	for j in xrange(nSteps):
		probs = noLoopsGraph[currstate,:]
		probs = probs/sum(probs)
		oldstate = currstate
		currstate = int(array(range(numStates))[multinomial(1,probs)==1])
		noLoopsGraph[oldstate,currstate] += 1
		noLoopsGraph[currstate,oldstate] += 1
	# Obtain final loop weights from Beta distribution
	initialWeightSelf = graphWeights.weights.diagonal() + priorCount
	initialWeightOther = array(graphWeights.weights.sum(1)).flatten()
	initialWeightOther += priorCount*numStates - initialWeightSelf
	finalWeightOther = noLoopsGraph.sum(1) 
	for state in xrange(numStates):
		p = beta(initialWeightSelf[state]/2,initialWeightOther[state]/2)
		noLoopsGraph[state,state] = p*finalWeightOther[state]
	# Convert to GraphWeights object
	newGraphWeights = GraphWeights(numStates)
	newGraphWeights.weights = sparse.lil_matrix(noLoopsGraph-priorCount)
	# Record stationary probability
	statProbs = noLoopsGraph.sum(1)/sum(noLoopsGraph)
	# Record observables
	observables = dict()
	for function in functions:
		observables[function.__name__] = function(newGraphWeights,priorCount)

	# Write output           
	f = open(filename,'w')
	if storeSample:
		cPickle.dump({'statProbs':statProbs,'observables':observables,\
			'priorCount':priorCount,'graphWeights':newGraphWeights},f)
	else:
		cPickle.dump({'statProbs':statProbs,'observables':observables,\
			'priorCount':priorCount},f)
	f.close()

def PosteriorMeans(data,filenames,initialState,functions):
	"""Computes a Monte Carlo estimate of the posterior mean of functions.
	See appendix D of [2].

	Input:
	'filenames' list of file names containing samples of an ERRW.
	'initialState' the initial state parametrizing the conjugate prior.
	'functions' list of functions of the transition matrix that take a GraphWeights
	object and priorCount as inputs and output a float or list of floats.
	
	Output: 
	A dictionary mapping function names to their posterior mean or means 
	(float or list)."""

	weightedFunctions = dict()
	logImportanceWeights = []

	for filename in filenames:
		f = open(filename,'rw')
		sample = cPickle.load(f)
		f.close()
		# Compute the importance weight of the sample
		liw = LogImportanceWeight(data,sample['statProbs'],initialState)
		logImportanceWeights.append(liw)
        # Normalize the importance weights by their average	
	partitionFunction = LogMeanExp(logImportanceWeights)
	normImportanceWeights = exp(logImportanceWeights-partitionFunction)

	for filenum, filename in enumerate(filenames):
		f = open(filename,'rw')
		sample = cPickle.load(f)
		f.close()
		# Compute the weighted functions
		for function in functions:
			# Create entry, if it doesn't exist
			if not weightedFunctions.has_key(function.__name__):
				weightedFunctions[function.__name__] = []
			if sample['observables'].has_key(function.__name__):
				observable = array(sample['observables'][function.__name__])
				weightedFunctions[function.__name__].append( \
			        	observable*normImportanceWeights[filenum])
			else:
				if not sample.has_key('graphWeights'):
                        		raise IOError('There are no graph weights stored \
                                	to compute functions required in PosteriorMeans!')	
				observable = array(function(sample['graphWeights'],
							    sample['priorCount']))
				weightedFunctions[function.__name__].append(\
					observable*normImportanceWeights[filenum])

	# Compute Eq. D4 in [2] for each function.
	for functionName in weightedFunctions:
		weightedFunctions[functionName] = \
			array(weightedFunctions[functionName]).mean(0)
	
	return weightedFunctions		
	
def MeanImportanceWeight(data,filenames,initialState):
	"""Computes a Monte Carlo estimate of an integral required to obtain
	the evidence of a reversible Markov chain (Eq. A8 in [2]).

	Input:
	'filenames' list of file names containing samples of an ERRW.
	'initialState' the initial state parametrizing the conjugate prior.
	
	Output: 
	Logarithm of the Monte Carlo estimate of the integral (float)."""

	logImportanceWeights = []
	for filename in filenames:
		f = open(filename,'rw')
		sample = cPickle.load(f)
		# Compute the importance weight of the sample
		liw = LogImportanceWeight(data,sample['statProbs'],initialState)
		logImportanceWeights.append(liw)
	# Compute the Monte Carlo average	
	meanLIW = LogMeanExp(logImportanceWeights)			
	
	return meanLIW		

def LogMeanExp(logs):
	"""Input is a list (log x_1, log x_2, ... , log x_m), and output
	is log(mean(x_1,x_2,...,x_m))."""

	sortedLogs = array(logs).copy()
	sortedLogs.sort()
	output = sortedLogs[-1]
	sortedLogs = sortedLogs - sortedLogs[-1]
	x = exp(sortedLogs)
        return output + log(mean(x))	


def PosteriorSample(data,filenames,initialState,nSamples,functions):
	"""Outputs a posterior sample of the functions specified. The sample
	is similar to the sample obtained from simulating the ERRW, but it is
	corrected by the importance weights. If the number of ERRW samples is
	large, the histograms obtained by this function will accurately represent
	the posterior distribution.

	Input:
	'filenames' list of file names containing samples of an ERRW.
	'nSamples' the number of samples to be output.
	'initialState' the initial state parametrizing the conjugate prior.
	'functions' list of functions of the transition matrix that take a GraphWeights
	object and priorCount as inputs and output a float or list of floats.
	
	Output: 
	A dictionary that maps function names to an 1 or 2 dimensional array 
	of samples. If the array is 2-dimensional, the second index denotes a coordinate
	of the function, and the first index denotes the sample number."""
	
	functionSamples = dict()
	logImportanceWeights = []

	for filename in filenames:
		f = open(filename,'rw')
		sample = cPickle.load(f)
		f.close()
		# Compute the importance weight of the sample
		liw = LogImportanceWeight(data,sample['statProbs'],initialState)
		logImportanceWeights.append(liw)
		# Extract function samples
		for function in functions:
			# If not defined add entry to output
			if not functionSamples.has_key(function.__name__):
				functionSamples[function.__name__] = []
			# If function stored in sample file, use it
			if sample['observables'].has_key(function.__name__):
				observable = array(sample['observables'][function.__name__])
				functionSamples[function.__name__].append(observable)
			# Else, try to compute it
			else:
				# If sample file has no graphWeights, stop
				if not sample.has_key('graphWeights'):
                        		raise IOError('There are no graph weights stored \
                                	to compute functions required in PosteriorSample!')
				observable = array(function(sample['graphWeights'],\
							    sample['priorCount']))
				functionSamples[function.__name__].append(observable)

	# Determine the number of repeats for each sample
	normImportanceWeights = exp(logImportanceWeights-LogMeanExp(logImportanceWeights))
	proportions = normImportanceWeights/len(normImportanceWeights)
	sampleRepeats = multinomial(nSamples,proportions)
	# Store the corrected samples
	correctedSamples = dict.fromkeys(functionSamples,0)
	for function in functions:
		correctedSamples[function.__name__] = []
		for i,numRepeats in enumerate(sampleRepeats):
			repeatedSample = [functionSamples[function.__name__][i]]*numRepeats
			correctedSamples[function.__name__].extend(repeatedSample)
		correctedSamples[function.__name__] = array(correctedSamples[function.__name__])

	return correctedSamples		


########################
# Functions of a transition matrix 
# (represented as a GraphWeights object + priorCount)
########################

def Eigenvalues(graphWeights,priorCount):
	"""Top two eigenvalues of the transition matrix."""
	
	tmat = (graphWeights.weights.todense()+priorCount)/graphWeights.weights.sum(1)
	return sort(numpy.linalg.eigvals(tmat))[-2:]

def Metastability(graphWeights,priorCount):
	"""Returns the trace of the transition matrix, normalized by the number of 
	states. Ignores priorCount, but that could be modified."""

	x = (graphWeights.weights.todense()/graphWeights.weights.sum(1)).trace()
	return float(x/graphWeights.numStates)

########################
# User-contributed functions
#
# In the space below, you can add functions of a transition matrix that are
# of interest to you. Each function should take as an input a GraphWeights object
# and priorCount. These inputs represent a reversible transition matrix, as the
# weights on an undirected graph. The weight on edge (i,j) is given by
# GraphWeights.weights(i,j)+priorCount. The output of each function should be
# a float or a list of floats.
########################



########################
# Debugging: 
# Simulate a Markov chain and generate MicroData objects from it.
# Then, test the above functions on this object.
########################

"""
microData = MicroData(5,5)
microDataBad = MicroData(3,5)
microData.mapMicroToMacro = array([0,1,2,3,4])
microDataBad.mapMicroToMacro = array([0,0,1,1,2])

# Sample random microstate transition matrix
tmat = random([5,5])
tmat = tmat + transpose(tmat)
tmat = transpose(transpose(tmat)/tmat.sum(1))

# Simulate Markov chain on microstates and create two MicroData objects

#currMicro=0 				# Case where chains could be concatenated
for chain in range(100):
	initialMicro = randint(5)	# Case where chains CANNOT be concatenated
#	initialMicro = currMicro	# Case where chains could be concatenated
	currMicro = initialMicro
	tCounts = sparse.lil_matrix((5,5))
	tCountsBad = sparse.lil_matrix((3,3))
	for step in range(10): 
		newMicro = int(array(range(5))[multinomial(1,tmat[currMicro,:])==1])
		tCounts[microData.mapMicroToMacro[currMicro],\
			microData.mapMicroToMacro[newMicro]] += 1
		tCountsBad[microDataBad.mapMicroToMacro[currMicro],\
		     	microDataBad.mapMicroToMacro[newMicro]] += 1
		microData.microCounts[newMicro] += 1
		microDataBad.microCounts[newMicro] += 1
		currMicro = newMicro
	microData.tCounts.append(tCounts)
	microDataBad.tCounts.append(tCountsBad)	
	microData.endStates.append([microData.mapMicroToMacro[initialMicro],\
				    microData.mapMicroToMacro[currMicro]])
	microDataBad.endStates.append([microDataBad.mapMicroToMacro[initialMicro],\
				    microDataBad.mapMicroToMacro[currMicro]])
microData.endStates = array(microData.endStates)
microDataBad.endStates = array(microDataBad.endStates)

# Make new MicroData object that is equal to microData, but where all 
# chains are concatenated to make sure the result is the same.
#microDataCat = MicroData(5,5)
#microDataCat.mapMicroToMacro = [0,1,2,3,4]
#microDataCat.tCounts.append(sparse.lil_matrix((5,5)))
#for tCounts in microData.tCounts:
#	microDataCat.tCounts[-1] = add(microDataCat.tCounts[-1],tCounts).tolil()
#microDataCat.endStates = [[microData.endStates[0][0],microData.endStates[-1][-1]]]


# Test microstate selection evidence
microEvidence = MicroSelectionEvidence(microData)
microBadEvidence = MicroSelectionEvidence(microDataBad)
print "Micro evidence (zero) = ", microEvidence
print "Micro bad evidence = ", microBadEvidence

# Test Markov Chain evidence functions
prefactor = PrefactorToMultiChainEvidence(microData,0)
prefactorBad = PrefactorToMultiChainEvidence(microDataBad,0)
multi,gw = MultiChainEvidence(microData)
multiBad,gwBad = MultiChainEvidence(microDataBad)
#multiCat,gwCat = MultiChainEvidence(microDataCat)
print "Prefactor = ", prefactor
print "Prefactor bad = ", prefactorBad
print "Multi = ", multi
#print "MultiCat = ", multiCat
print "Multi Bad = ", multiBad 

# Test ERW simulation
filenames =[]
filenamesBad = []
for sampleIndex in range(100):
	filenames.append('Samples/sample_'+str(sampleIndex))
	SampleReinforcedRW(gw,1.0/gw.numStates,0,\
			[Metastability,Eigenvalues],\
			filenames[-1],storeSample=1)
	filenamesBad.append('Samples/sampleBad_'+str(sampleIndex))
	SampleReinforcedRW(gwBad,1.0/gwBad.numStates,0,\
			[Metastability,Eigenvalues],\
			filenamesBad[-1],storeSample=1)

# Test estimating evidence
meanIW = MeanImportanceWeight(microData,filenames,0)
meanIWBad = MeanImportanceWeight(microDataBad,filenamesBad,0)
print "Log of Monte Carlo factor = ", log(meanIW)
print "Log of Monte Carlo factor bad = ", log(meanIWBad)
print "Total Log Evidence = ", log(meanIW)+prefactor+multi+microEvidence
print "Total Log Evidence bad = ", log(meanIWBad)+prefactorBad+multiBad+microBadEvidence

# Test estimating posterior means
means = PosteriorMeans(microData,filenames,0)
print "Posterior mean of Eigenvalues = ", means['Eigenvalues']
print "Posterior mean of Metastability = ", means['Metastability']

"""

