# just prints the GPL license information
def printLicense():
  print "    MSM Bayes version 0.9, Copyright (C) 2010 Stanford University."
  print "    MSM Bayes comes with ABSOLUTELY NO WARRANTY."
  print "    This program is free software; you can redistribute it and/or"
  print "    modify it under the terms of the GNU General Public License"
  print "    as published by the Free Software Foundation; either version 2"
  print "    of the License, or (at your option) any later version."
  print ""
  print "    Please reference"
  print "    S Bacallado, JD Chodera, and VS Pande. J. Chem. Phys. 2009. "
  print "    Bayesian analysis of Markov models of molecular dynamics with detailed"
  print "    balance contraint."
  print ""

