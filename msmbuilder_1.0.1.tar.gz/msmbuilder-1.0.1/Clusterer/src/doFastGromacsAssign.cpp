/************************************************************/
/* doFastGromacsAssign.cpp
/* 
/* Program for assigning Gromacs data to a known set of clusters.  
/* Uses the triangle inequality to speedup clustering and assignment.
/*
/* Please reference
/* GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble
/* simulations and Markov state models to identify conformational states.
/* 
/* Written by Gregory R. Bowman
/* Biophysics Program, Stanford Un iversity
/* Pande Group
/* 11/14/2008
/*
/* Copyright (C) 2008  Stanford University
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU General Public License as published by
/* the Free Software Foundation; either version 2 of the License, or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful,
/* but WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU General Public License for more details.
/*
/* You should have received a copy of the GNU General Public License
/* along with this program; if not, write to the Free Software
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
/*
/************************************************************/
/* TODO:
/* 
/************************************************************/
/* CHANGE LOG:
/*
/************************************************************/
#include<Argument_helper.h>
#include<fstream>
#include<iostream>
#include <sys/stat.h>
#include "AssignmentStats.h"
#include "Conformation.h"
#include "GromacsAssignmentWriter.h"
#include "GromacsReader.h"
#include "FastKCenterClusterer.h"
#include "license.h"
#include "RMSDist.h"

using namespace std;

int doesFileExist( char *filename ) { 
  struct stat buffer ;
  if ( stat( filename, &buffer ) == 0 ) return 1 ;
  return 0 ; 
}

int main(int argc, const char *argv[]) {
  // store statistics on each micro state
  vector<int> pop, withinCutoff;
  vector<float> maxRMSD, aveRMSD, stdRMSD;

  // input parameters
  int xtcSize = 1;
  double cutoff = 0.1;
  int nSubSample = 1;
  vector<string> trajListFns, atomListFns;
  string mapMicroToMacroFn="";
  bool justExpectedSize = false;
  bool dontIgnore = false;
  int minT=-1, maxT=-1;
  vector<int> temps;
  string statsFn = "stats.dat";

  // parse arguments
  dsr::Argument_helper ah;
  ah.new_named_string('o', "outputStatsFn", "Name of file to output statistics on each cluster to", "outputStatsFn", statsFn);
  ah.new_named_double('c', "cutoff", "Count number of elements within each cluster within this cutoff distance (in nm).", "cutoff", cutoff);
  ah.new_named_string_vector('t', "trajListFns", "List of trajectory files to read in, separated by spaces.", "trajLitsFns", trajListFns);
  ah.new_named_string_vector('a', "atomListFns", "List of atom index files to read in, separated by spaces.  Must be one corresponding to each trajListFn.", "atomListFns", atomListFns);
  ah.new_named_string('m', "mapMicroToMacroFn", "File listing macrostate each micro sttate is in.", "mapMciroToMacroFn", mapMicroToMacroFn);
  ah.new_named_int('x', "xtcSize", "Number of snapshots in each xtc file.", "xtcSize", xtcSize);
  ah.new_named_int('n', "nSubSample", "Only take every nth snapshot from each trajectory.", "nSubSample", nSubSample);
  ah.new_named_int('l', "lowT", "Lowest temperature to include.", "lowT", minT);
  ah.new_named_int('u', "upperT", "Highest temperature to include.", "upperT", maxT);
  ah.new_flag('j', "justExpectedSize", "If this flag is specified then just print the expected number of conformations and the size they'll take in memory without doing any clustering.", justExpectedSize);
  ah.new_flag('d', "dontIgnore", "If this flag is specified then don't ignore the last snapshot of each xtc file.", dontIgnore);
  ah.set_description("A small program for assigning Molecular Dynamics (MD) data from the Gromacs software package to cluster centers.  Statistics on each cluster are output to the stats.dat file as explained in the documentation.");
  ah.set_author("Greg Bowman, gregoryrbowman@gmail.com");
  ah.set_version(0.1);
  printLicense();
  ah.process(argc, argv);
  cout << "Argument values:" << endl;
  ah.write_values(std::cout);

  // error checking
  if(trajListFns.size() == 0 || atomListFns.size() == 0) {
    cout << "ERROR: must have at least one trajectory list and one atom list." << endl;
    return 1;
  }
  if(trajListFns.size() != atomListFns.size()) {
    cout << "ERROR: must have an equal number of trajectory and atom list files." << endl;
    return 1;
  }
  if(cutoff <= 0) {
    cout << "ERROR: cutoff must be greater than 0." << endl;
    return 1;
  }

  vector<Element*> confs;
  try {
    // setup clusterer
    int nAtoms, prevNAtoms;
    FastKCenterClusterer clusterer;
    vector<float> distances;
    vector<int> assignments;
    cout << "Reading in generators and doing assign" << endl;
    string fn = "generators/numGens";
    int nGen;
    ifstream f(fn.c_str());
    f >> nGen;
    f.close();
    cout << " Found " << nGen << " generators" << endl;
    vector<Element*> gens(nGen);
    for(int g=0; g<nGen; g++)
      gens[g] = new Conformation();
    clusterer.readGenerators(gens);
    nAtoms = Conformation::getNAtoms();
    prevNAtoms = nAtoms;

    // initialize statistics as long as not just getting size
    if(!justExpectedSize) {
      pop.resize(nGen, 0);
      withinCutoff.resize(nGen, 0);
      maxRMSD.resize(nGen, 0);
      aveRMSD.resize(nGen, 0);
      stdRMSD.resize(nGen, 0);
    }

    // init real distance metric used for clustering
    RMSDist rdReal(nAtoms, true, false);
    clusterer.setDistMetric(&rdReal);

    // check that assignments directory exists
    if( !doesFileExist("assignments") ) {
      system("mkdir assignments");
    }

    // loop over trajectory/atom lists doing assign
    for(int i=0; i<trajListFns.size(); i++) {
      // read in data
      // should check that Atoms is same for all
      cleanup(confs);
      confs.clear();
      int nAtoms;
      GromacsReader gr(trajListFns[i], atomListFns[i]);
      gr.setXtcSize(xtcSize);
      gr.readAtomIndices();
      gr.setNSubSample(nSubSample);
      if(justExpectedSize)
        gr.getSizeData(dontIgnore);
      else
        gr.getData(confs, dontIgnore);
      nAtoms = gr.getNumAtoms();

      // make sure nAtoms same for all traj lists
      if(prevNAtoms != nAtoms) {
        cout << "ERROR: all generators and trajectory list/atom index list files must have the same number of atoms." << endl;
        cleanup(confs);
        throw -1;
      }
      prevNAtoms = nAtoms;

      // only do assign and write if not just getting size
      if(!justExpectedSize) {
        cout << "Size of data " << confs.size() << endl;
        cout << "Number of atoms " << nAtoms << endl;

        // cluster the data into two clusters
        clusterer.assign(confs, distances, assignments);

        // accumulate statistics
        accumulateStats(pop, maxRMSD, aveRMSD, stdRMSD, withinCutoff, cutoff, distances, assignments);

        // write assignments
        GromacsAssignmentWriter grw(trajListFns[i]);
        // if no macro state  ng file given then just print micro state assignments 
        if(mapMicroToMacroFn == "")
          grw.writeData(confs, assignments);
        // if have macro state mapping but no temps then print macro state assignments too
        else if(minT == -1 && maxT == -1)
          grw.writeData(confs, assignments, mapMicroToMacroFn);
        // if have temps then all confs outside specified temp range are put in micro/macro state -1
        else {
          gr.getTempData(temps);
          grw.writeData(confs, assignments, mapMicroToMacroFn, minT, maxT, temps);
          temps.clear();
        }

        // cleanup
        cleanup(confs);
      }
    }

    // as long as not just getting size, then print statistics
    if(!justExpectedSize)
      printStats(statsFn, pop, maxRMSD, aveRMSD, stdRMSD, withinCutoff);

    cout << "Done with all assigns." << endl;

    return 0;
  }
  catch(...) {
    cout << "Terminated due to error." << endl;
    cleanup(confs);
    return 1;
  }
}

