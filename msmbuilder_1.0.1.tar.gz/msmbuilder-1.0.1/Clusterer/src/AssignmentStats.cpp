/************************************************************/
/* AssignmentStats.cpp
/* 
/* Code for getting statistics on assignments that is used by the
/* clustering and assignment programs.
/*
/* Please reference
/* GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble
/* simulations and Markov state models to identify conformational states.
/* 
/* Written by Gregory R. Bowman
/* Biophysics Program, Stanford Un iversity
/* Pande Group
/* 12/1/2008
/*
/* Copyright (C) 2008  Stanford University
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU General Public License as published by
/* the Free Software Foundation; either version 2 of the License, or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful,
/* but WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU General Public License for more details.
/*
/* You should have received a copy of the GNU General Public License
/* along with this program; if not, write to the Free Software
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
/*
/************************************************************/
/* TODO:
/* 
/************************************************************/
/* CHANGE LOG:
/*
/************************************************************/
#include<fstream>
#include<string>
#include<vector>
#include "AssignmentStats.h"
#include "Conformation.h"

using namespace std;

// accumulate statistics
void accumulateStats(vector<int> &pop, vector<float> &maxRMSD, vector<float> &aveRMSD, vector<float> &stdRMSD, vector<int> &withinCutoff, double cutoff, vector<float> &dist, vector<int> &assign) {
  for(int i=0; i<assign.size(); i++) {
    int micro = assign[i];
    pop[micro]++;
    if(dist[i] > maxRMSD[micro])
      maxRMSD[micro] = dist[i];
    aveRMSD[micro] += dist[i];
    stdRMSD[micro] += dist[i]*dist[i];
    if(dist[i] <= cutoff)
      withinCutoff[micro]++;
  }
}

// print final statistics. Format is one line/micro state with 
// population, ave rmsd, and std rmsd separated by spaces
void printStats(string fn, vector<int> &pop, vector<float> &maxRMSD, vector<float> &aveRMSD, vector<float> &stdRMSD, vector<int> &withinCutoff) {
  // get final aves and standard deviations and print to file
  ofstream f(fn.c_str());
  for(int micro=0; micro<pop.size(); micro++) {
    aveRMSD[micro] /= pop[micro];
    stdRMSD[micro] /= pop[micro];
    stdRMSD[micro] -= aveRMSD[micro]*aveRMSD[micro];
    f << pop[micro] << " " << maxRMSD[micro] << " " << aveRMSD[micro] << " " << stdRMSD[micro] << " ";
    f << withinCutoff[micro] << endl;
  }
  f.close();
}

// free all allocated space
void cleanup(vector<Element*> &confs) {
  for(unsigned int i=0; i<confs.size(); i++) {
    Conformation *currConf = (Conformation*)confs[i];
    delete currConf;
  }
  confs.clear();
}

