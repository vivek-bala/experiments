/************************************************************/
/* GromacsAssignmentWriter.cpp
/* 
/* Class for representing a writing assignments of Gromacs data to 
/* micro/macro states. Inherits from AssignmentWriter.
/*
/* Please reference
/* GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble
/* simulations and Markov state models to identify conformational states.
/* 
/* Written by Gregory R. Bowman
/* Biophysics Program, Stanford Un iversity
/* Pande Group
/* 11/14/2008
/*
/* Copyright (C) 2008  Stanford University
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU General Public License as published by
/* the Free Software Foundation; either version 2 of the License, or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful,
/* but WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU General Public License for more details.
/*
/* You should have received a copy of the GNU General Public License
/* along with this program; if not, write to the Free Software
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
/*
/************************************************************/
/* TODO:
/* 
/************************************************************/
/* CHANGE LOG:
/*
/************************************************************/
#include<fstream>
#include<iostream>
#include "GromacsAssignmentWriter.h"

using namespace std;

/************************************************************/
/* GromacsAssignmentWriter()
/*   Constructor
/* Arguemtns:
/*   None
/* Return:
/*   None
/************************************************************/
GromacsAssignmentWriter::GromacsAssignmentWriter() {
  assignDir = "assignments";
  trajListFn = "trajlist";
}

/************************************************************/
/* GromacsAssignmentWriter()
/*   Constructor
/* Arguemtns:
/*   string trajFn = name of file listing trajectories to write assignments of.
/* Return:
/*   None
/************************************************************/
GromacsAssignmentWriter::GromacsAssignmentWriter(std::string trajFn) {
  assignDir = "assignments";
  trajListFn = trajFn;
}

/************************************************************/
/* writeData()
/*   Write micro state assignments for the trajectories listed in 
/*   the file specified to the constructor.
/* Arguemtns:
/*   vector<Element*> &data = vector of data points
/*   vector<int> &assignMicro = bector of micro state assignments corresponding
/*    to each data point
/* Return:
/*   None
/************************************************************/
void GromacsAssignmentWriter::writeData(vector<Element*> &data, vector<int> &assignMicro) {
  // call writeData(data, assignMicro, mapMicroToMacroFn) indicating that 
  // there are no macro state assignments
  string mapMicroToMacroFn = "";
  writeData(data, assignMicro, mapMicroToMacroFn);
}

/************************************************************/
/* writeData()
/*   Write micro and macro state assignments for the trajectories listed in 
/*   the file specified to the constructor.
/* Arguemtns:
/*   vector<Element*> &data = vector of data points
/*   vector<int> &assignMicro = bector of micro state assignments corresponding
/*    to each data point
/*   string mapMicroToMacroFn = name of file listing mapping of micro states
/*    to macro states. Format is one line per micro state listing the index of 
/*    the macro state it is in (e.g. line 1 indicates the macro state micro 
/*    state 0 is in, line 2 indicates the macro state microstate 1 is in, ...).
/* Return:
/*   None
/************************************************************/
void GromacsAssignmentWriter::writeData(vector<Element*> &data, vector<int> &assignMicro, string mapMicroToMacroFn) {
  cout << "Writing assignments." << endl;

  // whether or not to write out macro state assignemtns
  bool writeMacro = false;

  // determine whether a mapMicroToMacroFn was specified.  If so, will write 
  // macro state assignemtns, otherwise will only write micro state asignbments.
  if(mapMicroToMacroFn != "") {
    cout << "Writing micro and macro state assignemtns." << endl;
     writeMacro = true;
  }
  else {
    cout << "Writing micro state assignments" << endl;
    writeMacro = false;
  }

  // if have mapping of micro states to macro states, then read it in
  vector<int> mapMicroToMacro;
  if(writeMacro) {
    cout << " Reading in mapping from micro to macro states from " << mapMicroToMacroFn << endl;
    ifstream mapMicroToMacroF(mapMicroToMacroFn.c_str());
    if(!mapMicroToMacroF.is_open()) {
      cout << "ERROR: mapping of micro to macro state file " << mapMicroToMacroFn << " could not be opened." << endl;
      throw -1;
    }

    int macro;
    while(mapMicroToMacroF >> macro)
      mapMicroToMacro.push_back(macro);

    mapMicroToMacroF.close();
  }

  // open the traj list file
  ifstream trajListF(trajListFn.c_str());
  if(!trajListF.is_open()) {
    cout << "ERROR: traj list file " << trajListFn << " could not be opened." << endl;
    throw -1;
  }

  // iterate over trajectories in traj list creating assignment file for each
  string trajFn;
  int d = 0;
  int curTrajNum = 0;
  while(trajListF >> trajFn) {
    // get traj file
    trajFn = assignDir + "/" + trajFn;
    cout << " Writing " << trajFn << endl;
    ofstream trajF(trajFn.c_str());
    if(!trajF.is_open()) {
      cout << "WARNING: traj file " << trajFn << " could not be opened." << endl;
      continue;
    }

    // loop over data printing assignments for block of data corresponding 
    // to current trajectory (all data should be sorted by trajID)
    Conformation* curDataPoint = (Conformation*)data[d];
    while(d < data.size() && curDataPoint->trajID == curTrajNum) {
      trajF << assignMicro[d] << " ";

      // if have macro state assignemtns then write that too
      if(writeMacro)
        // only write macro state assignment if exists, otherwise print error 
        // and exit function
        if(mapMicroToMacro.size() > assignMicro[d])
          trajF << mapMicroToMacro[assignMicro[d]];
        else {
          cout << "ERROR: no macro state assignment for micro state " << assignMicro[d] << endl;
          throw -1;
        }
      trajF << endl;

      // move to next data point
      d++;
      curDataPoint = (Conformation*)data[d];
    }

    curTrajNum++;
    trajF.close();
  }

  trajListF.close();
  cout << "Done writing assignments." << endl;
}

/************************************************************/
/* writeData()
/*   Write micro and macro state assignments for the trajectories listed in 
/*   the file specified to the constructor.
/* Arguemtns:
/*   vector<Element*> &data = vector of data points
/*   vector<int> &assignMicro = bector of micro state assignments corresponding
/*    to each data point
/*   string mapMicroToMacroFn = name of file listing mapping of micro states
/*    to macro states. Format is one line per micro state listing the index of 
/*    the macro state it is in (e.g. line 1 indicates the macro state micro 
/*    state 0 is in, line 2 indicates the macro state microstate 1 is in, ...).
/*   int minT = minimum temperature index to include
/*   int maxT = maximum temperature index to include
/*   vector<int> &temps = vector of temperature indices corresponding to 
/*    conformations
/* Return:
/*   None
/************************************************************/
void GromacsAssignmentWriter::writeData(vector<Element*> &data, vector<int> &assignMicro, string mapMicroToMacroFn, int minT, int maxT, vector<int> & temps) {
  cout << "Writing assignments." << endl;

  // whether or not to write out macro state assignemtns
  bool writeMacro = false;

  // determine whether a mapMicroToMacroFn was specified.  If so, will write 
  // macro state assignemtns, otherwise will only write micro state asignbments.
  if(mapMicroToMacroFn != "") {
    cout << "Writing micro and macro state assignemtns." << endl;
     writeMacro = true;
  }
  else {
    cout << "Writing micro state assignments" << endl;
    writeMacro = false;
  }

  // if have mapping of micro states to macro states, then read it in
  vector<int> mapMicroToMacro;
  if(writeMacro) {
    cout << " Reading in mapping from micro to macro states from " << mapMicroToMacroFn << endl;
    ifstream mapMicroToMacroF(mapMicroToMacroFn.c_str());
    if(!mapMicroToMacroF.is_open()) {
      cout << "ERROR: mapping of micro to macro state file " << mapMicroToMacroFn << " could not be opened." << endl;
      throw -1;
    }

    int macro;
    while(mapMicroToMacroF >> macro)
      mapMicroToMacro.push_back(macro);

    mapMicroToMacroF.close();
  }

  // open the traj list file
  ifstream trajListF(trajListFn.c_str());
  if(!trajListF.is_open()) {
    cout << "ERROR: traj list file " << trajListFn << " could not be opened." << endl;
    throw -1;
  }

  // iterate over trajectories in traj list creating assignment file for each
  string trajFn;
  int d = 0;
  int curTrajNum = 0;
  while(trajListF >> trajFn) {
    // get traj file
    trajFn = assignDir + "/" + trajFn;
    cout << " Writing " << trajFn << endl;
    ofstream trajF(trajFn.c_str());
    if(!trajF.is_open()) {
      cout << "WARNING: traj file " << trajFn << " could not be opened." << endl;
      continue;
    }

    // loop over data printing assignments for block of data corresponding 
    // to current trajectory (all data should be sorted by trajID)
    Conformation* curDataPoint = (Conformation*)data[d];
    while(d < data.size() && curDataPoint->trajID == curTrajNum) {
      // if temperatures specified and current conformation out of range then 
      // label as being in microstae -1 and macrostate -1
      if(temps.size() != 0 && (temps[d]<minT || temps[d]>maxT)) {
        trajF << "-1 ";
        if(mapMicroToMacro.size() > 0)
          trajF << "-1";
        trajF << endl;
      }
      else {
        trajF << assignMicro[d] << " ";

        // if have macro state assignemtns then write that too
        if(writeMacro)
          // only write macro state assignment if exists, otherwise print error 
          // and exit function
          if(mapMicroToMacro.size() > assignMicro[d])
            trajF << mapMicroToMacro[assignMicro[d]];
          else {
            cout << "ERROR: no macro state assignment for micro state " << assignMicro[d] << endl;
            throw -1;
          }
        trajF << endl;
      }

      // move to next data point
      d++;
      curDataPoint = (Conformation*)data[d];
    }

    curTrajNum++;
    trajF.close();
  }

  trajListF.close();
  cout << "Done writing assignments." << endl;
}

