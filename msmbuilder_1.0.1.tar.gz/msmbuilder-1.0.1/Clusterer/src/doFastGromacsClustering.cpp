/************************************************************/
/* doFastGromacsClustering.cpp
/* 
/* Program for clustering Gromacs data.  
/* Uses the triangle inequality to speedup clustering and assignment.
/*
/* Please reference
/* GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble 
/* simulations and Markov state models to identify conformational states.
/*
/* Written by Gregory R. Bowman
/* Biophysics Program, Stanford Un iversity
/* Pande Group
/* 11/14/2008
/*
/* Copyright (C) 2008  Stanford University
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU General Public License as published by
/* the Free Software Foundation; either version 2 of the License, or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful,
/* but WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU General Public License for more details.
/*
/* You should have received a copy of the GNU General Public License
/* along with this program; if not, write to the Free Software
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
/*
/************************************************************/
/* TODO:
/* - allow do assignes when have multiple trajectory lists
/************************************************************/
/* CHANGE LOG:
/*
/************************************************************/
#include<Argument_helper.h>
#include<fstream>
#include<iostream>
#include<sys/stat.h>
#include "AssignmentStats.h"
#include "Conformation.h"
#include "GromacsAssignmentWriter.h"
#include "GromacsReader.h"
#include "FastKCenterClusterer.h"
#include "license.h"
#include "RMSDist.h"

using namespace std;

int doesFileExist( char *filename ) {
  struct stat buffer ;
  if ( stat( filename, &buffer ) == 0 ) return 1 ;

  return 0 ;
}

int main(int argc, const char *argv[]) {
  // store statistics on each micro state
  vector<int> pop, withinCutoff;
  vector<float> maxRMSD, aveRMSD, stdRMSD;

  // input parameters
  int k = 1;
  int nSubSample = 1;
  double cutoff = 0.1;
  int seed = 0;
  int xtcSize = 0;
  vector<string> trajListFns, atomListFns;
  bool writeAssignments = false;
  bool justExpectedSize = false;
  bool dontIgnore = false;
  string statsFn = "stats.dat";

  // parse arguments
  dsr::Argument_helper ah;
  ah.new_named_string_vector('t', "trajListFns", "List of trajectory files to read in, separated by spaces.", "trajLitsFns", trajListFns);
  ah.new_named_string_vector('a', "atomListFns", "List of atom index files to read in, separated by spaces.  Must be one corresponding to each trajListFn.", "atomListFns", atomListFns);
  ah.new_named_string('o', "outputStatsFn", "Name of file to output statistics on each cluster to", "outputStatsFn", statsFn);
  ah.new_named_double('c', "cutoff", "Count number of elements within each cluster within this cutoff distance (in nm).", "cutoff", cutoff);
  ah.new_named_int('k', "k_clusters", "Number of clusters to generate.", "k", k);
  ah.new_named_int('x', "xtcSize", "Number of snapshots in each xtc file.", "xtcSize", xtcSize);
  ah.new_named_int('n', "nSubSample", "Only take every nth snapshot from each trajectory.", "nSubSample", nSubSample);
  ah.new_named_int('s', "seed", "Index of first cluster center.  Generally should not be used.", "seed", seed);
  ah.new_flag('w', "writeAssignments", "If this flag is specified then the assignments will be written out after clustering.", writeAssignments);
  ah.new_flag('j', "justExpectedSize", "If this flag is specified then just print the expected number of conformations and the size they'll take in memory without doing any clustering.", justExpectedSize);
  ah.new_flag('d', "dontIgnore", "If this flag is specified then don't ignore the last snapshot of each xtc file.", dontIgnore);
  ah.set_description("A small program for clustering Molecular Dynamics (MD) data from the Gromacs software package.");
  ah.set_author("Greg Bowman, gregoryrbowman@gmail.com");
  ah.set_version(0.1);
  printLicense();
  ah.process(argc, argv);
  cout << "Argument values:" << endl;
  ah.write_values(std::cout);

  // error checking
  if(trajListFns.size() == 0 || atomListFns.size() == 0) {
    cout << "ERROR: must have at least one trajectory list and one atom list." << endl;
    return 1;
  }
  if(trajListFns.size() != atomListFns.size()) {
    cout << "ERROR: must have an equal number of trajectory and atom list files." << endl;
    return 1;
  }
  if(cutoff <= 0) {
    cout << "ERROR: cutoff must be greater than 0." << endl;
    return 1;
  }

  vector<Element*> confs;
  try {
    // read in data
    // should check that Atoms is same for all
    int nAtoms;
    int prevNAtoms = -1;
    for(int i=0; i<trajListFns.size(); i++) {
      string trajListFn = trajListFns[i];
      string atomListFn = atomListFns[i];
      GromacsReader gr(trajListFn, atomListFn);
      gr.setXtcSize(xtcSize);
      gr.readAtomIndices();
      gr.setNSubSample(nSubSample);
      if(justExpectedSize)
        gr.getSizeData(dontIgnore);
      else
        gr.getData(confs, dontIgnore);
      nAtoms = gr.getNumAtoms();

      // make sure nAtoms same for all traj lists
      if(prevNAtoms > -1 && prevNAtoms != nAtoms) {
        cout << "ERROR: all trajectory list/atom index list files must have the same number of atoms." << endl;
        cleanup(confs);
        throw -1;
      }
      prevNAtoms = nAtoms;
    }

    // now exit if just getting size
    if(justExpectedSize)
      return 0;

    // set number of atoms for all Conforations
    Conformation::setNAtoms(nAtoms);

    cout << "Size of data " << confs.size() << endl;
    cout << "Number of atoms " << nAtoms << endl;

    // init distance metric used for clustering
    RMSDist rd(nAtoms, true, false);

    // make sure the assignments and trajectories directories exist
    if( !doesFileExist("generators") ) {
      system("mkdir generators");
    }
    if( !doesFileExist("assignments") ) {
      system("mkdir assignments");
    }

    // cluster the data 
    FastKCenterClusterer clusterer(&rd);
    vector<float> distances;
    vector<int> assignments;
    clusterer.cluster(confs, k, seed, distances, assignments);
    clusterer.writeGenerators();

    cout << "Getting micro state statistics." << endl;

    // initialize statistics
    if(!justExpectedSize) {
      pop.resize(k, 0);
      withinCutoff.resize(k, 0);
      maxRMSD.resize(k, 0);
      aveRMSD.resize(k, 0);
      stdRMSD.resize(k, 0);
    }

    // accumulate statistics
    accumulateStats(pop, maxRMSD, aveRMSD, stdRMSD, withinCutoff, cutoff, distances, assignments);
    printStats(statsFn, pop, maxRMSD, aveRMSD, stdRMSD, withinCutoff);

    // write assignments
    if(writeAssignments && trajListFns.size() > 1) {
      cout << "WARNING: cannot write assignemtns with doClustering when using multiple trajectory/atom lists.  Skipping this step.  Please use doAssign." << endl;
    }
    else if(writeAssignments) {
      // write assignments
      cout << "Writing assignments." << endl;
      GromacsAssignmentWriter grw(trajListFns[0]);
      grw.writeData(confs, assignments);
    }

    // cleanup
    cleanup(confs);

    return 0;
  }
  catch(...) {
    cout << "Terminated program due to error." << endl;
    cleanup(confs);
    return 1;
  }
}

