#include<iostream>
#include "license.h"

using namespace std;

void printLicense() {
  cout << "    MSMBuilder version 1.0, Copyright (C) 2010 Stanford University." << endl;
  cout << "    MSMBuilder comes with ABSOLUTELY NO WARRANTY." << endl;
  cout << "    This program is free software; you can redistribute it and/or" << endl;
  cout << "    modify it under the terms of the GNU General Public License" << endl;
  cout << "    as published by the Free Software Foundation; either version 2" << endl;
  cout << "    of the License, or (at your option) any later version." << endl;
  cout << endl;
  cout << "    Please reference" << endl;
  cout << "    GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble" << endl;
  cout << "    simulations and Markov state models to identify conformational states." << endl;
  cout << endl;
}

