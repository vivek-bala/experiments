/************************************************************/
/* Conformation.cpp
/* 
/* Class for representing a molecular conformation. Inherits Element.
/*
/* Please reference
/* GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble
/* simulations and Markov state models to identify conformational states.
/* 
/* Written by Gregory R. Bowman
/* Biophysics Program, Stanford Un iversity
/* Pande Group
/* 11/14/2008
/*
/* Copyright (C) 2008  Stanford University
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU General Public License as published by
/* the Free Software Foundation; either version 2 of the License, or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful,
/* but WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU General Public License for more details.
/*
/* You should have received a copy of the GNU General Public License
/* along with this program; if not, write to the Free Software
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
/*
/************************************************************/
/* TODO:
/* 
/************************************************************/
/* CHANGE LOG:
/*
/************************************************************/
#include<fstream>
#include<iostream>
#include<string>
#include "Conformation.h"

using namespace std;

unsigned int Conformation::nAtoms = 0;

/************************************************************/
/* Conformation()
/*   Constructor
/* Arguemtns:
/*   None
/* Return:
/*   None
/************************************************************/
Conformation::Conformation() {
  trajID = 0;
  xtcID = 0;
  ssID = 0;
  pos = NULL;
}

/************************************************************/
/* Conformation()
/*   Constructor
/* Arguemtns:
/*   unsigned int tID = trajectory ID (trajectory number relative to ordering in trajectory list file)
/*   unsigned int xID = xtc ID (xtc file number relative list of xtc files in trajectory)
/*   unsigned int sID = snapshot ID (snapshot number relative to xtc file)
/*   float* p = array of atom coordinates in format: x1, x2... y1, y2..., z1, z2...
/* Return:
/*   None
/************************************************************/
Conformation::Conformation(unsigned int tID, unsigned int xID, unsigned int sID, float* p) {
  trajID = tID;
  xtcID = xID;
  ssID = sID;
  pos = p;
}

/************************************************************/
/* ~Conformation()
/*   Destructor
/* Arguemtns:
/*   None
/* Return:
/*   None
/************************************************************/
Conformation::~Conformation() {
  delete[] pos;
}

/************************************************************/
/* read()
/*   Read Conformation in from a file
/* Arguemtns:
/*   string fn = file name to read from.  Format is: trajID, xtcID, sID, 
/*    nAtoms, x1, x2... y1, y2... z1, z2... where each entry is on its own line.
/* Return:
/*   None
/************************************************************/
void Conformation::read(string fn) {
  ifstream f(fn.c_str());
  if(!f.is_open()) {
    cout << "ERROR: could not open file " << fn << endl;
    throw -1;
  }

  f >> trajID;
  f >> xtcID;
  f >> ssID;
  f >> nAtoms;
  if(pos == NULL)
    pos = new float[3*nAtoms];
  for(int i=0; i<3*nAtoms; i++) {
    f >> pos[i];
  }
  f.close();
}

/************************************************************/
/* write()
/*   Write Conformation to a file.
/* Arguemtns:
/*   string fn = file name to write to.  Format is: trajID, xtcID, sID, 
/*    nAtoms, x1, x2... y1, y2... z1, z2... where each entry is on its own line.
/* Return:
/*   None
/************************************************************/
void Conformation::write(string fn) {
  ofstream f(fn.c_str());
  if(!f.is_open()) {
    cout << "ERROR: could not open file " << fn << endl;
    throw -1;
  }

  f << trajID << endl;
  f << xtcID << endl;
  f << ssID << endl;
  f << nAtoms << endl;
  for(int i=0; i<3*nAtoms; i++) {
    f << pos[i] << endl;
  }
  f.close();
}

/************************************************************/
/* getNAtoms()
/*   Get the number of atoms in all the Conformations.
/* Arguemtns:
/*   None
/* Return:
/*   Number of atoms in every Conformation (int)
/************************************************************/
int Conformation::getNAtoms() {
  return nAtoms;
}

/************************************************************/
/* setNAtoms()
/*   Set the number of atoms in all the Conformations.
/* Arguemtns:
/*   int n = number of atoms
/* Return:
/*   None
/************************************************************/
void Conformation::setNAtoms(int n) {
  if(n < 0) {
    cout << "ERROR: number of atoms must be greater than or equal to 0." << endl;
    throw -1;
  }

  nAtoms = n;
}

