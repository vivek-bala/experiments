/************************************************************/
/* doFastGromacsAssign.cpp
/*
/* Program for assigning Gromacs data to a known set of clusters.
/* Uses the triangle inequality to speedup clustering and assignment.
/*
/* Please reference
/* GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble
/* simulations and Markov state models to identify conformational states.
/*
/* Written by Gregory R. Bowman
/* Biophysics Program, Stanford Un iversity
/* Pande Group
/* 11/14/2008
/*
/* Copyright (C) 2008  Stanford University
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU General Public License as published by
/* the Free Software Foundation; either version 2 of the License, or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful,
/* but WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU General Public License for more details.
/*
/* You should have received a copy of the GNU General Public License
/* along with this program; if not, write to the Free Software
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
/*
/************************************************************/
/* TODO:
/*
/************************************************************/
/* CHANGE LOG:
/*
/************************************************************/
#include<Argument_helper.h>
#include<fstream>
#include<iostream>
#include<sstream>
#include "Conformation.h"
#include "license.h"
#include "RMSDist.h"

using namespace std;

void findCentralGen(vector<Conformation*> &members, int &center, int &pop, float &maxRmsd, float &aveRmsd, float &stdRmsd) {
  // initialize distance metric
  int nAtoms = members[0]->getNAtoms();
  RMSDist rd(nAtoms, true, false);

  // population is number of micro state centers in current macro state
  pop = members.size();

  // get rmsds between all pairs of conformations
  vector<vector<float>*> rmsds;
  vector<float> sums;
  for(int i=0; i<pop; i++) {
    rmsds.push_back(new vector<float>);
    sums.push_back(0);
    for(int j=0; j<pop; j++) {
      float rmsd = rd.getDist(members[i], members[j]);
      rmsds[i]->push_back(rmsd);
      sums[i] += rmsd;
    }
  }

  // find conformation with minimum sum.
  // this is the central micro state center 
  // (i.e. its closest to all micro state centers).
  center = 0;
  for(int i=0; i<pop; i++) {
    if(sums[i] < sums[center])
      center = i;
  }

  // get sttaistics on rmsd dist
  maxRmsd = aveRmsd = stdRmsd = 0;
  for(int i=0; i<pop; i++) {
    float rmsd = rmsds[center]->at(i);
    if(rmsd > maxRmsd)
      maxRmsd = rmsd;
    aveRmsd += rmsd;
    stdRmsd += rmsd*rmsd;
  }
  aveRmsd /= pop;
  stdRmsd /= pop;
  stdRmsd -= aveRmsd*aveRmsd;

  // clear space
  for(int i=0; i<pop; i++)
    delete rmsds[i];
}

// free all allocated space
void cleanup(vector<Conformation*> &confs) {
  for(unsigned int i=0; i<confs.size(); i++) {
    Conformation *currConf = confs[i];
    delete currConf;
  }
  confs.clear();
}

int main(int argc, const char *argv[]) {
  int numMacro=1;
  string mapMicroToMacroFn="";

  // parse arguments
  dsr::Argument_helper ah;
  ah.new_named_string('m', "mapMicroToMacroFn", "File listing macrostate each micro sttate is in.", "mapMciroToMacroFn", mapMicroToMacroFn);
  ah.new_named_int('n', "numMacro", "Number of macro states.", "numMacro", numMacro);
  ah.set_description("A small program for finding the most central micro state center for each macro state.");
  ah.set_author("Greg Bowman, gbowman@@stanford.edu");
  ah.set_version(1.0);
  printLicense();
  ah.process(argc, argv);
  cout << "Argument values:" << endl;
  ah.write_values(std::cout);

  // error checking
  if(mapMicroToMacroFn == "") {
    cout << "ERROR: must specify a mapping between micro and macro states." << endl;
    return 1;
  }
  if(numMacro <= 0) {
    cout << "ERROR: the number of macro states must be greater than 0." << endl;
    return 1;
  }

  vector<Conformation*> generators;
  vector<int> mapMicroToMacro;
  string genDir = "generators";
  try {
    // read in the mapping between micro states and macro states
    int macro;
    cout << "Reading in mapping from micro to macro states from " << mapMicroToMacroFn << endl;
    ifstream mapMicroToMacroF(mapMicroToMacroFn.c_str());
    if(!mapMicroToMacroF.is_open()) {
      cout << "ERROR: mapping of micro to macro state file " << mapMicroToMacroFn << " could not be opened." << endl;
      throw -1;
    }
    while(mapMicroToMacroF >> macro)
      mapMicroToMacro.push_back(macro);
    mapMicroToMacroF.close();

    // read in all the generators (micro state centers)
    cout << "Reading in generators and doing assign" << endl;
    string fn = "generators/numGens";
    int nGen;
    ifstream f(fn.c_str());
    f >> nGen;
    f.close();
    cout << " Found " << nGen << " generators" << endl;
    for(int g=0; g<nGen; g++) {
      stringstream converter;
      converter << g;
      string num;
      converter >> num;
      string fn = genDir + "/gen" + num;
      Conformation *c = new Conformation();
      c->read(fn);
      generators.push_back(c);
    }

    // check that lengths agree
    if(mapMicroToMacro.size() != nGen) {
      cout << "ERROR: the mapping from micro to macro states does not have the same number of entries as there are micro states." << endl;
      throw -1;
    }

    // loop over macro staes, finding central micro state and statistics for each one
    cout << "Getting macro state centers." << endl;
    int center, pop;
    float maxRmsd, aveRmsd, stdRmsd;
    vector<int> centers, pops;
    vector<float> maxRmsds, aveRmsds, stdRmsds;
    vector<Conformation*> members;
    for(int macro=0; macro<numMacro; macro++) {
      cout << " Getting center of macro state " << macro << endl;

      // loop over mapping to create list of generators in this macrostate
      vector<int> mapMemberToGenerators;
      for(int micro=0; micro<generators.size(); micro++)
        if(mapMicroToMacro[micro] == macro) {
          members.push_back(generators[micro]);
          mapMemberToGenerators.push_back(micro);
      }

      // find stats on current macro state and store
      findCentralGen(members, center, pop, maxRmsd, aveRmsd, stdRmsd);
      centers.push_back(mapMemberToGenerators[center]);
      pops.push_back(pop);
      maxRmsds.push_back(maxRmsd);
      aveRmsds.push_back(aveRmsd);
      stdRmsds.push_back(stdRmsd);

      members.clear();
    }

    // print stats
    string statsFn = "stats.macro.dat";
    ofstream statsF(statsFn.c_str());
    if(!statsF.is_open()) {
      cout << "ERROR: could not open file " << statsFn << endl;
      throw -1;
    }
    for(int macro=0; macro<numMacro; macro++) {
      statsF << centers[macro] << " " << pops[macro] << " ";
      statsF << maxRmsds[macro] << " " << aveRmsds[macro] << " ";
      statsF << stdRmsds[macro] << endl;
    }
    statsF.close();
  }
  catch(...) {
    cout << "Terminated due to error." << endl;
    cleanup(generators);
    return 1;
  }

  return 0;
}

