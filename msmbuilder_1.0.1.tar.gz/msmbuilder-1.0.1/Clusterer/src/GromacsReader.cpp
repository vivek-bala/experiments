/************************************************************/
/* GromacsReader.cpp
/* 
/* Class for reading in Gromacs data. Inherits Reader.
/*
/* Please reference
/* GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble
/* simulations and Markov state models to identify conformational states.
/* 
/* Written by Gregory R. Bowman
/* Biophysics Program, Stanford Un iversity
/* Pande Group
/* 11/14/2008
/*
/* Copyright (C) 2008  Stanford University
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU General Public License as published by
/* the Free Software Foundation; either version 2 of the License, or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful,
/* but WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU General Public License for more details.
/*
/* You should have received a copy of the GNU General Public License
/* along with this program; if not, write to the Free Software
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
/*
/************************************************************/
/* TODO:
/* 
/************************************************************/
/* CHANGE LOG:
/*
/************************************************************/
#include<cmath>
#include<iostream>
#include<fstream>
#include<string>
#include "Conformation.h"
#include "GromacsReader.h"

// include C code from Gromacs for reading trajectories
extern "C" {
#include "xtcio.h"
}

using namespace std;

/************************************************************/
/* GromacsReader()
/*   Constructor
/* Arguemtns:
/*   None
/* Return:
/*   None
/************************************************************/
GromacsReader::GromacsReader() {
  trajListFn = string("trajlist");
  atomIndicesFn = string("atom_indices");
  atomIndices = NULL;
  nAtoms = 0;
  trajDir = "trajectories";
  xtcSize = 0;
  nSubSample = 1;
}

/************************************************************/
/* GromacsReader()
/*   Constructor
/* Arguemtns:
/*   trajFn = name of file listing the trajectories
/*   atomFn = name of file listing the atom indices to use
/* Return:
/*   None
/************************************************************/
GromacsReader::GromacsReader(string trajFn, string atomFn) {
  trajListFn = trajFn;
  atomIndicesFn = atomFn;
  atomIndices = NULL;
  nAtoms = 0;
  trajDir = "trajectories";
  xtcSize = 0;
  nSubSample = 1;
}

/************************************************************/
/* ~GromacsReader()
/*   Destructor, deletes array of atom indices.
/* Arguemtns:
/*   None
/* Return:
/*   None
/************************************************************/
GromacsReader::~GromacsReader() {
  delete[] atomIndices;
}

/************************************************************/
/* getNumAtoms()
/*   Return the number of atoms will use in clustering.
/* Arguemtns:
/*   None
/* Return:
/*   number of atoms will use in clustering (int)
/************************************************************/
int GromacsReader::getNumAtoms() {
  return nAtoms;
}

/************************************************************/
/* getData()
/*   Read the xtc files corresponding to each trajectory and return all
/*   the conformations as a vector.
/* Arguemtns:
/*   vector<Element*> &confs = vector of pointers to 
/*    conformations that will be filled in by this function
/*   bool dontIgnore = if true then don't ignore the last snapshot
/*    of each xtc file
/* Return:
/*   None
/************************************************************/
void GromacsReader::getData(vector<Element*> &confs, int dontIgnore=0) {
  cout << "Reading data." << endl;

  if(nAtoms == 0) {
    cout << " ERROR: no atom indices were specified.  The atom index file may not have been specified or read." << endl;
    throw -1;
  }

  // first read through trajecotry and xtc file lists and reserve enough space 
  // for all the data that will go into the confs vector
  int expectedNumConf = getSizeData(dontIgnore);
  // reserve needed space.
  // add current size to expectedNumConf so can call this function repeatedly 
  // using different traj list files and concatenate all together all the data 
  // together
  confs.reserve(confs.size() + expectedNumConf);

  // print expected total number confs and expected total size (includes and confs/space
  // already allocated, unlike similar code in getSizeData())
  cout << " Expecting a total of " << confs.capacity() << " conformations." << endl;
  // expected size in memory has three parts:
  //  1) unsigned int for size of all Conformations (ignore this)
  //  2) 3 unsigned ints for the IDs of each Conformation
  //  3) 3*nAtoms floats for coordinates of each Conformation
  double bytesPerGB = 1073741824.0;
  double confsPerBytePerGB = confs.capacity() / bytesPerGB;
  double bytesPerConf = 3*nAtoms*sizeof(float) + 3*sizeof(unsigned int);
  double numGB = bytesPerConf * confsPerBytePerGB;
  cout << "  Will take " << numGB << " GB of memory." << endl;

  // when there are multiple trajlist files want trajID relative to 
  // concatenation of them. 
  // so store offset to be used when determining new trajID.
  // offset is one more than trajID of last conformation have at present.
  int trajIDOffset = 0;
  if(confs.size() > 0)
    trajIDOffset = ((Conformation*)(confs.back()))->trajID + 1;

  // now actually read in the data.
  // open the traj list file
  ifstream trajListF(trajListFn.c_str());
  if(!trajListF.is_open()) {
    cout << " ERROR: traj list file " << trajListFn << " could not be opened." << endl;
    throw -1;
  }

  cout << "Reading trajectories listed in " << trajListFn << endl;

  // iterate over trajectories in traj list
  string trajFn;
  int curTrajNum = 0;
  while(trajListF >> trajFn) {
    // get traj file
    trajFn = trajDir + "/" + trajFn;
    ifstream trajF(trajFn.c_str());
    if(!trajF.is_open()) {
      cout << " WARNING: traj file " << trajFn << " could not be opened." << endl;
      cout << "  Skipping this trajectory." << endl;
      continue;
    }

    // iterate over xtc files in traj adding conformations to confs
    unsigned int xtcID = 0;
    int relativeSSID = 0;  // snapshot ID relative entire trajectory and not counting repeated data
    string xtcFn;
    while(trajF >> xtcFn) {
      xtcFn += ".xtc";
      cout << "  Reading " << xtcFn << endl;
      char charXtcFn[1000];
      strcpy(charXtcFn, xtcFn.c_str());
      t_fileio *xtcF = open_xtc(charXtcFn, "r");
      int xtcNAtoms, step;
      real time;
      matrix box;
      rvec *x=NULL;
      real prec;
      gmx_bool bOK;
      real prevTime=-50.0;
      float centroid[3];
      vector<real> allTimes;  // all times stored so far
      allTimes.reserve(xtcSize);

      // read xtc file
      int ssID = 0;  // snapshot ID (or index) relative to this xtc file, counts repeated data
      read_first_xtc(xtcF,&xtcNAtoms,&step,&time,box,&x,&prec,&bOK);
      do {
        // We want to ensure that the last snapshot with a given timestamp is 
        // used in order to ensure continuity.  Multiple snapshots with the 
        // same time occur when the client stops and then restarts at a 
        // checkpoint.
        // If a jump backwards in time is found then the overlapping region
        // is dropped and then subsequent snapshots are accumulated as normal.
        if(time <= prevTime) {
          real finalTime = allTimes.back();
          while(time <= finalTime) {
            allTimes.pop_back();
            relativeSSID--;

            // be careful to nly drop snapshots if there is one for current time
            if(nSubSample == 1 || relativeSSID%nSubSample == 0) {
              confs.pop_back();
            }

            // break out of loop if no more data left for this xtc file
            if(allTimes.empty()) 
              break;

            finalTime = allTimes.back();
          }
        }

        // store current time
        allTimes.push_back(time);
        prevTime = time;

        // create new conformation if appropriate
        if(nSubSample == 1 || relativeSSID%nSubSample == 0) {
          float *pos = new float[3*nAtoms];
          Conformation *conf = new Conformation(trajIDOffset+curTrajNum, xtcID, ssID, pos);

          // pick out the atoms that we want to include in our rmsd computation
          // and concurrently find their centroid and remove it so its at origin
          int atomInd = 0;
          for(int k=0; k<3; k++) {
            centroid[k]=0;
          }
          for(int i=0; i<nAtoms; i++) {
            for(int k=0; k<3; k++) {
              atomInd = k*nAtoms + i;
              conf->pos[atomInd] = (float)x[atomIndices[i]][k];
              centroid[k] += conf->pos[atomInd];
            }
          }
          for(int k=0; k<3; k++) {
              centroid[k] /= nAtoms;
          }
          for(int i=0; i<nAtoms; i++) {
            for(int k=0; k<3; k++) {
              atomInd = k*nAtoms + i;
              conf->pos[atomInd] -= centroid[k];
            }
          }

          // add to list of conformations
          confs.push_back(conf);
        }

        relativeSSID++;
        ssID++;
      } while(read_next_xtc(xtcF,xtcNAtoms,&step,&time,box,x,&prec,&bOK));

      // as long as dontIgnore is false,
      // leave off last snapshot of every trajectory so don't double count,
      // this is because last snapshot for traj i is first snapshot of traj i+1.
      // Can't just drop a snapshot at end of each xtc file because may not
      // actually have stored last snapshot because of subsampling.
      if(!dontIgnore) {
        if(relativeSSID%(xtcSize-1) == 1 && (relativeSSID-1)%nSubSample == 0) {
          confs.pop_back();
        }
        relativeSSID--;
      }

      xtcID++;
      if(x != NULL)
        free(x); // use free instead of delete since initialized by malloc in gromacs
      close_xtc(xtcF);

      // error if didn't find at least xtcSize snapshots
      if(ssID < xtcSize) {
        cout << "  WARNING: have fewer than " << xtcSize << " snapshots in " << xtcFn << endl;
        cout << "   Truncating trajectory." << endl;
        break;
      }

    }

    curTrajNum++;
    trajF.close();
  }

  trajListF.close();

  cout << "Done reading files." << endl;
}

/************************************************************/
/* getTempData()
/*   Read the temperatures indices corresponding to each trajectory 
/*   and return all of them as a vector.
/* Arguemtns:
/*   vector<int> &temps = vector of temperature indices
/*    that will be filled in by this function
/* Return:
/*   None
/************************************************************/
void GromacsReader::getTempData(vector<int> &temps) {
  cout << "Reading temperature data." << endl;

  if(nAtoms == 0) {
    cout << " ERROR: no atom indices were specified.  The atom index file may not have been specified or read." << endl;
    throw -1;
  }

  // open the traj list file
  ifstream trajListF(trajListFn.c_str());
  if(!trajListF.is_open()) {
    cout << " ERROR: traj list file " << trajListFn << " could not be opened." << endl;
    throw -1;
  }

  cout << "Reading trajectories listed in " << trajListFn << endl;

  // iterate over trajectories in traj list
  string trajFn;
  int curTrajNum = 0;
  while(trajListF >> trajFn) {
    // get traj file
    trajFn = trajDir + "/" + trajFn;
    ifstream trajF(trajFn.c_str());
    if(!trajF.is_open()) {
      cout << " WARNING: traj file " << trajFn << " could not be opened." << endl;
      cout << "  Skipping this trajectory." << endl;
      continue;
    }

    // iterate over temperature files in traj adding temp indices to temps
    string tempFn;
    int tempNum = 0;
    while(trajF >> tempFn) {
      tempFn += ".T.dat";
      cout << "  Reading " << tempFn << endl;
      ifstream tempF(tempFn.c_str());
      if(!tempF.is_open()) {
        cout << " WARNING: temperature file " << tempFn << " could not be opened." << endl;
        throw -1;
      }

      // read temperature file
      int temp;
      while(tempF >> temp) {
        if(tempNum%nSubSample == 0)
          temps.push_back(temp);
        tempNum++;
      }

      tempF.close();
    }

    curTrajNum++;
    trajF.close();
  }

  trajListF.close();

  cout << "Done reading temperature files." << endl;
}

/************************************************************/
/* getSizeData()
/*   Get the expected number of data points and print how many GB
/*   this will take in memory.
/* Arguemtns:
/*   bool dontIgnore = if true then don't ignore the last snapshot
/*    of each xtc file
/* Return:
/*   Expected number of data points (int).
/************************************************************/
int GromacsReader::getSizeData(int dontIgnore=0) {
  cout << "Getting expected size data will take in memory." << endl;

  int expectedNumConf = 0;

  // open the traj list file
  ifstream trajListF(trajListFn.c_str());
  if(!trajListF.is_open()) {
    cout << " ERROR: traj list file " << trajListFn << " could not be opened." << endl;
    throw -1;
  }

  // iterate over trajectories in traj list
  string trajFn;
  unsigned int curTrajNum = 0;
  while(trajListF >> trajFn) {
    // get traj file
    int expectedNumXtc = 0;
    trajFn = trajDir + "/" + trajFn;
    ifstream trajF(trajFn.c_str());
    if(!trajF.is_open()) {
      cout << " WARNING: traj file " << trajFn << " could not be opened." << endl;
      cout << "  Skipping this trajectory." << endl;
      continue;
    }

    // count number xtc files in trajectory
    string fn;
    expectedNumXtc = 0;
    while(trajF >> fn)
      expectedNumXtc++;

    // without subsampling will get xtcSize-1 snapshots/xtc because drop last 
    // snapshot of each trajectory since identical to first snapshot of next 
    // xtc file and don't want to double count (dontIgnore option turns this
    // behavior off so uses all snapshots)..
    // divide by nSubSample to account for subsampling.
    if(!dontIgnore)
      expectedNumConf += ceil( ((float)(expectedNumXtc * (xtcSize-1))) / nSubSample );
    else
      expectedNumConf += ceil( ((float)(expectedNumXtc * xtcSize)) / nSubSample );

    trajF.close();
  }
  trajListF.close();

  // print expected number confs and expected size
  cout << " Expecting " << expectedNumConf << " conformations from trajectory list " << trajListFn << "." << endl;
  // expected size in memory has three parts:
  //  1) unsigned int for size of all Conformations
  //  2) 3 unsigned ints for the IDs of each Conformation
  //  3) 3*nAtoms floats for coordinates of each Conformation
  double bytesPerGB = 1073741824.0;
  double confsPerBytePerGB = expectedNumConf / bytesPerGB;
  double bytesPerConf = 3*nAtoms*sizeof(float) + 3*sizeof(unsigned int);
  double numGB = bytesPerConf * confsPerBytePerGB;
  cout << "  Will take " << numGB << " GB of memory." << endl;

  return expectedNumConf;
}

/************************************************************/
/* readAtomIndices()
/*   Read in an index file with format "nAtoms index1 index2...".
/*   All elements in the file should be separated by spaces and indices 
/*   should start with 1.  Internally the numbering will be altered to
/*   start with 0.
/* Arguemtns:
/*   None
/* Return:
/*   None
/************************************************************/
void GromacsReader::readAtomIndices() {
  cout << "Reading atom indices from " << atomIndicesFn << endl;
  ifstream indexFile(atomIndicesFn.c_str());
  if(!indexFile.is_open()) {
    cout << " ERROR: atom index file " << atomIndicesFn << " could not be opened." << endl;
    throw -1;
  }
  indexFile >> nAtoms;
  atomIndices = new int[nAtoms];
  for(int i=0; i<nAtoms; i++){
    // error if have reached end of file, if so have error
    if(indexFile.peek() == EOF) {
      cout << " ERROR: have less than " << nAtoms << " atoms in " << atomIndicesFn << endl;
      throw -1;
    }

    indexFile >> atomIndices[i];

    // convert from 1 to n numbering to 0 to n-1 numbering
    atomIndices[i]--;
  }
  indexFile.close();
}

/************************************************************/
/* setNSubSample()
/*   Set to only store every nth snapshot.
/* Arguemtns:
/*   int n = only store every nth snapshot
/* Return:
/*   None
/************************************************************/
void GromacsReader::setNSubSample(int n) {
  if(n <= 0) {
    cout << "ERROR: nSubSample must be greater than 0." << endl;
    throw -1;
  }

  nSubSample = n;
}

/************************************************************/
/* setXtcSize()
/*   Specify #snapshots to expect.  For safety should set to 1+#snapshots
/*   in an xtc file.
/* Arguemtns:
/*   int s = #snapshots in an xtc file
/* Return:
/*   None
/************************************************************/
void GromacsReader::setXtcSize(int s) {
  if(s <= 0) {
    cout << "ERROR: xtcSize must be greater than 0." << endl;
    throw -1;
  }

  xtcSize = s;
}

