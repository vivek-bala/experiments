/************************************************************/
/* KCenterClusterer.cpp
/* 
/* Class for doing k-center clustering. Inherits Clusterer.
/*
/* Please reference
/* GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble
/* simulations and Markov state models to identify conformational states.
/* 
/* Written by Gregory R. Bowman
/* Biophysics Program, Stanford Un iversity
/* Pande Group
/* 11/14/2008
/*
/* Copyright (C) 2008  Stanford University
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU General Public License as published by
/* the Free Software Foundation; either version 2 of the License, or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful,
/* but WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU General Public License for more details.
/*
/* You should have received a copy of the GNU General Public License
/* along with this program; if not, write to the Free Software
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
/*
/************************************************************/
/* TODO:
/* 
/************************************************************/
/* CHANGE LOG:
/*
/************************************************************/
#include<cfloat>
#include<fstream>
#include<iostream>
#include<sstream>
#include "KCenterClusterer.h"

using namespace std;

/************************************************************/
/* KCenterClusterer()
/*   Constructor
/* Arguemtns:
/*   None
/* Return:
/*   None
/************************************************************/
KCenterClusterer::KCenterClusterer() {
  distMetric = NULL;
  genDir = "generators";
}

/************************************************************/
/* KCenterClusterer()
/*   Constructor
/* Arguemtns:
/*   DistanceMetric *dm = distance metric to use for computing distances
/*    between Elements.
/* Return:
/*   None
/************************************************************/
KCenterClusterer::KCenterClusterer(DistanceMetric *dm) {
  distMetric = dm;
  genDir = "generators";
}

/************************************************************/
/* assign()
/*   Assign data points to a set of known generators.
/* Arguemtns:
/*  vector<Element*> &data = data to assign to generators
/*  vector<float> &distances = vector of distances between each data point and
/*    the generator it gets assigned to, filled in by this function.
/*  vector<float> &assignments = vector of generator indices each data point
/*    was assigned to, filled in by this function.
/* Return:
/*   None
/************************************************************/
void KCenterClusterer::assign(vector<Element*> &data, vector<float> &distances, vector<int> &assignments) {
  cout << "Doing assign" << endl;

  if(data.size() == 0) {
    cout << "ERROR: no data supplied to k-center clusterer." << endl;
    throw -1;
  }
  if(generators.size() == 0) {
    cout << "ERROR: no generators." << endl;
    throw -1;
  }

  // initializes output vectors
  distances.clear();
  distances.resize(data.size(), FLT_MAX); // fill in with maximum possible value
  assignments.clear();
  assignments.resize(data.size(), 0);
  cout << " Initialized variables" << endl;

  // loop over data points finding closest generator for each
  for(int g=0; g<generators.size(); g++) {
    cout << " Assigning to generator " << g << endl;

    for(int d=0; d<data.size(); d++) {
      float dist = distMetric->getDist(generators[g], data[d]);

      // if point d is closer to curGen than previous one, then assign to curGen
      if(dist < distances[d]) {
        assignments[d] = g;
        distances[d] = dist;
      }
    }
  }

  cout << "Done writin assignments." << endl;
}

/************************************************************/
/* cluster()
/*   Clust a set of data.
/* Arguemtns:
/*  vector<Element*> &data = data to assign to generators
/*  int k = number of clusters to generate
/*  int seed = index of generator of first cluster (no clever way to choose this that I'm aware of so should always use 0)
/*  vector<float> &distances = vector of distances between each data point and
/*    the generator it gets assigned to, filled in by this function.
/*  vector<float> &assignments = vector of generator indices each data point
/*    was assigned to, filled in by this function.
/* Return:
/*   None
/************************************************************/
void KCenterClusterer::cluster(vector<Element*> &data, int k, int seed, vector<float> &distances, vector<int> &assignments) {
  cout << "Doing k-center clustering with k=" << k << "." << endl;

  if(data.size() == 0) {
    cout << "ERROR: no data supplied to k-center clusterer." << endl;
    throw -1;
  }
  if(k <= 0) {
    cout << "ERROR: k must be greater than 0." << endl;
    throw -1;
  }
  if(data.size() < k) {
    cout << "ERROR: number of desired clusters is greater than number of data points." << endl;
    throw -1;
  }
  if(seed < 0) {
    cout << "ERROR: seed must be greater than or equal to 0." << endl;
    throw -1;
  }

  // write number of generators to file
  string fn = genDir + "/numGens";
  ofstream f(fn.c_str());
  if(!f.is_open()) {
    cout << " ERROR: could not open file " << fn << endl;
    throw -1;
  }
  f << k;
  f.close();

  // initializes output vectors
  distances.clear();
  distances.resize(data.size(), FLT_MAX);
  assignments.clear();
  assignments.resize(data.size(), 0);

  // first generator is always data point corresponding to seed
  generators.clear();
  generators.reserve(k);
  int curGen = seed;
  cout << " Initialized variables." << endl;

  for(int g=0; g<k; g++) {
    float maxDist = -1;
    int newGen;
    cout << " Getting generator " << g << endl;

    // store current generator
    generators.push_back(data[curGen]);

    for(int d=0; d<data.size(); d++) {
      float dist = distMetric->getDist(generators[g], data[d]);

      // if point d is closer to curGen than previous one, then assign to curGen
      if(dist < distances[d]) {
        assignments[d] = g;
        distances[d] = dist;
      }

      // keep track of point furthest from current generator.
      // furthest point will become next generator.
      if(distances[d] > maxDist) {
        newGen = d;
        maxDist = distances[d];
      }
    }

    // move on to new generator
    curGen = newGen;
  }

  cout << "Done clustering." << endl;
}

/************************************************************/
/* readGenerators()
/*   Read in generators from genDir directory
/* Arguemtns:
/*   vector<Element*> &gens = vecot of Elements already initialized to 
/*    correct type (e.g. a child of Element).  Must be right size, can 
/*    get size from numGens file in genDir directory.
/* Return:
/*   None
/************************************************************/
void KCenterClusterer::readGenerators(vector<Element*> &gens) {
  generators = gens;
  for(int g=0; g<generators.size(); g++) {
    stringstream converter;
    converter << g;
    string num;
    converter >> num;
    string fn = genDir + "/gen" + num;
    generators[g]->read(fn);
  }
}

/************************************************************/
/* setDistMetric()
/*   Set the distMetirc to a new DistanceMetric.
/* Arguemtns:
/*   DistanceMetric *dm = distance metric to use for computing distances
/*    between Elements.
/* Return:
/*   None
/************************************************************/
void KCenterClusterer::setDistMetric(DistanceMetric *dm) {
  distMetric = dm;
}

/************************************************************/
/* setGenDir()
/*   Set the genDir, where generators are read/written to.
/* Arguemtns:
/*   string fn = name of generator directory
/* Return:
/*   None
/************************************************************/
void KCenterClusterer::setGenDir(string fn) {
  genDir = fn;
}

/************************************************************/
/* writeGenerators()
/*   Write generators to genDir directory.
/* Arguemtns:
/*   None
/* Return:
/*   None
/************************************************************/
void KCenterClusterer::writeGenerators() {
  for(int g=0; g<generators.size(); g++) {
    stringstream converter;
    converter << g;
    string num;
    converter >> num;
    string fn = genDir + "/gen" + num;
    generators[g]->write(fn);
  }
}



