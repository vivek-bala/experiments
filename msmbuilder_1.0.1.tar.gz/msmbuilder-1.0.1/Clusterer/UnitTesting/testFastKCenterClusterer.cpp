#include<fstream>
#include<iostream>
#include "Conformation.h"
#include "GromacsReader.h"
#include "FastKCenterClusterer.h"
#include "RMSDist.h"

using namespace std;

int main(int argc, const char *argv[]) {
  // read in test data
  vector<Element*> confs;
  GromacsReader gr;
  gr.setXtcSize(501);
  gr.readAtomIndices();
  gr.setNSubSample(500);
  gr.getData(confs, false);
  int nAtoms = gr.getNumAtoms();

  // set number of atoms for all Conforations
  Conformation::setNAtoms(nAtoms);

  cout << "Size of data " << confs.size() << endl;

  RMSDist rd(nAtoms, true, false);

  // cluster the data into a single cluster
  FastKCenterClusterer clusterer(&rd);
  int k=1, seed=0;
  vector<float> distances;
  vector<int> assignments;
  clusterer.cluster(confs, k, seed, distances, assignments);
  clusterer.writeGenerators();

  // print out distances and make sure match RMSD to first frame
  cout << "RMSDs to cluster centers." << endl;
  for(unsigned int i=0; i<confs.size(); i++) {
    cout << "RMSD: " << distances[i] << endl;
  }

  // cluster into 2 clusters
  FastKCenterClusterer clusterer2(&rd);
  k=2;
  clusterer2.cluster(confs, k, seed, distances, assignments);
  clusterer2.writeGenerators();

  // print distances
  cout << "RMSDs to cluster centers." << endl;
  for(unsigned int i=0; i<confs.size(); i++) {
    cout << "RMSD: " << distances[i] << endl;
  }

  // assign to 2 clusters read from generator files
  cout << "Reading in generators and doing assign" << endl;
  string fn = "generators/numGens";
  int nGen;
  ifstream f(fn.c_str());
  f >> nGen;
  f.close();
  cout << " Found " << nGen << " generators" << endl;
  vector<Element*> gens(nGen);
  for(int g=0; g<nGen; g++)
    gens[g] = new Conformation();
  FastKCenterClusterer clusterer3(&rd);
  clusterer3.readGenerators(gens);
  clusterer3.assign(confs, distances, assignments);
  clusterer3.writeGenerators();

  // print distances
  cout << "RMSDs to cluster centers." << endl;
  for(unsigned int i=0; i<confs.size(); i++) {
    cout << "RMSD: " << distances[i] << endl;
  }

  // cleanup
  for(unsigned int i=0; i<confs.size(); i++) {
    Conformation *currConf = (Conformation*)confs[i];
    delete currConf;
  }
}

