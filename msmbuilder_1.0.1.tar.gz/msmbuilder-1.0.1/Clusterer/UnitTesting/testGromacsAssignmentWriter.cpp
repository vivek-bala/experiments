#include<fstream>
#include<iostream>
#include "GromacsAssignmentWriter.h"
#include "Conformation.h"
#include "GromacsReader.h"
#include "KCenterClusterer.h"
#include "RMSDist.h"

using namespace std;

int main(int argc, const char *argv[]) {
  // read in test data
  vector<Element*> confs;
  GromacsReader gr;
  gr.setXtcSize(501);
  gr.readAtomIndices();
  gr.setNSubSample(500);
  gr.getData(confs, false);
  int nAtoms = gr.getNumAtoms();

  // set number of atoms for all Conforations
  Conformation::setNAtoms(nAtoms);

  cout << "Size of data " << confs.size() << endl;

  RMSDist rd(nAtoms, true, false);

  // cluster the data into two clusters
  KCenterClusterer clusterer(&rd);
  int k=2, seed=0;
  vector<float> distances;
  vector<int> assignments;
  clusterer.cluster(confs, k, seed, distances, assignments);
  clusterer.writeGenerators();

  // print out distances and make sure match RMSD to first frame
  cout << "RMSDs to cluster centers." << endl;
  for(unsigned int i=0; i<confs.size(); i++) {
    cout << "RMSD: " << distances[i] << endl;
  }

  // write assignments
  GromacsAssignmentWriter grw;
  grw.writeData(confs, assignments);

  // cleanup
  for(unsigned int i=0; i<confs.size(); i++) {
    Conformation *currConf = (Conformation*)confs[i];
    delete currConf;
  }
}

