#include<iostream>
#include "Conformation.h"
#include "RMSDist.h"

using namespace std;

int main(int argc, const char *argv[]) {
  // define two systems, each with two atoms, and find rmsd between them
  float *c1, *c2;
  c1 = new float[6];
  c2 = new float[6];

  c1[0] = 0; // x coords
  c1[1] = 0;
  c1[2] = 0; // y coords
  c1[3] = 1;
  c1[5] = 0; // z coords
  c1[6] = 0;

  c2[0] = 0; // x coords
  c2[1] = 0;
  c2[2] = 1; // y coords
  c2[3] = 0;
  c2[5] = 1; // z coords
  c2[6] = 0;

  // set number of atoms for all Conforations
  Conformation::setNAtoms(2);

  Conformation *conf1 = new Conformation(0, 0, 0, c1);
  Conformation *conf2 = new Conformation(0, 0, 0, c2);

  RMSDist rd(2, true, false);

  float d = rd.getDist(conf1, conf2);

  cout << "RMSD: " << d << endl;
}

