# run all the unit tests

import difflib
import os
import os.path
import sys

# set absolute paths to directories needed to run tests
correctResultsDir = os.path.abspath("correct_results")
dataDir = os.path.abspath("data")
resultsDir = os.path.abspath("results")
unitTestDir = os.path.abspath(".")
assignDir = os.path.join(dataDir, "assignments")
generatorDir = os.path.join(dataDir, "generators")

# make sure directories exist
if not os.path.exists(assignDir):
  os.mkdir(assignDir)
if not os.path.exists(generatorDir):
  os.mkdir(generatorDir)

# will store names of all failed tests
failedTests = []

# delete contents of assignments and generators directories so know
# any output is from last program run
def cleanup():
  if os.path.exists(assignDir) and len(os.listdir(assignDir)) != 0:
    cmd = "rm " + os.path.join(assignDir, "*")
    os.system(cmd)
  if os.path.exists(generatorDir) and len(os.listdir(generatorDir)) != 0:
    cmd = "rm " + os.path.join(generatorDir, "*")
    os.system(cmd)

# test whether two files are identical
def isFileSame(fn1, fn2):
  if not os.path.exists(fn1):
    return False
  f = open(fn1, 'r')
  fn1Lines = f.readlines()
  f.close()
  if not os.path.exists(fn2):
    return False
  f = open(fn2, 'r')
  fn2Lines = f.readlines()
  f.close()
  diff = difflib.ndiff(fn1Lines, fn2Lines)

  success = True
  for line in diff:
    if line[0] != " ":
      success = False

  return success

# perform a unit test
def executeTest(testName, cmd, checkOtherFiles=False):
  cleanup()

  # run test
  print "Testing " + testName
  outFn = os.path.join(resultsDir, testName + ".out")
  cmd = os.path.join(unitTestDir, cmd) + " > " + outFn
  print " Running " + cmd
  os.system(cmd) 

  # check output
  print " Checking output"
  correctOutFn = os.path.join(correctResultsDir, testName + ".out")
  if not os.path.exists(correctOutFn):
    print " Test failed because " + correctOutFn + " does not exist."
    failedTests.append(testName)
    return
  success = isFileSame(correctOutFn, outFn)
  if not success:
    failedTests.append(testName)

  # if specified, check assignments and generators directories too
  if success and checkOtherFiles:
    print " Checking assignments and generators"
    correctAssignDir = os.path.join(correctResultsDir, testName, "assignments")
    correctGenDir = os.path.join(correctResultsDir, testName, "generators")

    # compare assignments
    assignSame = True
    for fn in os.listdir(assignDir):
      if fn == ".svn": continue
      correctFn = os.path.join(correctAssignDir, fn)
      outFn = os.path.join(assignDir, fn)
      print correctFn
      assignSame = isFileSame(correctFn, outFn)
      if not assignSame:
        break

    # compare generators
    genSame = True
    for fn in os.listdir(generatorDir):
      if fn == ".svn": continue
      correctFn = os.path.join(correctGenDir, fn)
      outFn = os.path.join(generatorDir, fn)
      genSame = isFileSame(correctFn, outFn)
      if not genSame:
        break

    if not assignSame or not genSame:
      failedTests.append(testName)
      success = False

  if success:
    print " Test successful."
  else:
    print " Test failed."

# clear any old output
cmd = "rm " + os.path.join(resultsDir, "*")
os.system(cmd)

# move into the data directory to run the tests
os.chdir(dataDir)

# test Conformation class
testName = "testConformation"
cmd = "testConformation"
executeTest(testName, cmd, True)

# test RMSDist class
testName = "testRMSDist"
cmd = "testRMSDist"
executeTest(testName, cmd)

# test GromacsReader class
testName = "testGromacsReader1"
cmd = "testGromacsReader 1"
executeTest(testName, cmd)
testName = "testGromacsReader2"
cmd = "testGromacsReader 500"
executeTest(testName, cmd)

# test KCenterClusterer class
testName = "testKCenterClusterer"
cmd = "testKCenterClusterer"
executeTest(testName, cmd, True)

# test FastKCenterClusterer class
testName = "testFastKCenterClusterer"
cmd = "testFastKCenterClusterer"
executeTest(testName, cmd, True)

# test GromacsAssignmentWriter class
testName = "testGromacsAssignmentWriter"
cmd = "testGromacsAssignmentWriter"
executeTest(testName, cmd, True)

# test Clustering fail when no traj list
testName = "testClustNoTrajList"
cmd = "../doFastGromacsClustering"
executeTest(testName, cmd)

# test Clustering fail when unequal number traj lists and atom lists
testName = "testClustUnequalNum"
cmd = "../doFastGromacsClustering -t trajlist -a atom_indices atom_indices_bad"
executeTest(testName, cmd)

# test Clustering fail when xtcSize negative
testName = "testClustNegSize"
cmd = "../doFastGromacsClustering -t trajlist -a atom_indices -x -1"
executeTest(testName, cmd)

# test Clustering fail when not enough atoms
testName = "testClustWrongAtoms"
cmd = "../doFastGromacsClustering -t trajlist -a atom_indices_bad -x 501"
executeTest(testName, cmd)

# test Clustering fail when nSubSample not positive
testName = "testClustSubSample"
cmd = "../doFastGromacsClustering -t trajlist -a atom_indices -x 501 -n 0"
executeTest(testName, cmd)

# test Clustering fail when no traj list exists
testName = "testClustNoTrajListExists"
cmd = "../doFastGromacsClustering -t trajlist_no -a atom_indices -x 501"
executeTest(testName, cmd)

# test Clustering warn when skip missing traj
testName = "testClustMissingTraj"
cmd = "../doFastGromacsClustering -t trajlist_bad -a atom_indices -x 501"
executeTest(testName, cmd, True)

# test Clustering fail when unequal num atoms
testName = "testClustUnequalAtoms"
cmd = "../doFastGromacsClustering -t trajlist trajlist -a atom_indices atom_indices_less -x 501"
executeTest(testName, cmd)

# test Clustering warn when missing snapshots 
testName = "testClustMissingSnapshots"
cmd = "../doFastGromacsClustering -t trajlist -a atom_indices -x 505"
executeTest(testName, cmd, True)

# test Clustering fail when k<=0
testName = "testClustBadK"
cmd = "../doFastGromacsClustering -t trajlist -a atom_indices -x 501 -k 0"
executeTest(testName, cmd)

# test Clustering fail when seed<0
testName = "testClustBadSeed"
cmd = "../doFastGromacsClustering -t trajlist -a atom_indices -x 501 -s -1"
executeTest(testName, cmd)

# test Clustering fail when k > data.size()
testName = "testClustBigK"
cmd = "../doFastGromacsClustering -t trajlist -a atom_indices -x 501 -k 999999999"
executeTest(testName, cmd)

# test Clustering fail when no generator dir
os.system("rm -rf " + generatorDir)
testName = "testClustNoGenDir"
cmd = "../doFastGromacsClustering -t trajlist -a atom_indices -x 501 -n 500"
executeTest(testName, cmd)
os.mkdir(generatorDir)

# test Clustering works
testName = "testClustWorks"
cmd = "../doFastGromacsClustering -t trajlist -a atom_indices -x 505 -n 500 -k 2 -w"
executeTest(testName, cmd, True)

# go back to the unit test directory once done with tests
os.chdir(unitTestDir)

#cleanup()

# print list of tests that failed
if len(failedTests) == 0:
  print "All tests were successful!"
else:
  s = "The following tests failed: "
  for i in range(len(failedTests)-1):
    s += failedTests[i] + ", "
  s += failedTests[len(failedTests)-1]
  print s

