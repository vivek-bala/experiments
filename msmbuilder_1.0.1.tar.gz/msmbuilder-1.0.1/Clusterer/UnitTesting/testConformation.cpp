#include<iostream>
#include<string>
#include "Conformation.h"

using namespace std;

int main(int argc, const char *argv[]) {
  // define a system with two atoms
  float *p;
  p = new float[6];

  p[0] = 0; // x coords
  p[1] = 0;
  p[2] = 0; // y coords
  p[3] = 1;
  p[4] = 0; // z coords
  p[5] = 0;

  // set number of atoms for all Conforations
  Conformation::setNAtoms(2);

  Conformation conf(0, 0, 0, p);

  // write conformation to generators directory
  string fn = "generators/gen0";
  cout << "Writing conformation to " << fn << endl;
  cout << " trajID " << conf.trajID << endl;
  cout << " xtcID " << conf.xtcID << endl;
  cout << " ssID " << conf.ssID << endl;
  cout << " nAtoms: " << conf.getNAtoms() << endl;
  for(unsigned int i=0; i<3*conf.getNAtoms(); i++)
    cout << " pos " << conf.pos[i] << endl;
  conf.write(fn);

  // change conf, will red back in and see if restored next
  conf.trajID = 10;
  cout << "Changed conformation to the following" << endl;
  cout << " trajID " << conf.trajID << endl;
  cout << " xtcID " << conf.xtcID << endl;
  cout << " ssID " << conf.ssID << endl;
  cout << " nAtoms: " << conf.getNAtoms() << endl;
  for(unsigned int i=0; i<3*conf.getNAtoms(); i++)
    cout << " pos " << conf.pos[i] << endl;

  // read Conformation back in
  cout << "Reading conformation from " << fn << endl;
  conf.read(fn);
  cout << " trajID " << conf.trajID << endl;
  cout << " xtcID " << conf.xtcID << endl;
  cout << " ssID " << conf.ssID << endl;
  cout << " nAtoms: " << conf.getNAtoms() << endl;
  for(unsigned int i=0; i<3*conf.getNAtoms(); i++)
    cout << " pos " << conf.pos[i] << endl;
}

