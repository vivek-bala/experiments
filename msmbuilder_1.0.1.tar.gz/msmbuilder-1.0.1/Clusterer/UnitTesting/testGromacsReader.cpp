#include<iostream>
#include "Conformation.h"
#include "GromacsReader.h"
#include "RMSDist.h"

using namespace std;

int main(int argc, const char *argv[]) {
  // get num subsample
  int nSubSample = atoi(argv[1]);

  // read in test data
  vector<Element*> confs;
  GromacsReader gr;
  gr.setXtcSize(501);
  gr.readAtomIndices();
  gr.setNSubSample(nSubSample);
  gr.getData(confs, false);
  int nAtoms = gr.getNumAtoms();

  // set number of atoms for all Conforations
  Conformation::setNAtoms(nAtoms);

  cout << "Size of data " << confs.size() << endl;

  // compute rmsd between first frame and every other frame
  Conformation *frame0 = (Conformation*)confs[0];
  for(unsigned int i=0; i<confs.size(); i++) {
    Conformation *currConf = (Conformation*)confs[i];
    RMSDist rd(nAtoms, true, false);

    float d = rd.getDist(currConf, frame0);

    cout << "RMSD: " << d << endl;
  }

  // cleanup
  for(unsigned int i=0; i<confs.size(); i++) {
    Conformation *currConf = (Conformation*)confs[i];
    delete currConf;
  }
}

