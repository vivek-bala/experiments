Directions:
  Test data is in data/

Tests:
- testRMSDist = just test the RMSDist class
- testGromacsReader = tests GromacsReader and RMSDist

