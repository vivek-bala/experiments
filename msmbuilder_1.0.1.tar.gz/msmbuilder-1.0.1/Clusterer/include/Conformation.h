/************************************************************/
/* Conformation.h
/* 
/* Class for representing a molecular conformation. Inherits Element.
/*
/* Please reference
/* GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble
/* simulations and Markov state models to identify conformational states.
/* 
/* Written by Gregory R. Bowman
/* Biophysics Program, Stanford Un iversity
/* Pande Group
/* 11/14/2008
/*
/* Copyright (C) 2008  Stanford University
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU General Public License as published by
/* the Free Software Foundation; either version 2 of the License, or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful,
/* but WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU General Public License for more details.
/*
/* You should have received a copy of the GNU General Public License
/* along with this program; if not, write to the Free Software
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
/*
/************************************************************/
/* TODO:
/* 
/************************************************************/
/* CHANGE LOG:
/*
/************************************************************/
#ifndef __CONFORMATION_H__
#define __CONFORMATION_H__

#include<vector>
#include "Element.h"

class Conformation: public Element {
  private:
    static unsigned int nAtoms;    // #atoms, only one copy for all Conformations since must be same for all, also saves apce
  public:
    Conformation();
    Conformation(unsigned int tID, unsigned int xID, unsigned int sID, float *p);
    virtual ~Conformation();

    void read(std::string fn);
    void write(std::string fn);

    static int getNAtoms();
    static void setNAtoms(int n);

    unsigned int trajID;  // trajectory ID relative trajlist file (or concatenation of them if have multiple)
    unsigned int xtcID;   // xtcID
    unsigned int ssID;    // snapshot ID, this includes repeated frames so can pull out right snapshot
    float *pos;   // position of atoms, all x coords followed by all y coords followed by al y coords
};

#endif

