/************************************************************/
/* GromacsReader.h
/* 
/* Class for reading in Gromacs data. Inherits Reader.
/*
/* Please reference
/* GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble
/* simulations and Markov state models to identify conformational states.
/* 
/* Written by Gregory R. Bowman
/* Biophysics Program, Stanford Un iversity
/* Pande Group
/* 11/14/2008
*
/* Copyright (C) 2008  Stanford University
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU General Public License as published by
/* the Free Software Foundation; either version 2 of the License, or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful,
/* but WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU General Public License for more details.
/*
/* You should have received a copy of the GNU General Public License
/* along with this program; if not, write to the Free Software
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
/*
/************************************************************/
/* TODO:
/* 
/************************************************************/
/* CHANGE LOG:
/*
/************************************************************/
#ifndef __GROMACSREADER_H__
#define __GROMACSREADER_H__

#include<string>
#include<vector>
#include "Reader.h"

class GromacsReader : public Reader {
  private:
    int *atomIndices;
    int nAtoms;
    int nSubSample; // take every nSubSample'th snapshot
    int xtcSize;  // should be set to one more than the #snapshots in each xtc
    std::string atomIndicesFn;
    std::string trajDir;
    std::string trajListFn;
  public:
    GromacsReader();
    GromacsReader(std::string trajFn, std::string atomFn);
    virtual ~GromacsReader();

    int getNumAtoms();
    void getData(std::vector<Element*> &v, int dontIgnore);
    void getTempData(std::vector<int> &temps);
    int getSizeData(int dontIgnore);
    void readAtomIndices();
    void setNSubSample(int n);
    void setXtcSize(int s);
};

#endif


