/************************************************************/
/* Clusterer.h
/* 
/* Abstract base class for clustering data.
/*
/* Please reference
/* GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble
/* simulations and Markov state models to identify conformational states.
/* 
/* Written by Gregory R. Bowman
/* Biophysics Program, Stanford Un iversity
/* Pande Group
/* 11/14/2008
/*
/* Copyright (C) 2008  Stanford University
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU General Public License as published by
/* the Free Software Foundation; either version 2 of the License, or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful,
/* but WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU General Public License for more details.
/*
/* You should have received a copy of the GNU General Public License
/* along with this program; if not, write to the Free Software
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
/*
/************************************************************/
/* TODO:
/* 
/************************************************************/
/* CHANGE LOG:
/*
/************************************************************/
#ifndef __CLUSTERER_H__
#define __CLUSTERER_H__

#include<string>
#include<vector>
#include "DistanceMetric.h"
#include "Element.h"

class Clusterer {
  protected:
    DistanceMetric *distMetric;
    std::string genDir;
    std::vector<Element*> generators;
  public:
    virtual ~Clusterer() {};

    // assign data to a known set of generators
    virtual void assign() {};

    // cluster a dataset
    virtual void cluster() {};

    // read a set of generators in from files
    virtual void readGenerators(std::vector<Element*> &gens) {};

    // set the generators directory
    virtual void setGenDir(std::string fn) = 0;

    // write the generators to files
    virtual void writeGenerators() {};
};

#endif


