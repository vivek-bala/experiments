/************************************************************/
/* FastKCenterClusterer.h
/* 
/* Class for doing k-center clustering using the triangle inequality
/* to obtain a speedup. Inherits KCenterClusterer.
/*
/* Please reference
/* GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble
/* simulations and Markov state models to identify conformational states.
/* 
/* Written by Gregory R. Bowman
/* Biophysics Program, Stanford Un iversity
/* Pande Group
/* 11/14/2008
*
/* Copyright (C) 2008  Stanford University
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU General Public License as published by
/* the Free Software Foundation; either version 2 of the License, or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful,
/* but WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU General Public License for more details.
/*
/* You should have received a copy of the GNU General Public License
/* along with this program; if not, write to the Free Software
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
/*
/************************************************************/
/* TODO:
/* 
/************************************************************/
/* CHANGE LOG:
/*
/************************************************************/
#ifndef __FASTKCENTERCLUSTERER_H__
#define __FASTKCENTERCLUSTERER_H__

#include<vector>
#include "KCenterClusterer.h"
#include "DistanceMetric.h"
#include "Element.h"

class FastKCenterClusterer : public KCenterClusterer {
  public:
    FastKCenterClusterer();
    FastKCenterClusterer(DistanceMetric *dm);

    void assign(std::vector<Element*> &data, std::vector<float> &distances, std::vector<int> &assignments);
    void cluster(std::vector<Element*> &data, int k, int seed, std::vector<float> &distances, std::vector<int> &assignments);
};

#endif


