/************************************************************/
/* GromacsAssignmentWriter.h
/* 
/* Class for representing a writing assignments of Gromacs data to 
/* micro/macro states. Inherits from AssignmentWriter.
/*
/* Please reference
/* GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble
/* simulations and Markov state models to identify conformational states.
/* 
/* Written by Gregory R. Bowman
/* Biophysics Program, Stanford Un iversity
/* Pande Group
/* 11/14/2008
*
/* Copyright (C) 2008  Stanford University
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU General Public License as published by
/* the Free Software Foundation; either version 2 of the License, or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful,
/* but WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU General Public License for more details.
/*
/* You should have received a copy of the GNU General Public License
/* along with this program; if not, write to the Free Software
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
/*
/************************************************************/
/* TODO:
/* 
/************************************************************/
/* CHANGE LOG:
/*
/************************************************************/
#ifndef __GROMACSASSIGNMENTWRITER_H__
#define __GROMACSASSIGNMENTWRITER_H__

#include<string>
#include<vector>
#include "AssignmentWriter.h"
#include "Conformation.h"
#include "Element.h"
using namespace std;

class GromacsAssignmentWriter : public AssignmentWriter {
  private:
    std::string assignDir;
    std::string trajListFn;
  public:
    GromacsAssignmentWriter();
    GromacsAssignmentWriter(std::string trajFn);
    void writeData(std::vector<Element*> &data, std::vector<int> &assignMicro);
    void writeData(std::vector<Element*> &data, std::vector<int> &assignMicro, std::string mapMicroToMacroFn);
    void writeData(std::vector<Element*> &data, std::vector<int> &assignMicro, std::string mapMicroToMacroFn, int minT, int maxT, std::vector<int> &temps);
};

#endif

