from numpy import conjugate
from scipy import *
from scipy.linalg import norm, svd, det,solve
import scipy.sparse

from numpy import random  # VAV needed for stochastic greedy backtracking

def GetBCommittors(U,F,T0,Equil,maxiter=100000,X0=None,Dense=False):
    """Get the backward committors of the reaction U -> F.  T0 is the transition matrix.  Equil are the equilibrium populations.  If you are have small matrices, it can be faster to use dense linear algebra.  If you don't use dense linear algebra, you might want to specify an initial vector X0 and the maximum number of iterations for controlling the sparse equation solver."""
    A,b,Q0=GetBCommittorsEqn(U,F,T0,Equil)
    if X0!=None:
        Q0=X0

    if Dense==False:
        Q=SolveEqn(A,b,Q0,maxiter)
    else:
        Q=solve(A.toarray(),b)
    return Q

def GetFCommittors(U,F,T0,maxiter=100000,X0=None,Dense=False):
    """Get the backward committors of the reaction U -> F.  T0 is the transition matrix.  Equil are the equilibrium populations.  If you are have small matrices, it can be faster to use dense linear algebra.  If you don't use dense linear algebra, you might want to specify an initial vector X0 and the maximum number of iterations for controlling the sparse equation solver."""
    A,b,Q0=GetFCommittorsEqn(U,F,T0)
    if X0!=None:
        Q0=X0
    if Dense==False:
        Q=SolveEqn(A,b,Q0,maxiter)
    else:
        Q=solve(A.toarray(),b)
    return(Q)
def GetBCommittorsEqn(U,F,T0,Equilibrium):
    """Construct the matrix equations used for finding backwards committors for the reaction U -> F.  T0 is the transition matrix, Equilibruim is the vector of equilibruim populations"""
    n=len(Equilibrium)
    DE=scipy.sparse.lil_diags([Equilibrium],[0],(n,n))
    DEInv=scipy.sparse.lil_diags([1/Equilibrium],[0],(n,n))
    TR=(DEInv.dot(T0.transpose())).dot(DE)
    return(GetFCommittorsEqn(F,U,TR))
def GetFCommittorsEqn(A,B,T0,maxiter=100000):
    """Construct the matrix equations used for finding committors for the reaction U -> F.  T0 is the transition matrix, Equilibruim is the vector of equilibruim populations"""
    n=T0.shape[0]
    T=scipy.sparse.lil_eye((n,n))-T0
    T=T.tolil()
    for a in A:
        T[a,:]=zeros(n)
        T[:,a]=0.0
        T[a,a]=1.0
    for b in B:
        T[b,:]=zeros(n)
        T[:,b]=0.0
        T[b,b]=1.0
    IdB=zeros(n)
    for b in B:
        IdB[b]=1.0
    print ("done with setting up matrices")
    RHS=T0.matvec(IdB)
    for a in A:
        RHS[a]=0.0
    for b in B:
        RHS[b]=1.0
    Q0=ones(n)
    for a in A:
        Q0[a]=0.0
    return(T,RHS,Q0)

def GetFlux(E,F,R,T):
    """Get the flux matrix.  Inputs:  Equilibrium, Forward Comm., Reverse Comm, Transition Matrix"""
    Indx,Indy=T.nonzero()

    n=len(E)
    X=scipy.sparse.lil_matrix((n,n))
    X.setdiag(E*R)

    Y=scipy.sparse.lil_matrix((n,n))
    Y.setdiag(F)
    P=dot(dot(X.tocsr(),T.tocsr()),Y.tocsr())
    P=P.tolil()
    P.setdiag(zeros(n))
    return(P)

def GetNetFlux(E,F,R,T):
    """Returns a (net) matrix Flux where Flux[i,j] is the flux from i to j.

    INPUT
    E - the equilibirum populations
    F - forward committors
    R - backwards committors
    T - transition matrix. 
    """

    n=len(E)
    Flux=GetFlux(E,F,R,T)
    ind=Flux.nonzero()
    NFlux=scipy.sparse.lil_matrix((n,n))
    for k in range(len(ind[0])):
        i,j=ind[0][k],ind[1][k]
        forward=Flux[i,j]
        reverse=Flux[j,i]
        NFlux[i,j]=max(0,forward-reverse)
    return(NFlux)
        
def GreedyBacktrack(A,b,F):
    """Starting at the final state b, work backwards towards the initial set A while trying to find the maximal flux path along the flux matrix F."""
    Finished=False
    ind=b
    Pathway=[]
    Fluxes=[]
    while not Finished:
        print(ind)
        Data=F[:,ind].toarray().flatten()
        ind=argmax(Data)
        Pathway.append(ind)
        Fluxes.append(Data[ind])
        if ind in A:
            Finished=True
    PathFlux=Fluxes[argsort(Fluxes)[0]]
    Pathway.reverse()
    Pathway.append(b)
    print(Fluxes)
    print(PathFlux)
    for i in range(len(Pathway)-1):
        print(Pathway[i],Pathway[i+1])
        F[Pathway[i],Pathway[i+1]]-=PathFlux
    return(Pathway,PathFlux)

def GreedyBacktrackWithPFold(A,b,F,PFold, Verbose=False):
    """Starting at the final state b, work backwards towards the initial set A while trying to find the maximal flux path along the flux matrix F.  This function  enforces the constraint that the PFold value is nonincreasing along the path."""
    Finished=False
    ind=b
    Pathway=[]
    Fluxes=[]
    CurPFold=1.
    while not Finished:
        if Verbose: print(ind)
        Data=F[:,ind].toarray().flatten()
        PFoldInd=where(PFold<CurPFold)
        ind=argmax(Data[PFoldInd])
        ind=PFoldInd[0][ind]
        if Verbose: print(ind,Data[ind])
        Pathway.append(ind)
        Fluxes.append(Data[ind])
        CurPFold=PFold[ind]
        if ind in A:
            Finished=True
    PathFlux=Fluxes[argsort(Fluxes)[0]]
    if Verbose: print(PathFlux)
    Pathway.reverse()
    Pathway.append(b)
    if Verbose: print(Fluxes)
    if Verbose: print(PathFlux)
    for i in range(len(Pathway)-1):
        if Verbose: print(Pathway[i],Pathway[i+1])
        F[Pathway[i],Pathway[i+1]]-=PathFlux
    return(Pathway,PathFlux)

def GreedyBacktrackWithPFoldStochastic(A,b,F,PFold, beta=4.0, Verbose=False):
    """A Stochastic version of GreedyBacktrackWithPFold():
    Instead of always taking the largest-flux path, paths are chosen 
    stochastically according to the normalized distribution P(flux)^beta.

        beta = an inverse temperature (beta must be > 0)

    When beta > 1, the max-flux paths are more heavily weighted, with max-flux
    being the limiting case of beta -> inf.

    When beta < 1, the search is weighted across a more uniform distribution of
    fluxes, with a random search in the limit of beta -> 0

    The default of beta=4.0 worked well in iniial tests
          
    """

    Finished=False
    ind=b
    Pathway=[]
    Fluxes=[]
    CurPFold=1.
    while not Finished:
        if Verbose: print(ind)
        Data=F[:,ind].toarray().flatten()
        PFoldInd=where(PFold<CurPFold)
        # find the probability of taking each path
        DataProb = Data[PFoldInd]**beta
        DataProb = DataProb/DataProb.sum() # normalize
        r = random.rand()
        cumprob = 0.0
        for i in range(DataProb.shape[0]): 
            cumprob += DataProb[i]
            if cumprob > r:
                ind = i
                break 
        #ind=argmax(Data[PFoldInd])
        ind=PFoldInd[0][ind]
        if Verbose: print(ind,Data[ind])
        Pathway.append(ind)
        Fluxes.append(Data[ind])
        CurPFold=PFold[ind]
        if ind in A:
            Finished=True
    PathFlux=Fluxes[argsort(Fluxes)[0]]
    if Verbose: print(PathFlux)
    Pathway.reverse()
    Pathway.append(b)
    if Verbose: print(Fluxes)
    if Verbose: print(PathFlux)
    for i in range(len(Pathway)-1):
        if Verbose: print(Pathway[i],Pathway[i+1])
        F[Pathway[i],Pathway[i+1]]-=PathFlux
    return(Pathway,PathFlux)


def GreedyBacktrackWithPFoldStochasticScrub(A,b,F,PFold, beta=4.0, NScrubs=100, Verbose=False):
    """Like the stochastic version of GreedyBacktrackWithPFoldStochastic(),
    but each next top path is determined by a stochastic "scrub" to try to find the ACTUAL 
    top flux at each step.
    """

    BestPathway = []
    BestPathFlux = 0.0

    for scrub in range(NScrubs):

      Finished=False
      ind=b
      Pathway=[]
      Fluxes=[]
      CurPFold=1.
      while not Finished:
        if Verbose: print(ind)
        Data=F[:,ind].toarray().flatten()
        PFoldInd=where(PFold<CurPFold)
        # find the probability of taking each path
        DataProb = Data[PFoldInd]**beta
        DataProb = DataProb/DataProb.sum() # normalize
        r = random.rand()
        cumprob = 0.0
        for i in range(DataProb.shape[0]):
            cumprob += DataProb[i]
            if cumprob > r:
                ind = i
                break
        #ind=argmax(Data[PFoldInd])
        ind=PFoldInd[0][ind]
        if Verbose: print(ind,Data[ind])
        Pathway.append(ind)
        Fluxes.append(Data[ind])
        CurPFold=PFold[ind]
        if ind in A:
            Finished=True
      PathFlux=Fluxes[argsort(Fluxes)[0]]
      if Verbose: print(PathFlux)
      Pathway.reverse()
      Pathway.append(b)
      if Verbose: print(Fluxes)
      if Verbose: print(PathFlux)

      if PathFlux > BestPathFlux:
          BestPathway = Pathway
          BestPathFlux = PathFlux
          print 'Found better path on scrub', scrub, Pathway, BestPathFlux

    for i in range(len(BestPathway)-1):
      if Verbose: print(BestPathway[i],BestPathway[i+1])
      F[BestPathway[i],BestPathway[i+1]]-=BestPathFlux

    return(BestPathway,BestPathFlux)

    
def AddPathwaysToMatrix(F,Pathway,PathFlux, Verbose=False):
    """Given a matrix F that is to contain a subset of the fluxes, add Pathway with flux PathFlux."""
    for k in range(len(Pathway)):
        if Verbose: print(k)
        P=Pathway[k]
        Flux=PathFlux[k]
        for i in range(len(P)-1):
            F[P[i],P[i+1]]+=Flux
            
def SolveEqn(A,b,X,nIter):
    """This is a simple Jacobi solver for the equation Ax=b.  X is the starting vector, nIter is the number of iterations."""
    n=A.shape[0]
    D=scipy.sparse.lil_diags([A.diagonal()],[0],(n,n))
    R=A-D
    DI=scipy.sparse.lil_diags([1/A.diagonal()],[0],(n,n))
    DI=DI.tocsr()
    R=R.tocsr()
    for i in range(nIter):
        X=DI.matvec((b-R.matvec(X)))
    return(X)
    
