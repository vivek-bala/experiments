#===============================================================================
# AdaptiveSampling.py
#
# This scripts takes as input a transition count matrix, and the number of new 
# trajectories that the user would like to simulate. The output is the file 
# 'startStates.dat', where each row contains an index for one state, followed by 
# the number of simulations that should be started from the state, according to the
# algorithm developed by Singhal (see reference below). The method aims to minimize the
# uncertainty of the largest non-unit eigenvalue of the transition matrix.
#
# Please reference
# N Singhal Hinrichs, and VS Pande. J. Chem. Phys. 2007. Calculation of the 
# distribution of eigenvalues and eigenvectors in Markovian State Models for
# molecular dynamics.
#
# Written 10/1/10 by
# Dan Ensign <densign@mail.utexas.edu>
# Gregory Bowman <gregoryrbowman@gmail.com>
# Sergio Bacallado <sergiobacallado@gmail.com>
# Stanford University
# Pande group
#
# Copyright (C) 2008  Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#===============================================================================
# TODO:
#===============================================================================
# GLOBAL IMPORTS:
from numpy import *
from scipy import matrix
from scipy.io import mmread
from scipy.sparse import *
from optparse import OptionParser
import sys
#===============================================================================
# LOCAL IMPORTS:
#===============================================================================
from ssaTools import *
from ssaCalculator import ssaCalculator
import license

# define options
usage = "%prog [options]"
parser = OptionParser(usage=usage)
# Count matrix
parser.add_option("-c", "--countMatrix", dest="C_ref_fn", action="store", type="string", default="tCount.macro.dat", help="The transition counts observed thus far in simulation. If the file ends in .mtx, it assumes it is in Matrix Market format, otherwise it assumes this is a text file with one row of the count matrix per line [default: tCount.macro.dat]")
# Determines whether we sample from all states proportionally to their variance contribution
# or from the single state with the highest contribution to the variance of the second eigenvalue.
parser.add_option("-f", "--fromAll", dest="fromAll", action="store_true", default=False, help="Set this flag if you would like to sample from all states, in proportion to each state's predicted reduction in the variance of the largest non-unit eigenvalue of the transition matrix. Otherwise, the algorithm samples only from the state that is predicted to cause the largest reduction.")
# Number of simulations
parser.add_option("-n", "--nSims", dest="nSims", action="store", type="int", default=100, help="The number of new simulations to be started in this round of adaptive sampling [default: 100]")

# parse option
license.printLicense()
(options, args) = parser.parse_args()
print sys.argv

lagTime = 1  

# read in reference count matrix to be used in updating prior
C_ref = None
if "mtx" in options.C_ref_fn:
  C_ref = mmread(options.C_ref_fn).toarray()
else:
  C_ref = loadtxt(options.C_ref_fn)
nStates = C_ref.shape[0]
p_row = array(C_ref.sum(axis=1)).flatten()
totalCounts = p_row.sum()
print "total counts: %d" % totalCounts
mat = matrix(C_ref, dtype=float64)

# Compute contributions to the variance of the second largest eigenvalue from
# each row of the transition matrix.
if mat.shape[0] > 1:
    print "Using largest eig val"
    # The third parameter in the following function is the uniform parameter of the Dirichlet prior.
    # by default, it is set to alpha=1/nStates. 
    calc = ssaCalculator( 1, mat, 1.0/nStates, evalList=[1], nNewSamples=options.nSims)
    calc.displayContributions( bling=True )
    print "State to sample more %d" % calc.stateToSampleMore

# write output: the number of new simulations to be started from each state.
startStateList = {}
if mat.shape[0] > 1:
    if options.fromAll:
      nOut = 0
      for i in range(len(calc.varianceContributions[0][:,9]	)):
        if calc.varianceContributions[0][i,9] > 0:
          startStateList[i] = round(calc.varianceContributions[0][i,9])
          nOut += startStateList[i]

      # make sure get desired number of sims
      if nOut < options.nSims:
        nHave = nOut
        nOut = 0
        for i in startStateList.keys():
          startStateList[i] = round(float(options.nSims)/nHave*startStateList[i])
          nOut += startStateList[i]
        i = 0
        while nOut < options.nSims:
          startStateList[startStateList.keys()[i]] += 1
          nOut += 1
          i += 1
          if i >= len(startStateList):
            i = 0
    else:
      startStateList[calc.stateToSampleMore] = options.nSims
    print startStateList
    f = open("startStates.dat", 'w')
    for i in startStateList.keys():
      f.write("%d %d\n" % (i, startStateList[i]))
    f.close()


