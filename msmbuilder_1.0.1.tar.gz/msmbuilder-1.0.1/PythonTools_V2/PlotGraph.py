from scipy import unique
import scipy.sparse
import pygraph
import gv

def GetScaleFunctions(NodeWeights,Edges,MaxNodeSize=20.0,MinNodeSize=5.0,MaxEdgeSize=1.0,MinEdgeSize=0.1):
    """Get Functions to help scale the node and edge sizes appropriately."""
    ind=Edges.nonzero()
    NodeList=[]
    EdgeList=[]
    for k in range(len(ind[0])):
        i=ind[0][k]
        j=ind[1][k]
        NodeList.append(NodeWeights[i])
        NodeList.append(NodeWeights[j])
        EdgeList.append(Edges[i,j])
    NodeList=unique(NodeList)
    EdgeList=unique(EdgeList)
    M1=max(NodeList)
    m1=min(NodeList)
    print("MAX,min",M1,m1)
    a1=(MaxNodeSize-MinNodeSize)/(M1-m1)
    b1=MaxNodeSize-a1*M1
    f1=lambda x: a1*x+b1

    M2=max(EdgeList)
    m2=min(EdgeList)
    a2=(MaxEdgeSize-MinEdgeSize)/(M2-m2)
    b2=MaxEdgeSize-a2*M2
    f2=lambda x: a2*x+b2
    return(f1,f2)
    

        

    
def PlotModel(Nodes,Edges,Filename,NodeWeights=None,NodeImages=None,WeightEdges=True,EdgeEpsilon=None,NodeFontScale=1.,EdgeFontScale=1.,ArrowScale=1.,TrimEmptyNodes=False,DotFilename=None,MaxNodeSize=1.0,MinNodeSize=.1,MaxEdgeSize=1.0,MinEdgeSize=0.1,UseScalingFunctions=True,Colors=None,Labels=None):
    """Create a dotfile and svg representation of a TPT flux network."""
    dig=pygraph.classes.Digraph.digraph()
    dig.add_nodes(Nodes)
    dig.__setattr__("rankdir","LR")

    if UseScalingFunctions==True:
        f1,f2=GetScaleFunctions(NodeWeights,Edges,MaxNodeSize=MaxNodeSize,MinNodeSize=MinNodeSize,MaxEdgeSize=MaxEdgeSize,MinEdgeSize=MinEdgeSize)
    else:
        f1=lambda x: x
        f2=lambda x: x

    for j in range(len(Nodes)):
        i=Nodes[j]
        dig.add_node_attribute(i,["fixedsize","true"])
        if NodeWeights!=None:
            width=f1(NodeWeights[i])
            height=f1(NodeWeights[i])
            fontsize=f1(NodeWeights[i])*NodeFontScale
            dig.add_node_attribute(i,["width",str(width)])
            dig.add_node_attribute(i,["height",str(height)])
            dig.add_node_attribute(i,["fontsize",str(fontsize)])
            dig.add_node_attribute(i,["labelloc","b" ])
        if Labels!=None:
            dig.add_node_attribute(i,["width",str(Labels[i])])
        if NodeImages!=None:
            dig.add_node_attribute(i,["image",NodeImages[i]])
            dig.add_node_attribute(i,["imagescale","true"])  
        if Colors!=None:
            color="%f %f %f"%(Colors[i],Colors[i],Colors[i])
            dig.add_node_attribute(i,["color",color])
    NZ=Edges.nonzero()
    for k in range(len(NZ[0])):
        i=NZ[0][k]
        j=NZ[1][k]
        if i in Nodes and j in Nodes:
#            print(i,j)
            if EdgeEpsilon==None:
                AddEdge=True
            elif Edges[i,j]>EdgeEpsilon:
                AddEdge=True
            else:
                AddEdge=False
            if AddEdge==True:
                penwidth=f2(Edges[i,j])
                fontsize=f2(Edges[i,j])*EdgeFontScale
                arrowsize=f2(Edges[i,j])*ArrowScale
                weight="%.1e"%Edges[i,j]
#                print(weight)
                dig.add_edge(i,j,wt=weight)
                dig.add_edge_attribute(i,j,["penwidth",str(penwidth)])
                dig.add_edge_attribute(i,j,["fontsize",str(fontsize)])
                dig.add_edge_attribute(i,j,["arrowsize",str(arrowsize)])
        
    if TrimEmptyNodes==True:
        for i in dig.nodes():
            if dig.node_degree(i)==0 and dig.node_order(i)==0:
                dig.del_node(i)


    dot=pygraph.readwrite.dot.write(dig,weighted=True)
    if DotFilename!=None:
        DotFile=open(DotFilename,'w')
        DotFile.write(dot)
    gvv=gv.readstring(dot)
    gv.layout(gvv,'dot')
    gv.render(gvv,"svg",Filename)

    return(f1,f2)
