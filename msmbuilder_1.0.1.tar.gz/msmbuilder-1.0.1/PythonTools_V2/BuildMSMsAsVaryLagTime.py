#===============================================================================
# BuildMSMsAsVaryLagTime.py
#
# Builds both Micro and Macro MSMs for a range of lag times.
#
# Please reference
# GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble 
# simulations and Markov state models to identify conformational states.
#
# Written 11/19/08 by
# Gregory R. Bowman <gregoryrbowman@gmail.com>
# Pande group
#
# Copyright (C) 2008  Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#===============================================================================
# TODO:
#===============================================================================
# GLOBAL IMPORTS:
from optparse import OptionParser
import sys
#===============================================================================
# LOCAL IMPORTS:
import license
import MacroMSM
import MicroMSM
import MSM
#===============================================================================
# CHANGE LOG:
#===============================================================================

# define options
usage = "%prog [options]"
parser = OptionParser(usage=usage)
# number separate botstrapping samples to draw
parser.add_option("-b", "--numBootstraps", dest="nIterBootstrap", action="store", type="int", default=0, help="Number of iterations of bootstrapping to do. [default: 0, no bootstrapping]")
# head directory where all the clustering data is
parser.add_option("-d", "--head_dir", dest="headDir", action="store", type="string", default=".", help="Head direectory containing the assignments and trajectories directories. [default: .]")
# filename where trajectory filename list is
parser.add_option("-f", "--traj_list", dest="trajListFn", action="store", type="string", default="trajlist", help="Filename of trajectory list. [default: trajlist]")
# interval (in steps) between lag times for MSMs will buil
parser.add_option("-i", "--interavl", dest="interval", action="store", type="int", help="(required) Interval between lag times to build models for.  Builds models for lag times of 1, interval, 2*interval... maxLagTime.")
# max lax time to use
parser.add_option("-m", "--maxLagTime", dest="maxLagTime", action="store", type="int", help="(required) Maximum lag time to go up to.")
# number of eigenvalues to use for each mode
parser.add_option("-n", "--n_eig", dest="nEig", action="store", type="int", default=100, help="number of eigenvalues (or implied timescales) to consider in analysis  [default: 100]")
# mapping of micro to macro states
parser.add_option("-p", "--mapMicroToMacroFn", dest="mapMicroToMacroFn", action="store", type="string", help="File listing mapping of micro states to macro states.")
# number of microstates
parser.add_option("-s", "--numMicroStates", dest="nMicroStates", action="store", type="int", help="(required) Number of microstaes.")
# number of ps between snapshot
parser.add_option("-t", "--time_step", dest="dt", action="store", type="float", help="(required) Time in ps between entries in the assignment files.")
# number of macrostates to build
parser.add_option("-u", "--num_macro", dest="numMacro", action="store", type="int", help="Number of macrostates to build. If unspecified then just get MicroMSMs as vary lag time, otherwise build MacroMSMs.")

# parse option
license.printLicense()
(options, args) = parser.parse_args()
print sys.argv

# check have all necessary arguments
if options.interval == None:
  print "ERROR: must specify the interval."
  sys.exit(1)
if options.maxLagTime == None:
  print "ERROR: must specify the maxLagTime."
  sys.exit(1)
if options.nMicroStates == None:
  print "ERROR: must specify the number of micro states."
  sys.exit(1)
if options.dt == None:
  print "ERROR: must specify the time-step between entries."
  sys.exit(1)

# if the number of macro states is 0 just build micro msms
if options.numMacro == None:
  print "Building MicroMSMs."
  myMsm = MicroMSM.MicroMSM(headDir=options.headDir, trajListFn=options.trajListFn, dt=options.dt, nMicroStates=options.nMicroStates)
# otherwise build macro msms
else:
  print "Building MacroMSMs."
  myMsm = MacroMSM.MacroMSM(headDir=options.headDir, trajListFn=options.trajListFn, dt=options.dt, lagTime=1, numMacro=options.numMacro, nMicroStates=options.nMicroStates, mapMicroToMacroFn=options.mapMicroToMacroFn)
myMsm.getAssignFileList()

# build MSMs as vary lag time and store implied timescales to files
nLagTimes = 1+int((options.maxLagTime)/options.interval)
lagTimes = []
for i in range(nLagTimes):
  lagTimes.append(options.interval*i)
lagTimes[0] = 1

myMsm.buildModelsAsVaryLagTime(lagTimes=lagTimes, nEig=options.nEig, nBootstrap=options.nIterBootstrap)

