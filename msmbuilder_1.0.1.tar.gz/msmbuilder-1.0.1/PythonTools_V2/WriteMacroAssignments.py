#===============================================================================
# WriteMacroAssignments.py
#

# Write macro state assignments based on the specified mapping from 
# micro to macro states.
# 
# Please reference
# GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble 
# simulations and Markov state models to identify conformational states.
#
# Written 12/12/08 by
# Gregory R. Bowman <gregoryrbowman@gmail.com>
# Biophysics Program, Stanford University
# Pande group
#
# Copyright (C) 2008  Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#===============================================================================
# TODO:
#===============================================================================
# GLOBAL IMPORTS:
from optparse import OptionParser
import os
import os.path
import sys
#===============================================================================
# LOCAL IMPORTS:
import license
#===============================================================================
# CHANGE LOG:
#===============================================================================

# define options
usage = "%prog [options]"
parser = OptionParser(usage=usage)
# max temp to consider
parser.add_option("-a", "--maxT", dest="maxT", action="store", type="string", help="Maximum temperature index to consider.  If minT and maxT are not specified then all assignments will be written.  If minT and maxT are specified then only assignments for data points with temperature indices in the range minT to maxT (inclusive) will be printed.  Other points will be assigned to microstate -1 and macrostate -1 and will be ignored by other scripts.")
# head directory where all the clustering data is
parser.add_option("-d", "--head_dir", dest="headDir", action="store", type="string", default=".", help="Head direectory containing the assignments and trajectories directories. [default: .]")
# filename where trajectory filename list is
parser.add_option("-f", "--traj_list", dest="trajListFn", action="store", type="string", default="trajlist", help="Filename of trajectory list. [default: trajlist]")
# min temp to consider
parser.add_option("-i", "--minT", dest="minT", action="store", type="string", help="Minimum temperature index to consider.  If minT and maxT are not specified then all assignments will be written.  If minT and maxT are specified then only assignments for data points with temperature indices in the range minT to maxT (inclusive) will be printed.  Other points will be assigned to microstate -1 and macrostate -1 and will be ignored by other scripts.")
# mapping of micro to macro states
parser.add_option("-m", "--mapMicroToMacroFn", dest="mapMicroToMacroFn", action="store", type="string", help="(required) File listing mapping of micro states to macro states(string).")

# parse option
license.printLicense()
(options, args) = parser.parse_args()
print sys.argv

# check have all necessary arguments
if options.mapMicroToMacroFn == None:
  print "ERROR: must specify the mapping from microstates to macrostates."
  sys.exit(1)

# set paths to assignment/trajectory directories
assignDir = os.path.join(options.headDir, "assignments")
trajDir = os.path.join(options.headDir, "trajectories")

# decide if restricting to crtain temperature range
useTemps = False
if options.minT != None and options.maxT != None:
  useTemps = True

# read in mapping
mapMicroToMacro = []
f = open(options.mapMicroToMacroFn, 'r')
for line in f:
  line = line.strip()
  mapMicroToMacro.append(int(line))
f.close()
# macro states are numbered from 0 to n, so n+1 of them in total
numMacro = max(mapMicroToMacro)+1

# read in trajectory list, needed for getting micro centers
trajList = []
assignList = []
trajListFn = os.path.abspath(options.trajListFn)
f = open(trajListFn, 'r')
for line in f:
  assignFn = os.path.join(assignDir, line.strip())
  trajFn = os.path.join(trajDir, line.strip())
  assignList.append(assignFn)
  trajList.append(trajFn)
f.close()

# read all assignments files and add macro assignments as second column
fileIndex = 0
for assignFn in assignList:
  # read file
  f = open(assignFn, 'r')
  lines = f.readlines()
  f.close()

  # read temperature data if specified
  temps = []
  if useTemps:
    trajFn = trajList[fileIndex]
    trajF = open(trajFn, 'r')
    for tempFn in trajF:
      tempFn += ".T.dat"
      tempFn = os.path.join(options.headDir, tempFn)
      tempF = open(tempFn, 'r')
      for line in tempF:
        temps.append(int(line.strip()))
      tempF.close()
    trajF.close()

  # write micro and macro assignments
  f = open(assignFn, 'w')
  lineIndex = 0
  for line in lines:
    micro = int(line.strip().split()[0])
    if micro >= len(mapMicroToMacro):
      print "ERROR: micro state out of range of mapping"
      sys.exit(1)
    macro = mapMicroToMacro[micro]

    # if only want certain temperature range then only print 
    # assignment if in range, otherwise print -1's
    if useTemps:
      myTemp = temps[lineIndex]
      if myTemp >= options.minT and myTemp <= options.maxT:
        line = "%d %d\n" % (micro, macro)
      else:
        line = "-1 -1\n"
    else:
      line = "%d %d\n" % (micro, macro)

    f.write(line)
    lineIndex += 1
  f.close()
  fileIndex += 1

