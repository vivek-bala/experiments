#!/usr/bin/env python2.6

import sys, string

import TransitionPathTheory
UseVisualization=True
try:
    import PlotGraph
except ImportError:
    print("PlotGraph cannot be imported due to missing library requirements.  Visualization will be disabled.")
    UseVisualization=False
import os
import os.path
import MicroMSM

from numpy import *
from scipy.sparse import *

def getEquilPopulations(T, nstates=1000, dt=1000.0):

    """Calculate the zeroth eigenvector of thr MAcrostate tProb matrix T."""

    myMSM = MicroMSM.MicroMSM(headDir='../', trajListFn="../trajlist", dt=dt, nMicroStates=nstates)
    myMSM.tProb  = T

    # Calculate the top n eigenvectors
    n = 2  # It can't be n=1, because o a bug
    eigSolution = myMSM.getLeftEigSolution(n)

    equil = real(eigSolution[1][:,0])
    equil = equil/equil.sum()  # normalize
    print 'EQUIL eigenvector:'
    for i in range(equil.shape[0]):
       print i, equil[i]

    return equil


# Main Program


usage = """Calculate the NPATHS highest flux pathways from SourceIndices to SinkIndices.  

Usage: ./tpt_ACBP_macro.py SourceIndices SinkIndices outname NPATHS [equilpopfile] [beta]

    Indices must be lists of numbers, with NO spaces allowed in the lists!

0       530     native
5441    799
18066	xxx	coil1
16935	xxx	coil2
12298	xxx     coil3
10992	xxx     coil4
17432	xxx     coil5

    Example (for M2000-lag20-n5): ./tpt_ACBP_macro.py [1601] [648] ext2native 15 equilpops.dat 8.0

    OPTIONAL

    equilpopfils - a flat file with equilibirum populations
    beta         - an inverse temperature (beta must be > 0)

    When beta > 1, the max-flux paths are more heavily weighted, with max-flux
    being the limiting case of beta -> inf.

    When beta < 1, the search is weighted across a more uniform distribution of
    fluxes, with a random search in the limit of beta -> 0

    The default of beta=4.0 worked well in iniial tests

"""


if len(sys.argv) < 5:
    print usage; sys.exit(1)


#Define states A and B; we are modeling the reaction A -> B
A = eval(sys.argv[1])
B = eval(sys.argv[2])
outname = sys.argv[3]
TopN = int(sys.argv[4])


equilpopfile = None
if len(sys.argv) >= 6:
    equilpopfile = sys.argv[5]

# output files
outdotfile = outname + '.dot'
outsvgfile = outname + '.svg'
outPfoldfile = outname + '.pfold'

datadir = './'

# get transition matrix and eq dist
T = lil_matrix(loadtxt(os.path.join( datadir, "tProb.macro.dat")))

nStates = T.shape[0]
if equilpopfile == None:
    X = getEquilPopulations(T, nstates=nStates)
else:
    X = loadtxt(equilpopfile)
print 'X', X
#X = loadtxt( os.path.join(datadir,"eq_dist.dat"))
#X = loadtxt("/Users/greg/Projects/Lambda/msm_3064/M5k/eq_dist.dat")
X = array(X).flatten()
# normalize X to be safe!
X = X/X.sum()

n = T.shape[0]

#Calculate the necessary quantities

print "getting forward commitors"
F=TransitionPathTheory.GetFCommittors(A,B,T,maxiter=25000)
print "getting reverse commitors"
R=TransitionPathTheory.GetBCommittors(A,B,T,X,maxiter=25000)
print "getting flux"
Flux=TransitionPathTheory.GetNetFlux(X,F,R,T)
PFold=F

# write Pfolds to file
print 'PFold:', PFold
fout = open(outPfoldfile,'w')
for i in range(PFold.shape[0]):
    print i, PFold[i]
    fout.write('%f\n'%PFold[i])
fout.close()

print 'Total flux out of source', A
for i in A:
    print Flux[i,:]


#Use greedy backtracking to calculate the top 15 pathways
PathList=[]
FluxList=[]
print "doing backtracking"
print '#index\tflux\tpath'
for i in range(TopN):
    tmp=TransitionPathTheory.GreedyBacktrackWithPFoldStochasticScrub(A,B[0],Flux,PFold, beta=4.0, NScrubs=100, Verbose=False)   # beta > 8.0 is essentially greedy
    #tmp=TransitionPathTheory.GreedyBacktrackWithPFold(A,B[0],Flux,PFold)
    PathList.append(tmp[0])
    FluxList.append(tmp[1])

    print '%d\t%e\t%r'%(i, FluxList[-1], PathList[-1])

#Build a new flux matrix that only contains the fluxes from the top 15 pathways
F2=lil_matrix((n,n))
TransitionPathTheory.AddPathwaysToMatrix(F2,PathList[0:TopN],FluxList[0:TopN])

# print a Mathematica-style graph
(i_ind, j_ind) = F2.nonzero()

print 'g = {', 
connections = []
unique_indices = []
for k in range(len(i_ind)):
   connections.append('{%d -> %d, %16.16f}'%(i_ind[k], j_ind[k], F2[i_ind[k], j_ind[k]]))
   if unique_indices.count(i_ind[k]) == 0:  unique_indices.append(i_ind[k])
   if unique_indices.count(j_ind[k]) == 0:  unique_indices.append(j_ind[k])
print string.joinfields(connections, ', '),
print '};'

# Print a mathematica-friendly linked list of free energies
Free = -0.5959*log(X)
Free = Free - Free.min()
print 'FreeEnergies = {',
terms = []
for k in unique_indices:
    terms.append('%d -> %16.16f'%(k,Free[k]))
print string.joinfields(terms,','),
print '};'


#Visualize, with output sent to test.svg
Nodes=range(n)
flist = []
pngDir = "/Users/server/lambda/MacroPNG-March7"
for i in Nodes:
  fn = "state%d.png" % i
  fn = os.path.join(pngDir, fn)
  flist.append(fn)
#print len(flist)
flist = None
NodeWeights=log(X)
#print 'NodeWeights', NodeWeights

# Write DOT files
if UseVisualization==True:
    PlotGraph.PlotModel(Nodes,F2,outsvgfile,NodeWeights=log(X),DotFilename=outdotfile,TrimEmptyNodes=True,NodeImages=flist,UseScalingFunctions=True)


