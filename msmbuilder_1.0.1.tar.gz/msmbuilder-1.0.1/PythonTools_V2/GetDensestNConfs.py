#===============================================================================
# GetDensestNConfs.py
#
# Extract N representative conformations from each macrostate by getting
# the microstate centers of the N densest microstates from each macrostate.
#
# Please reference
# GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble 
# simulations and Markov state models to identify conformational states.
# 
# Written 11/27/08 by
# Gregory R. Bowman <gregoryrbowman@gmail.com>
# Biophysics Program, Stanford University
# Pande group
#
# Copyright (C) 2008  Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#===============================================================================
# TODO:
#===============================================================================
# GLOBAL IMPORTS:
from optparse import OptionParser
import os
import os.path
import shutil
import sys
#===============================================================================
# LOCAL IMPORTS:
import license
#===============================================================================
# CHANGE LOG:
#===============================================================================

# define options
usage = "%prog [options]"
parser = OptionParser(usage=usage)
# directory to find density info in
parser.add_option("-d", "--densityDir", dest="densityDir", action="store", type="string", default="StateCenters", help="Directory where density information (from GetDensityInfo.py) and the microstate centers (from GetMicroCentersByMacroState.py) are.  All output will be put in this directory. [default: StateCenters]")
# number of macrostates 
parser.add_option("-m", "--num_macro", dest="numMacro", action="store", type="int", help="(required) Number of macrostates.")
# number of confs to get from each state
parser.add_option("-n", "--numConfs", dest="numConfs", action="store", type="int", default=1, help="Number of conformations to get from each macrostate. [default: 1]")

# parse option
license.printLicense()
(options, args) = parser.parse_args()
print sys.argv

# check have all necessary arguments
if options.numMacro == None:
  print "ERROR: must specify the number of macrostates."
  sys.exit(1)

macro = 0
while macro < options.numMacro:

  # open list microstates in this macrostate and grab confs corresponding
  # to desired number of desnsest microstates.
  fn = os.path.join(options.densityDir, "macro%d.listMicros.dat" % macro)
  f = open(fn, 'r')

  conf = 0
  while conf < options.numConfs:
    line = f.readline().strip()
    if line == "": break
    microIndex = int(line.split()[0])
    microFn = os.path.join(options.densityDir, "macro%d" % macro, "gen%d.gro" % microIndex)
    macroFn = os.path.join(options.densityDir, "macro%d.densest%d.gro" % (macro, conf))
    shutil.copyfile(microFn, macroFn)

    conf += 1

  f.close()

  macro += 1

