#===============================================================================
# GetMicroCentersByMacroState.py
#
# Get gro files for all the micro state centers and group together by macro state.
# All the micro states in a given macro state go into a directory called macroX
# in the specified output directory, where X is th emacro state index.
# 
# Please reference
# GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble 
# simulations and Markov state models to identify conformational states.
#
# Written 11/25/08 by
# Gregory R. Bowman <gregoryrbowman@gmail.com>
# Biophysics Program, Stanford University
# Pande group
#
# Copyright (C) 2008  Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#===============================================================================
# TODO:
#===============================================================================
# GLOBAL IMPORTS:
import cPickle
from optparse import OptionParser
import os
import os.path
import shutil
import sys
#===============================================================================
# LOCAL IMPORTS:
import license
#===============================================================================
# CHANGE LOG:
#===============================================================================

# define options
usage = "%prog [options]"
parser = OptionParser(usage=usage)
# head directory where all the clustering data is
parser.add_option("-d", "--head_dir", dest="headDir", action="store", type="string", default=".", help="Head direectory containing the assignments and trajectories directories. [default: .]")
# path to trjconv executable
parser.add_option("-e", "--exec", dest="trjconvExec", action="store", type="string", help="Full path to trjconv executable. [default: $MSMBUILDERHOME/Extras/trjconv/trjconv]")
# filename where trajectory filename list is
parser.add_option("-f", "--traj_list", dest="trajListFn", action="store", type="string", default="trajlist", help="Filename of trajectory list.  Multiple files may be specified by giving a space delineated list surrounded by double quotes.  Note that an equal number of trajlist, tpr, and ndx files must be specified.  [default: trajlist]")
# mapping of micro to macro states
parser.add_option("-m", "--mapMicroToMacroFn", dest="mapMicroToMacroFn", action="store", type="string", help="(required) File listing mapping of micro states to macro states.")
# directory to write output to
parser.add_option("-o", "--outputDir", dest="outDir", action="store", type="string", default="StateCenters", help="Directory name to put output into. [default: StateCenters]")
# specify output type
parser.add_option("-p","--outputType",dest="outputType",action="store",type="string",help="Type of file to output.  .pdb or .gro",default=".gro")
# tpr file
parser.add_option("-t", "--tprFn", dest="tprFn", action="store", type="string", help="(required) Path to tpr file.  Multiple files may be specified by giving a space delineated list surrounded by double quotes.  Note that an equal number of trajlist, tpr, and ndx files must be specified.  ")
# ndx file
parser.add_option("-x", "--ndxFn", dest="ndxFn", action="store", type="string", help="(required) Path to index (.ndx) file.  Multiple files may be specified by giving a space delineated list surrounded by double quotes.  Note that an equal number of trajlist, tpr, and ndx files must be specified.  ")

# parse option
license.printLicense()
(options, args) = parser.parse_args()
print sys.argv

# check have all necessary arguments
if options.mapMicroToMacroFn == None:
  print "ERROR: must specify the mapping from microstates to macrostates."
  sys.exit(1)
if options.tprFn == None:
  print "ERROR: must specify the tpr file."
  sys.exit(1)
if options.ndxFn == None:
  print "ERROR: must specify the ndx file."
  sys.exit(1)
if options.outputType not in [".gro",".pdb"]:
   print "Error: Output Filetype must be .gro or .pdb"
   print options.outputType
   sys.exit(1)

# parse multiple trajlist/tpr/ndx file lists if there and make sure have 
# same number of each
options.trajListFn = options.trajListFn.split()
options.tprFn = options.tprFn.split()
options.ndxFn = options.ndxFn.split()
if len(options.trajListFn) != len(options.tprFn) or len(options.trajListFn) != len(options.ndxFn) or len(options.tprFn) !=  len(options.ndxFn):
  print "ERROR: must have the same number of trajlist, tpr, and ndx files."
  sys.exit(1)

# read in mapping
mapMicroToMacro = []
f = open(options.mapMicroToMacroFn, 'r')
for line in f:
  line = line.strip()
  mapMicroToMacro.append(int(line))
f.close()
# macro states are numbered from 0 to n, so n+1 of them in total
numMacro = max(mapMicroToMacro)+1 

# setup output directories.
# gro files will be organized into one directory per macro state
outDir = options.outDir
if os.path.exists(outDir):
  print "WARNING: %s already exists." % outDir
if not os.path.exists(outDir):
  os.mkdir(outDir)
i = 0
while i < numMacro:
  macroDir = os.path.join(outDir, "macro" + str(i))
  if not os.path.exists(macroDir):
    os.mkdir(macroDir)

  i += 1

# read in number of generators and make sure agrees with mapping
genDir = os.path.join(options.headDir, "generators")
numGenFn = os.path.join(genDir, "numGens")
f = open(numGenFn, 'r')
numGen = int(f.readline().strip())
f.close()
if(numGen != len(mapMicroToMacro)):
  print "ERROR: the length of mapMicroToMacro doesn't match the number of generators."
  sys.exit(1)

# read in trajectory list, needed for getting micro centers.
# store tuples of (trajectory name, trajlist index) where trajlist index
# will also be the index of the tpr/ndx files to be used
trajDir = os.path.join(options.headDir, "trajectories")
trajList = []
i = 0
while i < len(options.trajListFn):
  trajListFn = os.path.abspath(options.trajListFn[i])
  f = open(trajListFn, 'r')
  for line in f:
    trajFn = os.path.join(trajDir, line.strip())
    trajList.append((trajFn, i))
  f.close()
  i += 1

# read in generators and output gro file for each.
i = 0
while i < numGen:
  # get snapshot identifiers
  genFn = os.path.join(genDir, "gen" + str(i))
  f = open(genFn, 'r')
  trajId = int(f.readline().strip())
  xtcId = int(f.readline().strip())
  snapshotId = int(f.readline().strip())
  f.close()

  # determine output file name
  macro = mapMicroToMacro[i]
  if options.outputType=='.pdb':
    outFn = os.path.join(outDir, "macro" + str(macro), "gen" + str(i) + ".pdb")
  else:
    outFn=  os.path.join(outDir, "macro" + str(macro), "gen" + str(i) + ".gro")

  # pull out gro file and write to appropriate directory
  (trajFn, fnInd) = trajList[trajId]
  trajF = open(trajFn, 'r')
  lines = trajF.readlines()
  trajF.close()
  xtcFn = os.path.join(options.headDir, lines[xtcId].strip() + ".xtc")
  msmBuilderHome = os.environ.get('MSMBUILDERHOME')
  cmd = ""
  if options.trjconvExec != None:
    cmd = options.trjconvExec
  else:
    cmd = os.path.join(msmBuilderHome, "Extras/trjconv/trjconv ")
  cmd += " -f %s -o %s -s %s -n %s" % (xtcFn, outFn, options.tprFn[fnInd], options.ndxFn[fnInd])
  cmd += " -dumpN %d" % (snapshotId)
  print cmd
  os.system(cmd)

  i += 1



