Transition Path Theory is a way calculate reaction pathways from a Markov state model.  See Noe, PNAS, 2009 or Pande and Voelz, JACS, 2009 for examples.

Because TPT is used to visualized graphs, visualizing such calculations requires a few extra libraries.  Performing TPT calculations can be done without visualization, but then you will have to find your own way to visualize things.  


Visualization Requirements:

pygraph h (python-pygraph)
gv (libgv-python)

Note that libgv-python is broken in Ubuntu 10.04 as of Oct. 11, 2010.  See https://bugs.launchpad.net/ubuntu/+source/graphviz/+bug/556874 for a workaround.  


Using TPT:

A script for performing TPT calculations is included (DoTPT.py).  DoTPT.py is likely the best "tutorial" on how to use the TPT code for your own calculations.  

Performing TPT generally requires:

1.  A transition matrix
2.  A set of source states (A)
3.  A set of sink states (B)

TPT then requires calculating three intermediate calculations:

1.  Equilibrium populations
2.  The forward commitors.
3.  The backward commitors.  

Finally, TPT eventually gives a matrix of net Fluxes that represent the net flux of the reaction A-> B.  This flux can also be decomposed into different pathways using a number of algorithms.
