#===============================================================================
# MicroMSM.py
#
# MicroMSM class for building a Markov State Model (MSM) of microstates.
# Extends the MSM class.
# No lumping into macrostates is performed.
#
# For an example of the use of this class see BuildMicroMSMsVaryLagTime.py,
# which builds MSMs for varying lag times in order to determine
# the number of timescales present (i.e. an appropriate number of macrostates
# to lump into).
#
# Please reference
# GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble 
# simulations and Markov state models to identify conformational states.
#
# Written 11/18/08 by
# Gregory R. Bowman <gregoryrbowman@gmail.com>
# Sergio Bacallado <sergiobacallado@gmail.com>
# Xuhui Huang <xuhuihuang@gmail.com>
# Pande group
#
# Copyright (C) 2008  Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#===============================================================================
# TODO:
#===============================================================================
# GLOBAL IMPORTS:
import cPickle
import os
import os.path
from numpy import *
from numpy.linalg import *
import random
import sys
from scipy.io import mmwrite, mmread
import scipy.sparse.linalg
#===============================================================================
# LOCAL IMPORTS:
import MSM
#===============================================================================
# CHANGE LOG:
# 03/24/09 GRB - merged in sparse matrix code from Kyle Beauchamp
#===============================================================================


class MicroMSM(MSM.MSM):
  def __init__(self, headDir="", trajListFn="trajlist", dt=None, nMicroStates=None):
    """Class for building Markov model for just microstates.  Used for determining how many macrostates to gen
erate.

    ARGUMENTS:
      headDir = path to directory where hierarchical clustering performed (string)
      trajListFn = name of trajlist file (string)
      dt = timestep in fs used in simulation (float)
      nMicroStates = number of microstates (int)
    """

    # directory relative to head dir where assignment files are
    self.assignDir = "assignments"

    # column of assignment file to use. Generally col=0 for the micro state assignment and col=1 for the macro state assignment.
    self.col = 0

    # time in ps lapsed between entries in the assignments files
    self.dt = dt

    # lag time in number of entries in assignment file (int).
    self.lagTime = None

    # store results from Noe transition matrix sampling alg
    self.noeResults = None

    # number of states
    self.nStates = nMicroStates

    # head directory where all the clustering data is
    self.headDir = os.path.abspath(headDir)

    # list of implied timescales
    self.tau = []

    # transition count and probability matrices
    self.tCount = None
    self.tProb = None

    # file listing all the assignment files to be used
    self.trajListFn = os.path.abspath(trajListFn)

    # list of all the assignment files to be used
    self.trajList = []

  def getTransitionMatrix(self, subsample=False, useNoe=False, nIter=1e7, freqSample=1e4, readDir="", doSymm=True):
    """Get the transition matrix.  Overloads the base classes method.  Added functionality is that this method will load the microstate transition matrices from files in the head directory if they're available.

    ARGUMENTS:
      subsample = If false use sliding window to count transitions, if true use every lagTime'th step (bool).
      useNoe = Determine whether or not to use Noe method to get transition probability matrix (bool).  If useNoe is true then subsample should also be true in order to get accurate statistics.
      nIter = Number iteration Noe sampling to do, only matters if useNoe is true (int).
      freqSample = Frequency to store samples from Noe Markov chain, only matters if useNoe is true (int).  Stores every freqSample'th step.
      readDir = directory to read transition matrix files from (string)
    """

    # set tProb/tCount to None to prevent falsely thinking have loaded them
    self.tProb = None
    self.tCount = None

    # try to read the transition matrices from files in the head directory
    if readDir == None:
      self.loadTransitionMatrix()
    else:
      self.loadTransitionMatrix(readDir=readDir)

    if not (self.tProb==None or self.tCount==None):
      print "Micro Transition Matrix Found and Loaded."

      self.weights = array(self.tCount.sum(axis=1)).flatten()
      # adjust weights for low counts
      self.weights[self.weights==0] = 1

      # get size information on loaded matrices
      n1=self.nStates
      n2=shape(self.tCount)[0]
      n3=shape(self.tCount)[1]
      n4=shape(self.tProb)[0]
      n5=shape(self.tProb)[1]

      # ensure that the matrices are squares and match the desired number of states
      if shape(self.tCount)!=shape(self.tProb) or not (n1==n2==n3==n4==n5):
        print "Loaded tCount/tProb Shapes Inconsisent with nShape, recalculating tProb"
        self.tCount=None
        self.tProb=None

    else:
      print "No Transition Matrix Found or Incorrect Shapes Found; Creating matrices from Assignments."
      MSM.MSM.getTransitionMatrix(self, subsample=subsample, useNoe=useNoe, nIter=nIter, freqSample=freqSample, doSymm=doSymm)

  def loadTransitionMatrix(self, readDir=""):
    """Load teh transition count and probailty matrices from files.

    ARGUMENTS:
      readDir = directory to read files from (string)
    """

    try:
      tCountFn = os.path.join(readDir, "tCount.micro.mtx")
      tProbFn = os.path.join(readDir, "tProb.micro.mtx")
      if not os.path.exists(tCountFn) or not os.path.exists(tProbFn):
        return
      self.tCount = mmread(tCountFn).tolil()
      self.tProb = mmread(tProbFn).tolil()
    except IOError:
      self.tCount = None
      self.tProb = None

  def printTransitionMatrices(self, outDir=""):
    """Print the transition count matrix and transition probability matrices to files.

    ARGUMENTS:
      outDir = directory to write files to (string)
    """

    tCountFn = os.path.join(outDir, "tCount.micro.mtx")
    tProbFn = os.path.join(outDir, "tProb.micro.mtx")
    mmwrite(tCountFn, self.tCount)
    mmwrite(tProbFn, self.tProb)

  def rightMultiplyVec(self,x,A):
    """Multiple Sparsely.  
    """

    LO = scipy.sparse.linalg.aslinearoperator(A)
    return LO.rmatvec(x.flatten()).reshape(shape(x))

  def initializeMatrices(self):
    """ Allocate and Zero tProb and tCount.  Different for Macro and Micro MSMs, because Micro MSMs are stored as sparse LIL matrices.
    """

    self.tProb = scipy.sparse.lil_matrix((self.nStates,self.nStates))
    self.tCount = scipy.sparse.lil_matrix((self.nStates,self.nStates))
    self.totalCount = 0

