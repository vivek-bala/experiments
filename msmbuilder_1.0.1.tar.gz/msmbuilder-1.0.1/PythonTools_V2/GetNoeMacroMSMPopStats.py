#===============================================================================
# GetNoeMacroMSMPopStats.py
#
# Get statistics (mean and standard deviation) on the population of each state 
# using Noe's MCMC transition matrix sampling method.
#
# Please reference
# GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble 
# simulations and Markov state models to identify conformational states.
#
# Written 08/28/08 by
# Gregory R. Bowman <gregoryrbowman@gmail.com>
# Pande group
#
# Copyright (C) 2008  Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#===============================================================================
# TODO:
#===============================================================================
# GLOBAL IMPORTS:
import cPickle
from optparse import OptionParser
import os
import os.path
import sys
#===============================================================================
# LOCAL IMPORTS:
import license
import MacroMSM
import MicroMSM
#===============================================================================
# CHANGE LOG:
# 08/28/08 GRB - Ready for general use
# 01/30/09 GRB - No longer have to read in MSM.
#===============================================================================

# define options
usage = "%prog [options]"
parser = OptionParser(usage=usage)
# head directory where all the clustering data is
parser.add_option("-d", "--head_dir", dest="headDir", action="store", type="string", help="Head direectory containing the assignments and trajectories directories.  This option is required unless you read in an existing MSM with the -r option.")
# filename where trajectory filename list is
parser.add_option("-f", "--traj_list", dest="trajListFn", action="store", type="string", help="Filename of trajectory list.  This option is required unless you read in an existing MSM with the -r option.")
# interval store Noe results
parser.add_option("-i", "--interval", dest="interval", action="store", type="int", default=1e4, help="Noe algorithm will store results every interval'th steps and use these stored results to calculate expectations and variances. [default: 1e4]")
# lag time to use
parser.add_option("-l", "--lag_time", dest="lagTime", action="store", type="int", help="(required) Lag time in number of entries in the assignment files to use for the model.")
# number of macrostates 
parser.add_option("-m", "--num_macro", dest="numMacro", action="store", type="int", help="Number of macrostates.")
# number Noe iterations
parser.add_option("-n", "--nIter", dest="nIter", action="store", type="int", default=1e7, help="Number of iterations of Noe MCMC matrix sampling to do. [default: 1e7]")
# mapping of micro to macro states
parser.add_option("-p", "--mapMicroToMacroFn", dest="mapMicroToMacroFn", action="store", type="string", help="File listing mapping of micro states to macro states.")
# number of microstates
parser.add_option("-s", "--numMicroStates", dest="nMicroStates", action="store", type="int", help="Number of microstaes.  This option is required unless you read in an existing MSM with the -r option.")
# number of ps between snapshot
parser.add_option("-t", "--time_step", dest="dt", action="store", type="float", help="Time in ps between entries in the assignment files.  This option is required unless you read in an existing MSM with the -r option.")

# parse option
license.printLicense()
(options, args) = parser.parse_args()
print sys.argv

# print usage and exit if don't have required options
if options.lagTime == None:
  print "ERROR: must specify the lagTime."
  sys.exit(1)
if (options.headDir==None or options.trajListFn==None or options.nMicroStates==None or options.dt==None):
  print "ERROR: must specify the head directory, trajlist file, number of microstates, and time step necessary to build one."
  sys.exit(1)

myMsm = None
# if have number macrostates build new macro msm object
if options.numMacro != None:
  myMsm = MacroMSM.MacroMSM(headDir=options.headDir, trajListFn=options.trajListFn, dt=options.dt, lagTime=options.lagTime, numMacro=options.numMacro, nMicroStates=options.nMicroStates, mapMicroToMacroFn=options.mapMicroToMacroFn)
# otherwise make new micro msm object
else:
  myMsm = MicroMSM.MicroMSM(headDir=options.headDir, trajListFn=options.trajListFn, dt=options.dt, nMicroStates=options.nMicroStates, trjconvExec=options.trjconv)
  myMsm.lagTime = options.lagTime

# set MSM vars
if options.headDir != None:
  myMsm.headDir = options.headDir
if options.trajListFn != None:
  myMsm.trajListFn = os.path.abspath(options.trajListFn)
myMsm.lagTime = options.lagTime

# get population stats
myMsm.getPopStatsUsingNoeMethod(nIter=options.nIter, freqSample=options.interval)

