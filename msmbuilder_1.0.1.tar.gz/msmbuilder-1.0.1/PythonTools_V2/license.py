# just prints the GPL license information
def printLicense():
  print "    MSMBuilder version 1.0.1, Copyright (C) 2010 Stanford University."
  print "    MSMBuilder comes with ABSOLUTELY NO WARRANTY."
  print "    This program is free software; you can redistribute it and/or"
  print "    modify it under the terms of the GNU General Public License"
  print "    as published by the Free Software Foundation; either version 2"
  print "    of the License, or (at your option) any later version."
  print ""
  print "    Please reference"
  print "    GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble"
  print "    simulations and Markov state models to identify conformational states."
  print ""

