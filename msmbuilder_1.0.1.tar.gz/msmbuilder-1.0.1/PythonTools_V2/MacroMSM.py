#===============================================================================
# MacroMSM.py
#
# MacroMSM class for building a Markov State Model (MSM).
# Lumps given microstates into macrostates by performing one iteration of PCCA
# and then using a Simulated Annelaing (SA) procedure to refine the lumping.
# Extends the MSM class.
#
# For an example of the use of this class see BuildMacroMSM.py, which should
# be suficient for most applications.
#
# Please reference
# GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble 
# simulations and Markov state models to identify conformational states.
#
# Written 11/18/08 by
# Gregory R. Bowman <gregoryrbowman@gmail.com>
# Sergio Bacallado <sergiobacallado@gmail.com>
# Xuhui Huang <xuhuihuang@gmail.com>
# Pande group
#
# Copyright (C) 2008  Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#===============================================================================
# TODO:
#===============================================================================
# GLOBAL IMPORTS:
import math
from numpy import *
from numpy.linalg import *
import os
import os.path
import random
import sys
import scipy.sparse
#from scipy.optimize import anneal
# Check if scipy 0.7 or greater is available
try:
  from scipy import savetxt
  import scipy.sparse
except ImportError:
  sys.exit()
#===============================================================================
# LOCAL IMPORTS:
import MicroMSM
import MSM
import NoeSampling
#===============================================================================
# CHANGE LOG:
# 01/18/09 GRB - rewrote Q calculation so orders of magnitude faster
# 03/24/09 GRB - merged in sparse matrix code from Kyle Beauchamp
#===============================================================================

class MacroMSM(MSM.MSM):
  def __init__(self, headDir=".", trajListFn="trajlist", dt=None, numMacro=None, lagTime=None, nMicroStates=None, mapMicroToMacroFn=None):
    """Class for building final Markov model by lumping microstates into macrostates.

    ARGUMENTS:
      headDir = path to directory where hierarchical clustering performed (string)
      trajListFn = name of trajlist file (string)
      dt = timestep in fs used in simulation (float)
      numMacro = number of macrostates to build (int)
      lagTime = lag time to use for MSM (int)
      nMicroStates = number of microstates (int)
      mapMicroToMacroFn = file specifying mapping of microstates to macrostates (string)
    """

    # directory relative to head dir where assignment files are
    self.assignDir = "assignments"

    # column of assignment file to use. Generally col=0 for the micro state assignment and col=1 for the macro state assignment.
    self.col = 1

    # time in ps lapsed between entries in the assignments files
    self.dt = dt

    # lag time in number of entries in assignment file (int).
    self.lagTime = lagTime

    # mapping between micro states and macro sttaes
    if mapMicroToMacroFn==None:
      self.mapMicroToMacro = None
    else:
      self.mapMicroToMacro= loadtxt(mapMicroToMacroFn,dtype='int')

    # microMSM whose states will be lumped together to make macro msm
    self.microMSM = None

    # store results from Noe transition matrix sampling alg
    self.noeResults = None

    # number of microstates
    self.nMicroStates = nMicroStates

    # number of states
    self.nStates = numMacro

    # head directory where all the clustering data is
    self.headDir = os.path.abspath(headDir)

    # list of implied timescales
    self.tau = []

    # transition count and probability matrices
    self.tCount = zeros((numMacro,numMacro))
    self.tProb = zeros((numMacro,numMacro))

    # file listing all the assignment files to be used
    self.trajListFn = os.path.abspath(trajListFn)

    # list of all the assignment files to be used
    self.trajList = []

  def lump(self, nRunSA=20, nIterSA=20000, alg='Standard', doMinimization=True, readDir=None, outDir=None):
    """Lump microstates into macrostates.

    ARGUMENTS:
      nRunSA = number of simulated annealing runs to refine macrostates (int)
      nIterSA = number of iterations of SA do per run (int)
      alg = specifies which PCCA algotihm to use (string).  Choices are 'Standard' and 'Simplex'
      doMinimization = whether or not to do minimization (bool)
      readDir = directory to read micro msm transition matrix files from (string)
      outDir = directory to write micro msm transition matrix files to (string)
    """

    # initialize microMSM will build macro states out of
    self.microMSM = MicroMSM.MicroMSM(headDir=self.headDir, trajListFn=self.trajListFn, dt=self.dt, nMicroStates=self.nMicroStates)
    self.microMSM.lagTime = self.lagTime
    self.microMSM.trajList = self.trajList
    self.microMSM.getTransitionMatrix(readDir=readDir)

    # do PCCA to get initial guess at macrostates
    print "Doing initial PCCA..."
    self.PCCA(nEigPerron=self.nStates-1, alg=alg, doMinimization=doMinimization)

    # do nRunSA iterations of simulated annealing to refine macrostates
    self.getTMatFromMicroMSM()
    maxQ = self.getQ()
    print "Metastability (Q) after PCCA: " + str(maxQ)
    print "Doing %d iterations of simulated annealing..." % nRunSA
    for i in range(nRunSA):
      prevQ = maxQ
      maxQ = self.SA(nIterSA, maxQ)
      print "SA run %d: %f -> %f" % (i, prevQ, maxQ)

      # make sure tCount corresponds current best mapping
      self.getTMatFromMicroMSM()

    print "Final Q: " + str(self.getQ())

    # print output to files
    fn = "Q.dat"
    f = open(fn, 'w')
    line = str(maxQ) + "\n"
    f.write(line)
    f.close()

    fn = "mapMicroToMacro.dat"
    f = open(fn, 'w')
    for microToMacro in self.mapMicroToMacro:
      line = str(int(microToMacro)) + "\n"
      f.write(line)
    f.close()

    # print macro and micro transition matrices
    self.printTransitionMatrices()
    if outDir != None:
      self.microMSM.printTransitionMatrices(outDir=outDir)

  def getTMatFromMicroMSM(self):
    """Convert the microMSM transition count/probability matrices into a macro MSM transition count/probability matrices.
    """

    # check that have mapping to convert
    if self.mapMicroToMacro == None:
      print "ERROR: can't convert micro state transition probability matrix to macro state one if no mapping from micro states to macro states exists."
      return

    # zero tCount
    self.tCount = zeros((self.nStates,self.nStates))

    # loop over all micro state transition
    indices=array(self.microMSM.tCount.nonzero()).transpose()
    for k in range(len(indices)):
      micro1 = indices[k,0]
      micro2 = indices[k,1]
      macro1 = self.mapMicroToMacro[micro1]
      macro2 = self.mapMicroToMacro[micro2]
      self.tCount[macro1,macro2] += self.microMSM.tCount[micro1,micro2]

    self.updateTProb()

  def updateTProb(self):
    """Recompute the transition probability matrix from the transition count matrix.
    """

    self.tProb = zeros((self.nStates,self.nStates))

    # normalize
    self.weights=self.tCount.sum(axis=0)

    # adjust weights for low counts
    self.weights[self.weights==0] = 1

    self.tProb = transpose(divide(transpose(self.tCount),self.weights))

  def PCCA(self, nEigPerron=None, alg='Standard', doMinimization=True):
    """Do PCCA analysis to get initial lumping of microstates into macrostates.  Assumes you've used determinePerronClusterEigenvalues() to determine the number of eigenvalues in the Perron cluster.

    ARGUMENTS:
      nEigPerron = number of eigenvalues in the Perron cluster (int).  This is one less than the desired number of macrostates.
      alg = specifies which PCCA algotihm to use (string).  Choices are 'Standard' and 'Simplex'
      doMinimization = whether or not to do minimization (bool).  Only matters for simplex version PCCA.
    """

    # mapping of microstates to macrostates
    self.mapMicroToMacro = zeros(self.microMSM.nStates)

    # call appropriate version of PCCA
    alg = alg.lower() # make all lowercase
    if alg=='simplex':
      print "Using the Simplex version of PCCA..."
      self.PCCA_Simplex(nEigPerron, doMinimization=doMinimization)
    else:
      print "Using standard version of PCCA..."
      self.PCCA_Standard(nEigPerron)

  def PCCA_Standard(self, nEigPerron):
    """Do PCCA clustering using standard method.  Should only be called by PCCA().

    ARGUMENTS:
      nEigPerron = number of eigenvalues close to 1 (int)
    """

    # get left eigenvectors
    eigVecs = self.microMSM.getRightEigSolution(self.nStates)[1]

    # by default eigenvectors column vectors, switch to row vectors for convenience
    eigVecs = transpose(eigVecs)

    # build macrostates 
    # start with one large macrostate and split self.nStates-1=nEigPerron times
    for curNumMacro in range(1, self.nStates):
      # find macrostate with largest spread in left eigenvector.
      # will split this one.
      # ignore first eigenvector since corresponds to equilibrium distribution
      maxSpread = -1         # max spread seen
      maxSpreadState = -1    # state with max spread
      for currState in range(curNumMacro):
        # find spread in components of eigenvector corresponding to current state
        myComponents = eigVecs[curNumMacro][(self.mapMicroToMacro==currState).flatten()]
        maxComponent = max(myComponents)
        minComponent = min(myComponents)
        spread = maxComponent - minComponent

        # store if this is max spread seen so far
        if spread > maxSpread:
          maxSpread = spread
          maxSpreadState = currState

      # split the macrostate with the greatest spread.
      # microstates corresponding to components of macrostate eigenvector
      # greater than mean go in new
      # macrostate, rest stay in current macrostate
      meanComponent = mean(eigVecs[curNumMacro][(self.mapMicroToMacro==maxSpreadState).flatten()])
      newMacrostateIndices = (eigVecs[curNumMacro] >= meanComponent)*(self.mapMicroToMacro==maxSpreadState)
      self.mapMicroToMacro[newMacrostateIndices] = curNumMacro

  def PCCA_Simplex(self, nEigPerron, doMinimization=True):
    """Do PCCA clustering using the simplex method.  Should only be called by PCCA().

    ARGUMENTS:
      nEigPerron = number of eigenvalues close to 1 (int)
      doMinimization = whether or not to do minimization (bool)
    """

    # just want right eigenvectors corresponding to Perron clusters
    (eigVals, eigVecs) = self.microMSM.getRightEigSolution(nEigPerron+1)

    # by default eigenvectors column vectors, switch to row vectors for convenience
#    eigVecs = transpose(eigVecs)

    # get invariant density
    pi=self.microMSM.getStationaryDist()

    # number eigenvectors
    nEigVecs = shape(eigVecs)[1]

    # pi orthogonalization
    for i in range(nEigVecs):
      denom = dot(transpose(eigVecs[:,nEigVecs-1]*pi), eigVecs[:,nEigVecs-1])
      denom = sqrt(denom)
      denom *= sign(eigVecs[0,nEigVecs-1])
      eigVecs[:,nEigVecs-1] = eigVecs[:,nEigVecs-1] / denom

    maxScale = 0.0
    maxInd=0
    for i in range(nEigVecs):
      scale = sum(pi * eigVecs[:,i])
      if abs(scale) > maxScale:
        maxScale = abs(scale)
        maxInd = i
    eigVecs[:,maxInd] = eigVecs[:,0]
    eigVecs[:,0] = 1
    eigVecs[where(pi<=0)[0],:] = 0

    for i in range(1,nEigVecs):
      for j in range(i-1):
        scale = dot(transpose(eigVecs[:,j]*pi), eigVecs[:,i])
        eigVecs[:,i] -= scale*eigVecs[:,j]
      sumVal = sqrt(dot(transpose(eigVecs[:,i]*pi), eigVecs[:,i]))
      eigVecs[:,i] /= sumVal

    # find representative microstate for each vertex of simplex (cluster)
    repMicroState = self.findSimplexVertices(nEigPerron+1, eigVecs)

    # get initial guess for transformatin matrix A
    A = eigVecs[repMicroState,:]
    A = inv(A)
    normA = norm(A[1:nEigVecs, 1:nEigVecs])

    # check what min of chi is before optimize
    minChi = (dot(eigVecs,A)).min()
    print " Before optimize, chi.min = %f" % minChi

    # get flattened representation of A
    alpha = zeros([(nEigVecs-1)*(nEigVecs-1)])
    for i in range(nEigVecs-1):
      for j in range(nEigVecs-1):
        alpha[j + i*(nEigVecs-1)] = A[i+1,j+1]

    # do optimization
    from scipy.optimize import fmin
    initVal = -self.objectiveFunc(alpha, eigVecs, pi, normA)
    print " Initial value of objective function: %f" % initVal
    if doMinimization:
      alpha = fmin(self.objectiveFunc, alpha, args=(eigVecs, pi, normA), maxiter=1e6, maxfun=1e6)
    else:
      print " Skipping Minimization Step"

    # get A back from alpha
    for i in range(nEigVecs-1):
      for j in range(nEigVecs-1):
        A[i+1,j+1] = alpha[j + i*(nEigVecs-1)]

    # fill in missing values in A
    A[1:nEigVecs,0] = -sum(A[1:nEigVecs,1:nEigVecs], 1)
    for j in range(nEigVecs):
      A[0,j] = -dot(eigVecs[0,1:nEigVecs], A[1:nEigVecs,j])
      for l in range(1,self.microMSM.nStates):
        dummy = -dot(eigVecs[l,1:nEigVecs], A[1:nEigVecs,j])
        if dummy > A[0,j]:
          A[0,j] = dummy
    A /= sum(A[0,:])

    # find chi matrix, membership matrix giving something like probability that each microstate belongs to each vertex/macrostate.
    # say like probability because may get negative numbers and don't necessarily sum to 1 due imperfect simplex structure.
    # rows are microstates, columns are macrostates
    self.chi = dot(eigVecs, A)

    # print final values of things
    minChi = (dot(eigVecs,A)).min()
    print " At end, chi.min = %f" % minChi
    finalVal = -self.objectiveFunc(alpha, eigVecs, pi, normA)
    print " Final value of objective function: %f" % finalVal

    # find most probable mapping of all microstates to macrostates.
    self.mapMicroToMacro = argmax(self.chi,1)

  def objectiveFunc(self, alpha, eigVecs, pi, NORMA):
    # number eigenvectors
    nEigVecs = shape(eigVecs)[1]

    # get A back from alpha
    A = zeros([nEigVecs,nEigVecs])
    for i in range(nEigVecs-1):
      for j in range(nEigVecs-1):
        A[i+1,j+1] = alpha[j + i*(nEigVecs-1)]

    normA = norm(A[1:nEigVecs, 1:nEigVecs])

    # fill in missing values in A
    A[1:nEigVecs,0] = -sum(A[1:nEigVecs,1:nEigVecs], 1)
    for j in range(nEigVecs):
      A[0,j] = -dot(eigVecs[0,1:nEigVecs], A[1:nEigVecs,j])
      for l in range(1,self.microMSM.nStates):
        dummy = -dot(eigVecs[l,1:nEigVecs], A[1:nEigVecs,j])
        if dummy > A[0,j]:
          A[0,j] = dummy
    A /= sum(A[0,:])

    # optimizing trace(S)
    optval = trace(dot(dot(diag(1/A[0,:]), transpose(A)), A))
    optval = -(optval - (NORMA-normA)*(NORMA-normA))

    return optval

  def findSimplexVertices(self, nClusters, eigVecs):
    """Find the vertices of the simplex structure.  Do this by finding vectors that are as close as possible to orthogonal.

    ARGUMENTS:
      nClusters = number of Perron clusters (int)
      eigVecs = first nCluster eigenvectors (matrix of floats).  That is, eigenvectors corresponding to Perron clusters

    RETRUN: list mapping between simplex vertices and represnetative microstates (microstate that lies exactly on vertex) (array of ints).
    """

    # initialize mapping between simplex verices and microstates
    mapVertToMicro = zeros([nClusters], int32)

    # copy of eigVecs that will use/modify to find orthogonal vectors
    orthoSys = eigVecs.copy()

    # find the first vertex, the eigenvector with the greatest norm (or length).
    # this will be the first of our basis vectors
    maxNorm = 0
    for i in range(size(eigVecs,0)):
      dist = norm(eigVecs[i,:])
      if dist > maxNorm:
        maxNorm = dist
        mapVertToMicro[0] = i

    # reduce every row of orthoSys by eigenvector of first vertex.
    # do this so can find vectors orthogonal to it
    for i in range(size(eigVecs,0)):
      orthoSys[i,:] = orthoSys[i,:]-eigVecs[mapVertToMicro[0],:]

    # find remaining vertices with Gram-Schmidt orthogonalization
    for k in range(1,nClusters):
      maxDist = 0

      # get previous vector of orthogonal basis set
      temp = orthoSys[mapVertToMicro[k-1],:].copy()

      # find vector in orthoSys that is most different from temp
      for i in range(size(eigVecs,0)):
        # remove basis vector just found (temp) so can find next orthogonal one
        orthoSys[i,:] = orthoSys[i,:]-dot(dot(orthoSys[i,:], transpose(temp)),temp)
        dist = norm(orthoSys[i,:])
        if dist > maxDist:
          maxDist = dist
          mapVertToMicro[k] = i

      orthoSys = orthoSys/maxDist

    return mapVertToMicro

  def SA(self, nIter, maxQ):
    """Do Simulated Annealing (SA) on assignment of microstates to macrostates for nIter iterations to try and get maximum metastability.

    ARGUMENTS:
      nIter = number of iterations to run simulated annealing for (int)

    RETURN: metastability (float)
    """

    # change transition matrices to faster format
    self.microMSM.tCount=self.microMSM.tCount.todok()
    self.microMSM.tProb=self.microMSM.tProb.todok()

    # best metastability seen so far and mapping that gave it
    currQ = maxQ
    bestMapping = self.mapMicroToMacro.copy()

    # do simulated annealing, temperature factor inversely proportional to step number.
    # equivalent to decreasing temperature at each step
    beta = 0
    while beta < nIter:
      # find a random microstate to move to a new macrostate
      while True:
        # choose a random microstate
        micro = random.randint(0,len(self.mapMicroToMacro)-1)

        # get original macrostate micro state is assigned to
        currMacro = self.mapMicroToMacro[micro]

        # if there's only one microstate in the macrostate selected then try again.
        # otherwise break out of loop
        if len(self.mapMicroToMacro[self.mapMicroToMacro==currMacro])==1:
          continue
        else:
          break

      # randomly choose a new macrostate to move the selected microstate to
      newMacro = random.randint(0, self.nStates-1)

      # repeat until get a new macrostate
      while newMacro == currMacro:
        newMacro = random.randint(0, self.nStates-1)

      # assign microstate to new macrostate
      self.mapMicroToMacro[micro] = newMacro

      # get new metastability and accept new assignment with Metropolis criteria
      # (minimizing -Q, which is equivalent to maximizing Q)
      self.updateTMat(micro, currMacro, newMacro)
      newQ = self.getQ()
      r = random.random()
      if r < min(1,exp(beta*(newQ-currQ))):
        currQ = newQ
      else: # reject move, return to previous mapping
        self.mapMicroToMacro[micro] = currMacro
        self.updateTMat(micro, newMacro, currMacro)

      # if this is best metastability/mapping seen so far then store it
      if currQ > maxQ:
        maxQ = currQ
        bestMapping = self.mapMicroToMacro.copy()

      beta += 1

    # set mapping to best one seen so far
    self.mapMicroToMacro = bestMapping.copy()

    # return to original format
    self.microMSM.tCount=self.microMSM.tCount.tolil()
    self.microMSM.tProb=self.microMSM.tProb.tolil()

    return maxQ

  def updateTMat(self, mMove, oldMacro, newMacro):
    """Update the transition count/probability matrices to reflect moving a microstate from one macrostate to another.

    ARGUMENTS:
      mMove = index of the microstate that is being moved (int)
      oldMacro = index of the macrostate mMove was in before (int)
      newMacro = index of the macrostate mMove is being moved to (int)
    """

    # moving a microstate from one macrostate to another effectively moves
    # all the transition counts for that microstate to the new macrostate.
    # loop over all microstates moving transition counts from old macrostate 
    # to new one
    microrowindices=array(self.microMSM.tCount[mMove,:].nonzero()[1],dtype='int')
    microcolindices=array(self.microMSM.tCount[:,mMove].nonzero()[0],dtype='int')

    # update elements on diagonal
    self.tCount[oldMacro,oldMacro]-=self.microMSM.tCount[mMove,mMove]
    self.tCount[newMacro,newMacro]+=self.microMSM.tCount[mMove,mMove]

    # avoid double counting?
    myMacro=self.mapMicroToMacro[mMove]
    self.tCount[oldMacro, myMacro]+=self.microMSM.tCount[mMove,mMove]
    self.tCount[newMacro,myMacro]-=self.microMSM.tCount[mMove,mMove]
    self.tCount[myMacro,oldMacro]+=self.microMSM.tCount[mMove,mMove]
    self.tCount[myMacro,newMacro]-=self.microMSM.tCount[mMove,mMove]

    for micro in microrowindices:
      myMacro=self.mapMicroToMacro[micro]
      self.tCount[oldMacro, myMacro]-=self.microMSM.tCount[mMove,micro]
      self.tCount[newMacro,myMacro] +=self.microMSM.tCount[mMove,micro]
    for micro in microcolindices:
      myMacro=self.mapMicroToMacro[micro]
      self.tCount[myMacro,oldMacro] -=self.microMSM.tCount[micro,mMove]
      self.tCount[myMacro,newMacro] +=self.microMSM.tCount[micro,mMove]

    self.updateTProb()

  def getPopulationStats(self, trajListFn, nIterBootstrap=10, nSamples=100):
    """Use bootstrapping to get the mean and standard deviation of the population of each macrostate.
    Assumes you've used assign_macro to assign each snapshot to the appropriate micro and macro state.

    ARGUMENTS:
      trajListFn = file listing trajectories to choose from (string)
      nIterBootstrap = number of different subsamples to draw for bootstrapping (int)
      nSamples = number of trajectories to include in each subsample

    RETURN: tuple where first element is vector of mean population of each macrostate, second element is vector of standard deviation in population of each macrostate.
    """

    # store the populations from each iteration of bootstrapping
    populations = zeros([nIterBootstrap, self.nStates], float64)

    # get trajectory list
    self.trajListFn = os.path.abspath(trajListFn)
    self.getAssignFileList()
    print "len " + str(len(self.trajList))

    for i in range(nIterBootstrap):
      print "Doing iteration %d of bootstrapping..." % i

      # create a new MacroMSM object with the same parameters as this one
      print self.nStates
      myMSM = MacroMSM(headDir=self.headDir, trajListFn=trajListFn, dt=self.dt, numMacro=self.nStates, lagTime=self.lagTime, nMicroStates=self.nMicroStates)

      # set the trajectory list to a subsampling of this objects trajectory list
      myMSM.trajList = self.getSubSampleTrajData(nSamples)

      # get the transition matrix and stationary distribution
      myMSM.getTransitionMatrix(subsample=True)
      populations[i] = myMSM.getStationaryDist()

    # store mean and standard deviation of populations
    print "Calculating statistics and print to file populations.dat"
    meanPop = mean(populations, 0)
    meanPop = meanPop / sum(meanPop) # normalize
    stdPop = std(populations, 0)

    # print to file
    f = open("populations.dat", 'w')
    for i in range(self.nStates):
      line = "%f %f" % (meanPop[i], stdPop[i])
      f.write(line + "\n")
    f.close()

    return (meanPop, stdPop)

  def determineMicroMSMPerronClusterEigenvalues(self, n):
    """Used for determining the number of eigenvalues in the PerronCluster of the MicroMSM.  That is, the number of eigenvalues that are almost 1.

   ARGUMENTS:
     n = number of eigenavlues to get (int)
   """

    # initialize microMSM if not done already
    if self.microMSM == None:
      self.microMSM = MicroMSM.MicroMSM(headDir=self.headDir, trajListFn=self.trajListFn, dt=self.dt, nMicroStates=self.nMicroStates)
      self.microMSM.lagTime = self.lagTime
      self.microMSM.trajList = self.trajList
      self.microMSM.getTransitionMatrix()

    # get eigenvalues of microMSM
    self.microMSM.determinePerronClusterEigenvalues(n)

  def printTransitionMatrices(self, outDir=""):
    """Print the transition count matrix and transition probability matrices to files.

    ARGUMENTS:
      outDir = directory to write files to (string)
    """

    tCountFn = os.path.join(outDir, "tCount.macro.dat")
    tProbFn = os.path.join(outDir, "tProb.macro.dat")
    savetxt(tCountFn, self.tCount)
    savetxt(tProbFn, self.tProb)

  def rightMultiplyVec(self,x,A):
    """Multiple Matrices for dense matrix
    """

    return dot(x,A)

  def initializeMatrices(self):
    """ Allocate and Zero tProb, tCount, and totalCount.  Different for Macro and Micro MSMs, because Micro MSMs are stored as sparse LIL matrices.
    """

    self.tCount = zeros((self.nStates,self.nStates))
    self.tProb = zeros((self.nStates,self.nStates))
    self.totalCount = 0

  def getStateFromMap(self, assignArray):
    """Used to get the current state by applying a mapping from micro to macro states instead of reading the macro state definition directly from the second column of the assignments files.  This is done by replacing self.getState() with this function when a mapping exists.
    """

    return self.mapMicroToMacro[int(assignArray[0])]

  def getTransitionMatrix(self, subsample=False, useNoe=False, nIter=1e7, freqSample=1e4, doSymm=True):
    """Get the transition matrix.  Overloads the base classes method.  Added functionality is that this method
 will use a mapping from microstates to macrostates instead of reading macrostate assignments directly from the assignments files if a mapping is available.

    ARGUMENTS:
      subsample = If false use sliding window to count transitions, if true use every lagTime'th step (bool).
      useNoe = Determine whether or not to use Noe method to get transition probability matrix (bool).  If use
Noe is true then subsample should also be true in order to get accurate statistics.
      nIter = Number iteration Noe sampling to do, only matters if useNoe is true (int).
      freqSample = Frequency to store samples from Noe Markov chain, only matters if useNoe is true (int).  St
ores every freqSample'th step.
    """

    # if there is a mapping from micro to macro states then use it instead of reading the macrostate assignments directly from the assignments files
    if self.mapMicroToMacro != None:
      self.getState = self.getStateFromMap

    MSM.MSM.getTransitionMatrix(self, subsample=subsample, useNoe=useNoe, nIter=nIter, freqSample=freqSample, doSymm=doSymm)

