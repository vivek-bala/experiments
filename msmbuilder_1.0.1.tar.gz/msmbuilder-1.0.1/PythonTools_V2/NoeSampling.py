#=======================================================================================
# NoeSampling.py
#
# NoeSamplingObject class is used to sample from the posterior distribution of a 
# Reversible Stochastic Matrix. The Markov Chain Monte Carlo algorithm used is algorithm
# 2 in:
#
# Noe, F. "Probability Distributions of Molecular Observables computed from Markov 
# Models." J. Chem. Phys. January, 2008.
#
# The class can be used to infer a microstate transition probability matrix from count
# data, which obeys detailed balance and we can use in PCCA to obtain macrostates. 
# This is done in the class 'MacroNoeMSM'.
#
# The sampling function plots several convergence criteria, and others can be easily 
# added.
#
# Please reference
# GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble 
# simulations and Markov state models to identify conformational states.
#
# Written 8/6/08 by
# Sergio Bacallado <sergiobacallado@gmail.com>
# Pande Group
#
# Copyright (C) 2008  Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#  
#=======================================================================================
# TODO:
#=======================================================================================
# GLOBAL IMPORTS:
from numpy import *
from numpy.linalg import *
from numpy.random import *
import pickle
import sys
import string 
#=======================================================================================
# CHANGE LOG:
# 8/6/08 SB - Ready for general use.
# 9/3/08 GRB - added line in init to make sure no zero counts in self.t
# 1/8/09 GRB - made print to text files instead of using Gnuplot library
#=======================================================================================

class NoeSamplingObject:
	def __init__(self,countMatrix):
		"""Class for sampling from posterior distribution of Reversible Transition Matrix.

		ARGUMENTS:
			countMatrix = The matrix of transition counts (numpy array)
		"""

		self.tcount = countMatrix.astype(float64)
	
		# Symmetrize the count matrix
		# and normalize to obtain the max-likelihood estimate of the transition matrix.
		self.t = (self.tcount+transpose(self.tcount))/2
		# make sure no 0 entries, causes problem when calculate log likelihoods
		self.t[where(self.t == 0)] = 1
		self.t = transpose(divide(transpose(self.t),add.reduce(self.t,1)))

#		self.t_mean = self.t.copy()

		# Create a container for transition matrix samples. Turn this off if
		# you are dealing with large matrices.
		self.t_list = []		
		
		# This dictionary maps the observables whose distributions are needed
		# to the functions that compute them from the transition matrix.
		# If you want to add an observable, add an entry to the dictionary, and the
		# corresponding function.
		self.observables = {"Self transition probability of largest state": self.GetSelfProbMax, \
				"Self transition probability of smallest state": self.GetSelfProbMin, \
				"Largest eigenvalues": self.GetLargestEigvals, \
				"Equilibrium distribution": self.GetEquilibriumDist}
		self.results = dict()
		for key in self.observables:
			self.results[key] = []		

	def GetSelfProbMax(self):
		"""Return the self-transition probability of the most populated state.

		RETURN: self-transition probability of most likely state (float)
		"""
		maxState = argmax(self.pi)
		return [self.t[maxState][maxState]]

	def GetSelfProbMin(self):
		"""Return the self-transition probability of the least populated state.

		RETURN: self-transition probability of least likely state (float)
		"""
		minState = argmin(self.pi)
		return [self.t[minState][minState]]

	def GetEquilibriumDist(self):
		"""Return the equilibrium distribution of the system

		RETURN: equilibrium distribution of the system (numpy array)
		"""
		return self.pi.copy()

	def GetLargestEigvals(self):
		"""Return the three largest eigenvalues < 1.

		RETURN: three largest eigenvalues of transition matrix (numpy array)
		"""
		return -sort(-eigvals(self.t))[1:4]

	def pRevElementShift(self,i,j,delta):
		"""Return the acceptance probability for a reversible element shift step.

		RETURN: acceptance probability of a reversible element shift (float)
		"""
		# Simplify names to make equations readable
		T = self.t	
		C = self.tcount
		pi = self.pi
		# Compute acceptance probability
		prior = ((T[i,j]-delta)**2+(T[j,i]-delta*pi[i]/pi[j])**2)/(T[i,j]**2+T[j,i]**2)
		loglik = log((T[i,i]+delta)/(T[i,i]))*C[i,i]+log((T[i,j]-delta)/(T[i,j]))*C[i,j] 
		loglik += log((T[j,j]+delta*pi[i]/pi[j])/(T[j,j]))*C[j,j]+log((T[j,i]-delta*pi[i]/pi[j])/(T[j,i]))*C[j,i]
		return prior*exp(loglik)

	def pNodeShift(self,i,alpha):
		"""Return the acceptance probability for a node shift step.

		RETURN: acceptance probability of a node shift (float)
		"""
		# Simplify names to make equations readable
		T = self.t	
		C = self.tcount
		# Compute acceptance probability
		logp = log(alpha)*(len(T)-2+sum(C[i,:])-C[i,i])+log((1-alpha*(1-T[i,i]))/T[i,i])*C[i,i]
		return exp(logp)

	def UpdateResults(self):
		"""Append the array of results in the object with the observables for the current transition matrix."""
		for observable in self.results.keys():
			self.results[observable].append(self.observables[observable]())		
		
		self.t_list.append(self.t.copy())

	def MatrixChainAnalysis(self):
		"""Plot results from transition matrix sampling to study convergence.
	
		Plotting now means printing columns of data to text files.  There are pairs of columns where the first is the data and the second is the variance or error bars for that data.
		Each result is plotted in a different graph. Results can have multiple data ranges, as in the case
		of the three largest eigenvalues. Then, each range is plotted in a different color on the same
		graph.
		"""

		# plot each item in results
		for key in self.results.keys():
			# list of columns of data to print
			dataColumns = []   

			# get data
			result = matrix(self.results[key])
			if shape(self.results[key])[0]==1:
				result = transpose(result)

			print key
			print result

			# For each result
			for i in range(shape(result)[1]):
	
				# get teh data
				resShape = shape(result[:,i])

				# add values to data columns
				dataColumns.append([])
				for j in range(resShape[0]):
					dataColumns[i].append(result[j,i])

			# print data and variances to files
			datFn = key + ".dat"
			datF = open(datFn, 'w')
			varFn = key + " Var.dat"
			varF = open(varFn, 'w')
			nCol = len(dataColumns)
			nLine = len(dataColumns[0])
			i = 0
			while i < nLine:
				j = 0
				while j < nCol:
					datF.write(str(dataColumns[j][i]) + " ")
					varF.write(str(var(dataColumns[j][0:i])) + " ")
					j += 1
				datF.write("\n")
				varF.write("\n")
				i += 1
			datF.close()
			varF.close()

	def CheckReversibility(self,matrix,pi):
		"""Computes an RMSD for opposite fluxes in the matrix. 
			
		RETURN: RMSD (float)
		"""

		rmsd = 0
		for i in range(len(matrix)):
			for j in range(len(matrix)):
				if i==j:
					continue
				rmsd += (matrix[i,j]*pi[i]-matrix[j,i]*pi[j])**2
		rmsd = sqrt(rmsd/2)
		return rmsd

	def SampleMatrix(self,nsteps,recordInterval=1e4,analysis=1):
		"""Run the Markov Chain Monte Carlo algorithm.

		This function can be slow for matrices with hundreds of states. The rate-limiting
		step is probably recording the results, which involves eigenvalue computation.
		If convergence takes too much time, then make simulation longer and increase
		the 'recordInterval' parameter accordingly.

		ARGUMENTS:
			nsteps = total number of steps in MCMC simulation (int)
			recordInterval = determines every how many steps we record results (int)
			analysis = if 1, then MatrixChainAnalysis is performed (int)
		"""

		# Find equilibrium distribution
		EigSolution = eig(transpose(self.t))
		self.pi = EigSolution[1][:,argmax(EigSolution[0])]
		self.pi = self.pi/sum(self.pi)

		# Markov Chain Monte Carlo
		n = 0
		while n < nsteps:
			# Record results every recordInterval steps
			if n%recordInterval == 0:
				print "Updating results..."
				self.UpdateResults()
				print "Equilibrium distribution: ", self.results["Equilibrium distribution"][-1]
				print "Sum of equilibrium populations: ", sum(self.results["Equilibrium distribution"][-1])
				print "Transition matrix: ", self.t
				print "Reversible RMSD: ", self.CheckReversibility(self.t,self.pi)
				print "Test of equilibrium distribution: ", sum(dot(self.pi,self.t)-self.pi), "\n"

			# Make updates
			r1 , r2 = random(), random()
			if r1 > 0.5: 
				# Reversible element shift
				i,j = randint(0,len(self.t)) , randint(0,len(self.t))
				delta = uniform(max(-self.t[i,i],-self.pi[j]/self.pi[i]*self.t[j,j]),min(self.t[i,j],self.t[j,i]*self.pi[j]/self.pi[i]))
				if r2 <= self.pRevElementShift(i,j,delta):
					self.t[i,i] += delta
					self.t[i,j] += -delta
					self.t[j,j] += delta*self.pi[i]/self.pi[j]
					self.t[j,i] += -delta*self.pi[i]/self.pi[j]
			else: 
				# Node shift
				i = randint(0,len(self.t))
				alpha = uniform(0,1/(1-self.t[i,i]))
				if r2 <= self.pNodeShift(i,alpha):
#					pi_save = self.pi.copy()
#					t_save = self.t.copy()
					for j in range(len(self.t)):
						if j == i:
							continue
						self.t[i,j] = self.t[i,j]*alpha
						self.pi[j] = alpha*self.pi[j]/(self.pi[i]+alpha*(1-self.pi[i]))
					self.t[i,i] += 1-sum(self.t[i,:])
					self.pi[i] += 1-sum(self.pi)
#				if (self.pi<0.001).any():
#					print self.pi
#					self.pi = pi_save
#					self.t = t_save
			n += 1
	
		# Only do analysis if 'analysis' argument is 1 
		if analysis == 1:
			self.MatrixChainAnalysis()			

