# remove all H's and symetric atoms in side chains of proteins
#===============================================================================
# GetRandomConfsFromEachState.py
#
# Load a pickled MSM object and get a specified number of random 
# conformations from each state.  They will be deposited as gro files
# in the speciefied directory.
# If a state doesn't have enough conformations then all the available 
# conformations are turned into starting points.
# Works on both MacroMSMs and MicroMSMs.
# 
# Please reference
# GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble 
# simulations and Markov state models to identify conformational states.
#
# Written 11/20/08 by
# Gregory R. Bowman <gregoryrbowman@gmail.com>
# Biophysics Program, Stanford University
# Pande group
#
# Copyright (C) 2008  Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#===============================================================================
# TODO:
#===============================================================================
# GLOBAL IMPORTS:
import os
import os.path
import sys
from optparse import OptionParser
#===============================================================================
# LOCAL IMPORTS:
import license
#===============================================================================
# CHANGE LOG:
#===============================================================================

# define options
usage = "%prog [options]"
parser = OptionParser(usage=usage)
# gro file to parse
parser.add_option("-g", "--groFn", dest="groFn", action="store", type="string", help="Protein gro file to parse in order to create heavy atom index file without any symmetry issues.")
# index file name to output to
parser.add_option("-o", "--outFn", dest="outFn", action="store", type="string", help="File name to output index file to.")

# parse optionlicense.printLicense()
(options, args) = parser.parse_args()
print sys.argv

groFn = options.groFn
outFn = options.outFn

# dictionaries with residue types as keys and list of atoms to keep for given residue as entries
toKeepDict = {
"ALA": ["N", "CA", "CB", "C", "O"],
"CALA": ["N", "CA", "CB", "C", "O"],
"NALA": ["N", "CA", "CB", "C", "O"],
"ARG": ["N", "CA", "CB", "C", "O", "CG", "CD", "NE", "CZ"],
"CARG": ["N", "CA", "CB", "C", "O", "CG", "CD", "NE", "CZ"],
"NARG": ["N", "CA", "CB", "C", "O", "CG", "CD", "NE", "CZ"],
"ASN": ["N", "CA", "CB", "C", "O", "CG", "OD1", "ND2"],
"CASN": ["N", "CA", "CB", "C", "O", "CG", "OD1", "ND2"],
"NASN": ["N", "CA", "CB", "C", "O", "CG", "OD1", "ND2"],
"ASP": ["N", "CA", "CB", "C", "O", "CG"],
"CASP": ["N", "CA", "CB", "C", "O", "CG"],
"NASP": ["N", "CA", "CB", "C", "O", "CG"],
"CYS": ["N", "CA", "CB", "C", "O", "SG"],
"CCYS": ["N", "CA", "CB", "C", "O", "SG"],
"NCYS": ["N", "CA", "CB", "C", "O", "SG"],
"GLU": ["N", "CA", "CB", "C", "O", "CG", "CD"],
"CGLU": ["N", "CA", "CB", "C", "O", "CG", "CD"],
"NGLU": ["N", "CA", "CB", "C", "O", "CG", "CD"],
"GLN": ["N", "CA", "CB", "C", "O", "CG", "CD", "OE1", "NE2"],
"CGLN": ["N", "CA", "CB", "C", "O", "CG", "CD", "OE1", "NE2"],
"NGLN": ["N", "CA", "CB", "C", "O", "CG", "CD", "OE1", "NE2"],
"GLY": ["N", "CA", "C", "O"],
"CGLY": ["N", "CA", "C", "O"],
"NGLY": ["N", "CA", "C", "O"],
"HID": ["N", "CA", "CB", "C", "O", "CG", "ND1", "CE1", "NE2", "CD2"],
"CHID": ["N", "CA", "CB", "C", "O", "CG", "ND1", "CE1", "NE2", "CD2"],
"NHID": ["N", "CA", "CB", "C", "O", "CG", "ND1", "CE1", "NE2", "CD2"],
"HIE": ["N", "CA", "CB", "C", "O", "CG", "ND1", "CE1", "NE2", "CD2"],
"CHIE": ["N", "CA", "CB", "C", "O", "CG", "ND1", "CE1", "NE2", "CD2"],
"NHIE": ["N", "CA", "CB", "C", "O", "CG", "ND1", "CE1", "NE2", "CD2"],
"HIP": ["N", "CA", "CB", "C", "O", "CG", "ND1", "CE1", "NE2", "CD2"],
"CHIP": ["N", "CA", "CB", "C", "O", "CG", "ND1", "CE1", "NE2", "CD2"],
"NHIP": ["N", "CA", "CB", "C", "O", "CG", "ND1", "CE1", "NE2", "CD2"],
"ILE": ["N", "CA", "CB", "C", "O", "CG1", "CG2", "CD"],
"CILE": ["N", "CA", "CB", "C", "O", "CG1", "CG2", "CD"],
"NILE": ["N", "CA", "CB", "C", "O", "CG1", "CG2", "CD"],
"LEU": ["N", "CA", "CB", "C", "O", "CG"],
"CLEU": ["N", "CA", "CB", "C", "O", "CG"],
"NLEU": ["N", "CA", "CB", "C", "O", "CG"],
"LYP": ["N", "CA", "CB", "C", "O", "CG", "CD", "CE", "NZ"],
"CLYP": ["N", "CA", "CB", "C", "O", "CG", "CD", "CE", "NZ"],
"NLYP": ["N", "CA", "CB", "C", "O", "CG", "CD", "CE", "NZ"],
"MET": ["N", "CA", "CB", "C", "O", "CG", "SD", "CE"],
"CMET": ["N", "CA", "CB", "C", "O", "CG", "SD", "CE"],
"NMET": ["N", "CA", "CB", "C", "O", "CG", "SD", "CE"],
"PHE": ["N", "CA", "CB", "C", "O", "CG", "CZ"],
"CPHE": ["N", "CA", "CB", "C", "O", "CG", "CZ"],
"NPHE": ["N", "CA", "CB", "C", "O", "CG", "CZ"],
"PRO": ["N", "CA", "CB", "C", "O", "CD", "CG"],
"CPRO": ["N", "CA", "CB", "C", "O", "CD", "CG"],
"NPRO": ["N", "CA", "CB", "C", "O", "CD", "CG"],
"SER": ["N", "CA", "CB", "C", "O", "OG"],
"CSER": ["N", "CA", "CB", "C", "O", "OG"],
"NSER": ["N", "CA", "CB", "C", "O", "OG"],
"THR": ["N", "CA", "CB", "C", "O", "CG2", "OG1"],
"CTHR": ["N", "CA", "CB", "C", "O", "CG2", "OG1"],
"NTHR": ["N", "CA", "CB", "C", "O", "CG2", "OG1"],
"TRP": ["N", "CA", "CB", "C", "O", "CG", "CD1", "NE1", "CE2", "CZ2", "CH2", "CZ3", "CE3", "CD2"],
"CTRP": ["N", "CA", "CB", "C", "O", "CG", "CD1", "NE1", "CE2", "CZ2", "CH2", "CZ3", "CE3", "CD2"],
"NTRP": ["N", "CA", "CB", "C", "O", "CG", "CD1", "NE1", "CE2", "CZ2", "CH2", "CZ3", "CE3", "CD2"],
"TYR": ["N", "CA", "CB", "C", "O", "CG", "CZ", "OH"],
"CTYR": ["N", "CA", "CB", "C", "O", "CG", "CZ", "OH"],
"NTYR": ["N", "CA", "CB", "C", "O", "CG", "CZ", "OH"],
"VAL": ["N", "CA", "CB", "C", "O"],
"CVAL": ["N", "CA", "CB", "C", "O"],
"NVAL": ["N", "CA", "CB", "C", "O"],
"NLE": ["N", "CA", "CB", "C", "O", "CG", "CD", "CE"],
"CNLE": ["N", "CA", "CB", "C", "O", "CG", "CD", "CE"],
"NNLE": ["N", "CA", "CB", "C", "O", "CG", "CD", "CE"]
}

# read gro file
f = open(groFn, 'r')
groLines = f.readlines()
f.close()

# iterate over lines of gro file and create index file
f = open(outFn, 'w')
f.write("[ System ]\n")
for line in groLines:
  if len(line) < 60: continue

  res = line[5:10].strip()
  atom = line[10:15].strip()
  atomNum = line[15:20].strip()

  if res.isdigit():
    continue

  if atom in toKeepDict[res]:
    f.write("%s " % atomNum)
f.write("\n")
f.close()



