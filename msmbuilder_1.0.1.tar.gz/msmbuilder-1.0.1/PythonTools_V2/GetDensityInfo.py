#===============================================================================
# GetDensityInfo.py
#
# Read in the stats.dat file and group all the micro states into one file per 
# macro state ordered from highest to lowest density.
#
# Please reference
# GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble 
# simulations and Markov state models to identify conformational states.
# 
# Written 11/27/08 by
# Gregory R. Bowman <gregoryrbowman@gmail.com>
# Biophysics Program, Stanford University
# Pande group
#
# Copyright (C) 2008  Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#===============================================================================
# TODO:
#===============================================================================
# GLOBAL IMPORTS:
import cPickle
from optparse import OptionParser
import os
import os.path
import shutil
import sys
#===============================================================================
# LOCAL IMPORTS:
import license
#===============================================================================
# CHANGE LOG:
#===============================================================================

# define options
usage = "%prog [options]"
parser = OptionParser(usage=usage)
# head directory where all the clustering data is
parser.add_option("-d", "--head_dir", dest="headDir", action="store", type="string", default=".", help="Head direectory containing the assignments and trajectories directories. [default: .]")
# mapping of micro to macro states
parser.add_option("-m", "--mapMicroToMacroFn", dest="mapMicroToMacroFn", action="store", type="string", help="(required) File listing mapping of micro states to macro states.")
# directory to write output to
parser.add_option("-o", "--outputDir", dest="outDir", action="store", type="string", default="StateCenters", help="Directory name to put output into. [default: StateCenters]")

# parse option
license.printLicense()
(options, args) = parser.parse_args()
print sys.argv

# check have all necessary arguments
if options.mapMicroToMacroFn == None:
  print "ERROR: must specify the mapping from microstates to macrostates."
  sys.exit(1)

# function to be used for sorting
def mySortFunc(g1, g2):
  x = int(float(g1[1]))
  y = int(float(g2[1]))
  return y-x

# read in mapping
mapMicroToMacro = []
f = open(options.mapMicroToMacroFn, 'r')
for line in f:
  line = line.strip()
  mapMicroToMacro.append(int(line))
f.close()
# macro states are numbered from 0 to n, so n+1 of them in total
numMacro = max(mapMicroToMacro)+1 

# setup output directories.
# gro files will be organized into one directory per macro state
outDir = options.outDir
if os.path.exists(outDir):
  print "WARNING: %s already exists." % outDir
else:
  os.mkdir(outDir)

# read in stats on generators and make sure agrees with mapping
statsFn = os.path.join(options.headDir, "stats.dat")
f = open(statsFn, 'r')
lines = f.readlines()
f.close()
if(len(lines) != len(mapMicroToMacro)):
  print "ERROR: the length of mapMicroToMacro doesn't match the number of generators."
  sys.exit(1)

# sort stats by macro state
microListPerMacro = []
macro = 0
while macro < numMacro:
  microListPerMacro.append([])
  macro += 1
micro = 0
while micro < len(lines):
  (pop, maxRmsd, aveRmsd, minRmsd) = lines[micro].strip().split()
  macro = mapMicroToMacro[micro]
  microListPerMacro[macro].append((micro, pop, maxRmsd, aveRmsd, minRmsd))

  micro += 1

# sort all the lists and print to files
macro = 0
while macro < numMacro:
  microListPerMacro[macro].sort(mySortFunc)

  # print to file
  fn = os.path.join(outDir, "macro%d.listMicros.dat" % macro)
  f = open(fn, 'w')
  for entry in microListPerMacro[macro]:
    line = "%s %s %s %s %s\n" % (entry[0], entry[1], entry[2], entry[3], entry[4])
    f.write(line)
  f.close()

  macro += 1


