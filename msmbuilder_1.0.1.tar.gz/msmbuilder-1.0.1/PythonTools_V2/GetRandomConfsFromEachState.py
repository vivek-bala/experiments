#===============================================================================
# GetRandomConfsFromEachState.py
#
# Get a specified number of random 
# conformations from each state.  They will be deposited as gro files
# in the speciefied directory.
# If a state doesn't have enough conformations then all the available 
# conformations are turned into starting points.
# Works on both MacroMSMs and MicroMSMs.
# 
# Please reference
# GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble 
# simulations and Markov state models to identify conformational states.
#
# Written 11/20/08 by
# Gregory R. Bowman <gregoryrbowman@gmail.com>
# Biophysics Program, Stanford University
# Pande group
#
# Copyright (C) 2008  Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#===============================================================================
# TODO:
#===============================================================================
# GLOBAL IMPORTS:
import cPickle
from optparse import OptionParser
import os
import os.path
import sys
#===============================================================================
# LOCAL IMPORTS:
import license
import MacroMSM
import MicroMSM
#===============================================================================
# CHANGE LOG:
# 01/30/09 GRB - No longer have to read in MSM.
#===============================================================================

# define options
usage = "%prog [options]"
parser = OptionParser(usage=usage)
# head directory where all the clustering data is
parser.add_option("-d", "--head_dir", dest="headDir", action="store", type="string", help="Head direectory containing the assignments and trajectories directories.  This option is required unless you read in an existing MSM with the -r option.")
# filename where trajectory filename list is
parser.add_option("-f", "--traj_list", dest="trajListFn", action="store", type="string", help="Filename of trajectory list.  This option is required unless you read in an existing MSM with the -r option.")
# number of microstates
parser.add_option("-i", "--numMicroStates", dest="nMicroStates", action="store", type="int", help="Number of microstaes.  This option is required unless you read in an existing MSM with the -r option.")
# time per xtc file
parser.add_option("-l", "--timePerXtc", dest="timePerXtc", action="store", type="int", help="(required) Time that elapses over course of each xtc file in ps.")
# number of macrostates
parser.add_option("-m", "--num_macro", dest="numMacro", action="store", type="int", help="Number of macrostates.")
# number of random confs to get from each state
parser.add_option("-n", "--numConfs", dest="numConfs", action="store", type="int", default=10, help="Number of random conformations to choose from each state. [default: 10]")
# directory to write output to
parser.add_option("-o", "--outputDir", dest="outDir", action="store", type="string", default="RandomConfs", help="Directory name to put output into. [default: RandomConfs]")
# state to get confs for 
parser.add_option("-s", "--state", dest="state", action="store", type="int", help="State index (numbering from 0) to get random conformations from.")
# tpr file
parser.add_option("-t", "--tprFn", dest="tprFn", action="store", type="string", help="(required) Path to tpr file.")
# ndx file
parser.add_option("-x", "--ndxFn", dest="ndxFn", action="store", type="string", help="(required) Path to index (.ndx) file.")
# number of ps between snapshot
parser.add_option("-z", "--time_step", dest="dt", action="store", type="float", help="(required) Time in ps between entries in the assignment files.")

# parse option
license.printLicense()
(options, args) = parser.parse_args()
print sys.argv

# print usage and exit if don't provide pickled file as arg
if options.timePerXtc == None:
  print "ERROR: must specify the time that elapses over the course of each xtc file in ps."
  sys.exit(1)
if (options.headDir==None or options.trajListFn==None or options.nMicroStates==None):
  print "ERROR: must specify the head directory, trajlist file, and number of microstates necessary to build one."
  sys.exit(1)
if options.tprFn == None:
  print "ERROR: must specify the tpr file."
  sys.exit(1)
if options.ndxFn == None:
  print "ERROR: must specify the ndx file."
  sys.exit(1)
if options.dt == None:
  print "ERROR: must specify the timestep"
  sys.exit(1)

myMsm = None
# if have number macrostates build new macro msm object
if options.numMacro != None:
  myMsm = MacroMSM.MacroMSM(headDir=options.headDir, trajListFn=options.trajListFn, numMacro=options.numMacro, nMicroStates=options.nMicroStates, dt=options.dt)
# otherwise make new micro msm object
else:
  myMsm = MicroMSM.MicroMSM(headDir=options.headDir, trajListFn=options.trajListFn, nMicroStates=options.nMicroStates)
  myMsm.dt = options.dt

# determine whether use macro or micro states
#if(options.useMacro):
#  myMsm.col = 1
#else:
#  myMsm.col = 0

# set MSM vars
if options.headDir != None:
  myMsm.headDir = options.headDir
if options.trajListFn != None:
  myMsm.trajListFn = os.path.abspath(options.trajListFn)
myMsm.getAssignFileList()

# get random confs
myMsm.getRandomConfs(N=options.numConfs, timePerXtc=options.timePerXtc, tprFn=options.tprFn, ndxFn=options.ndxFn, outDir=options.outDir, singleState=options.state)

