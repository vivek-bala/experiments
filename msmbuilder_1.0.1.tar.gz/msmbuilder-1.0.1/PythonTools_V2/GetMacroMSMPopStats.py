#===============================================================================
# GetMacroMSMPopStats.py
#
# Get statistics (mean and standard deviation) on the population of each state.
#
# Please reference
# GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble 
# simulations and Markov state models to identify conformational states.
#
# Written 7/29/07 by
# Gregory R. Bowman <gregoryrbowman@gmail.com>
# Pande group
#
# Copyright (C) 2008  Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#===============================================================================
# TODO:
#===============================================================================
# GLOBAL IMPORTS:
import cPickle
from optparse import OptionParser
import os
import os.path
import sys
#===============================================================================
# LOCAL IMPORTS:
import license
import MacroMSM
#===============================================================================
# CHANGE LOG:
# 07/30/08 GRB - Ready for general use
#===============================================================================

# define options
usage = "%prog [options]"
parser = OptionParser(usage=usage)
# number separate botstrapping samples to draw
parser.add_option("-b", "--numBootstraps", dest="nIterBootstrap", action="store", type="int", default=10, help="Number of iterations of bootstrapping to do. [default: 10]")
# head directory where all the clustering data is
parser.add_option("-d", "--head_dir", dest="headDir", action="store", type="string", help="Head direectory containing the assignments and trajectories directories.  This option is required unless you read in an existing MSM with the -r option or just want statistics on a microstate msm.")
# filename where trajectory filename list is
parser.add_option("-f", "--traj_list", dest="trajListFn", action="store", type="string", help="Filename of trajectory list.  This option is required unless you read in an existing MSM with the -r option or just want statistics on a microstate msm.")
# lag time to use
parser.add_option("-l", "--lag_time", dest="lagTime", action="store", type="int", help="Lag time in number of entries in the assignment files to use for the model.  If this option is not specified then the value used to build the MSM will be used.")
# number of macrostates                                                                                       
parser.add_option("-m", "--num_macro", dest="numMacro", action="store", type="int", help="Number of macrostates.")
# number trajectories per bootstrapping sample
parser.add_option("-n", "--numSamples", dest="nSamples", action="store", type="int", help="(required) Number of trajectories to include in each iteration of bootstrapping.  The number of trajectories listed in the trajlist file is generally a good choice.")
# number of microstates
parser.add_option("-s", "--numMicroStates", dest="nMicroStates", action="store", type="int", help="Number of microstaes.  This option is required unless you read in an existing MSM with the -r option.")
# number of ps between snapshot                                                                               
parser.add_option("-t", "--time_step", dest="dt", action="store", type="float", help="Time in ps between entries in the assignment files.  This option is required unless you read in an existing MSM with the -r option.")  
# parse option
license.printLicense()
(options, args) = parser.parse_args()
print sys.argv

# print usage and exit if don't provide pickled file as arg
if options.nSamples == None:
  print "ERROR: must specify the number of samples per iteration of bootstrapping."
  sys.exit(1)
if (options.headDir==None or options.trajListFn==None or options.nMicroStates==None or options.dt==None):
  print "ERROR: must specify the head directory, trajlist file, number of microstates, and time step necessary to build one."
  sys.exit(1)

myMsm = None
# if have number macrostates build new macro msm object
if options.numMacro != None:
  myMsm = MacroMSM.MacroMSM(headDir=options.headDir, trajListFn=options.trajListFn, dt=options.dt, lagTime=options.lagTime, numMacro=options.numMacro, nMicroStates=options.nMicroStates)
# otherwise make new micro msm object
else:
  myMsm = MicroMSM.MicroMSM(headDir=options.headDir, trajListFn=options.trajListFn, dt=options.dt, nMicroStates=options.nMicroStates)
  myMsm.lagTime = options.lagTime

# set the head directory
if options.headDir != None:
  myMsm.headDir = options.headDir

# set lag time if specified
if options.lagTime != None:
  myMsm.lagTime = options.lagTime

# get trajectory list
if options.trajListFn != None:
  myMsm.trajListFn = os.path.abspath(options.trajListFn)

# get population stats
myMsm.getPopulationStats(options.trajListFn, nIterBootstrap=options.nIterBootstrap, nSamples=options.nSamples)

