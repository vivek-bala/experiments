#===============================================================================
# MSM.py
#
# Base class for the MacroMSM and MicroMSM classes.  Should not be instantiated itself.
#
# Please reference
# GR Bowman, X Huang, and VS Pande. Methods 2009. Using generalized ensemble 
# simulations and Markov state models to identify conformational states.
#
# Written 11/18/08 by
# Gregory R. Bowman <gregoryrbowman@gmail.com>
# Sergio Bacallado <sergiobacallado@gmail.com>
# Xuhui Huang <xuhuihuang@gmail.com>
# Pande group
#
# Copyright (C) 2008  Stanford University
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#===============================================================================
# TODO:
#===============================================================================
# GLOBAL IMPORTS:
import math
from numpy import *
from numpy.linalg import *
import os
import os.path
import random
import sys
from scipy.io import mmwrite
import time
# try to import scipy sparse methods correctly, accounting for different namespaces in different version
from types import ModuleType
def importSparseEig():
	try:
		import scipy.sparse.linalg
		if isinstance(scipy.sparse.linalg.eigen, ModuleType):
			raise ImportError
		sparseEigen = scipy.sparse.linalg.eigen
	except:
		pass
	else:
		return sparseEigen

	try:
		import scipy.sparse.linalg.eigen.arpack as arpack
                sparseEigen = arpack.eigen
	except:
		pass
	else:
		return sparseEigen

	try:
		import scipy.sparse.linalg.eigen
		sparseEigen = scipy.sparse.linalg.eigen.eigs
	except:
		pass
	else:
		return sparseEigen

	raise ImportError
sparseEigen = importSparseEig()
from scipy import savetxt
import scipy.sparse
#===============================================================================
# LOCAL IMPORTS:
import NoeSampling
#===============================================================================
# CHANGE LOG:
# 01/16/09 GRB and KB - added in sparse matrix methods from scipy
# 01/23/09 GRB - reqrote buildModelsAsVaryLagTime so does bootstrapping
# 03/24/09 GRB - merged in sparse matrix code from Kyle Beauchamp
#===============================================================================

class MSM:
  def __init__():
    # directory relative to head dir where assignment files are
    self.assignDir = "assignments"

    # column of assignment file to use. Generally col=0 for the micro state assignment and col=1 for the macro state assignment.
    self.col = 0

    # time in ps lapsed between entries in the assignments files
    self.dt = None

    # lag time in number of entries in assignment file (int).
    self.lagTime = None

    # store results from Noe transition matrix sampling alg
    self.noeResults = None

    # number of states
    self.nStates = 0

    # head directory where all the clustering data is
    self.headDir = "."

    # list of implied timescales
    self.tau = []

    # transition count and probability matrices
    self.tCount = None
    self.tProb = None

    # file listing all the assignment files to be used
    self.trajListFn = ""

    # list of all the assignment files to be used
    self.trajList = []

  def getAssignFileList(self):
    """Read in the trajlist file to get list of files containing trajectory asignments.
    """

    print "Getting list of trajectory assignment files from " + self.trajListFn + "..."

    self.trajList = []

    # read trajlist file and get assignment file names
    f = open(self.trajListFn, 'r')
    for line in f:
      trajAssignName = line.strip()
      if trajAssignName == "": continue
      trajAssignName = os.path.join(self.headDir, self.assignDir, trajAssignName)
      if os.path.exists(trajAssignName):
        self.trajList.append(trajAssignName)
    f.close()

    print "#trajectories: " + str(len(self.trajList))

  def getTransitionMatrix(self, subsample=False, useNoe=False, nIter=1e7, freqSample=1e4, doSymm=True):
    """Get the transition matrix.

    ARGUMENTS:
      subsample = If false use sliding window to count transitions, if true use every lagTime'th step (bool).
      useNoe = Determine whether or not to use Noe method to get transition probability matrix (bool).  If useNoe is true then subsample should also be true in order to get accurate statistics.
      nIter = Number iteration Noe sampling to do, only matters if useNoe is true (int).
      freqSample = Frequency to store samples from Noe Markov chain, only matters if useNoe is true (int).  Stores every freqSample'th step.
    """

    # error checking
    if useNoe and not subsample:
      print "If using Noe code should subsample data, setting subsample to True."
      subsample = True

    # initialize transition matrices
    self.initializeMatrices()

    # read assignment files to determine transition count matrix
    for trajFileName in self.trajList:
      # skip if file doesn't exist
      if not os.path.exists(trajFileName):
        continue

      # read file
      f = open(trajFileName, 'r')
      assignments = f.readlines()
      f.close()

      # get transition counts for given lag time
      trajLen = len(assignments)
      i = 0
      while i < trajLen-self.lagTime:
        origState = self.getState(assignments[i].strip().split())
        newState = self.getState(assignments[i+self.lagTime].strip().split())

        # state will be -1 if using ST flags in hierarchical clustering and temperature not in desired range.
        # this has no effect if not using ST
        if origState<0 or newState<0:
          # move to next window.
          # if subsample is true then move forward lagTime steps.
          # otherwise move forward one step (sliding window).
          if subsample:
            i += self.lagTime
          else:
            i += 1
          continue

        # make sure don't exceed number of states
        if origState>=self.nStates or newState>=self.nStates:
          print "ERROR: found a state outside of the specified range!"
          sys.exit(1)

        # add count
        self.tCount[origState,newState] += 1
        self.totalCount += 1

        # move to next window.
        # if subsample is true then move forward lagTime steps.
        # otherwise move forward one step (sliding window).
        if subsample:
          i += self.lagTime
        else:
          i += 1

    # try drop things with too few counts
#    self.weights = add.reduce(self.tCount, 1) # weight is sum of a row, equivalent to number of counts in given state
#    lowInds = where(self.weights < 20)[0]
#    self.tCount[:,lowInds] = 0
#    self.tCount[lowInds,:] = 0

    if useNoe:
      self.printTransitionMatrices()
      # use Noe sampling to get transition probability matrix
      noeObject = NoeSampling.NoeSamplingObject(self.tCount)
      noeObject.SampleMatrix(nIter,freqSample,analysis=1)

      # store results for use elesewhere
      self.noeResults = noeObject.results

      # get transition probability matrix.
      # get list of transition matrices, leaving off first element since likely unprobable and take average
      tList = noeObject.t_list[1:]
      self.tProb = mean(tList, 0)  # get sum
    else:
      # determine the deviation from reversibility (or symmetry of count matrix)
      d = abs(self.tCount - self.tCount.transpose()).sum() / 2.0
      print " Deviation from reversibility/symmetry: %f" % (float(d)/self.totalCount)

      if doSymm:
        # Symmetrize count matrix (optional)
        self.tCount = (self.tCount+self.tCount.transpose())/2

      # reweight to get transition probability matrix
      self.tProb = self.tCount.copy()
      self.weights =  array(self.tCount.sum(axis=1)).flatten()
      # adjust weights for low counts
      self.weights[self.weights==0] = 1

      # normalize to get tProb
      indices = array(self.tProb.nonzero()).transpose()
      for ind in indices:
        self.tProb[ind[0],ind[1]] /= self.weights[ind[0]]

  def getState(self, assignArray):
    """Given an array representation of a line from an assignment file, return the current state.
    """

    return int(assignArray[self.col])

  def printTransitionMatrices(self, outDir=""):
    """Print the transition count matrix and transition probability matrices to files.

    ARGUMENTS:
      outDir = directory to write files to (string)
    """

    print "This method is not implemented and should not be called; instead, call MicroMSM or MacroMSM's printTransitionMatrices"

  def getLeftEigSolution(self, n):
    """Get largest n eigenvalues and left eigenvectors of transition probability matrix reordered so eigenvalues are from largest to smallest (eigenvectors reordered to match eigenvalues).

    ARGUMENTS:
      n = number of eigenvalues/vectors to get (int)

    RETRUN: tuple where first part is eigenvalues and second part is eigenvectors. (tuple)
    """

    isSparse = scipy.sparse.issparse(self.tProb)

    if n > self.nStates:
      print "ERROR: There are only %d states and, thereofre, only %d eigenvalues.  Getting %d eigenvalues is impossible." % (self.nStates, self.nStates, n)
      sys.exit(1)
    if isSparse and n ==1:
      print "Shouldn't request a single eigenvalue/vector, there is a bug in scipy that will soon be fixed."
      sys.exit(1)

    eigSolution = None

    # Left eigenvectors are right eighvectors of the transpose matrix.
    if isSparse:
      eigSolution = sparseEigen(self.tProb.transpose().tocsr(), n, which="LR")
    else:
      eigSolution = eig(self.tProb.transpose())

    # reorder by eigenvalu (from largest to smallest) and only keep first n
    eigSolution = (eigSolution[0][(-eigSolution[0]).argsort()][0:n], eigSolution[1][:,(-eigSolution[0]).argsort()][:,0:n])

    return eigSolution

  def getRightEigSolution(self, n):
    """Get largest eigenvalues and right eigenvectors of transition probability matrix reordered so eigenvalues are from largest to smallest (eigenvectors reordered to match eigenvalues).

    ARGUMENTS:
      n = number of eigenvalues/vectors to get (int)

    RETRUN: tuple where first part is eigenvalues and second part is eigenvectors. (tuple)
    """

    isSparse = scipy.sparse.issparse(self.tProb)

    if n > self.nStates:
      print "ERROR: There are only %d states and, thereofre, only %d eigenvalues.  Getting %d eigenvalues is impossible." % (self.nStates, self.nStates, n)
      sys.exit(1)
    if isSparse and n ==1:
      print "Shouldn't request a single eigenvalue/vector, there is a bug in scipy that will soon be fixed."
      sys.exit(1)

    eigSolution = None

    if isSparse:
      eigSolution = sparseEigen(self.tProb.tocsr(), n, which="LR")
    else:
      eigSolution = eig(self.tProb)

    # reorder by eigenvalu (from largest to smallest) and only keep first n
    eigSolution = (eigSolution[0][(-eigSolution[0]).argsort()][0:n], eigSolution[1][:,(-eigSolution[0]).argsort()][:,0:n])

    return eigSolution

  def impliedTimescales(self, n=1):
    """Get the longest n timescales between states.  Assumes already have transition matrices.

    Note: still need to add a part to match the eigenvectors

    ARGUMENTS:
      n = number of largest timescales to get (int)
    """

    eigValues = self.getRightEigSolution(n)[0]

    # init timescale vector
    self.tau = zeros((1,len(eigValues)-1))

    # get timescales.
    # skip first eigenvalues.  Corresponds to equilibrium distribution so its stationary and
    # causes errors in implied timescale calculation since equal to 1
    for i in range(1, len(eigValues)):
      if eigValues[i]>0:
        self.tau[0][i-1] = (-self.lagTime/log(eigValues[i]))*self.dt
      else:
        print "WARNING: have eigenvalue that's less than or equal to 0"

  def readAssignments(self):
    """Read assignments files and store in arrays.  Used for picking random conformations from each
 state.

    RETURN: list of arrays of assignments for each trajectory
    """

    # list for storing arrays of state assignments
    assignList = []

    # read assignment files.
    for trajFileName in self.trajList:
      # skip if file doesn't exist
      if not os.path.exists(trajFileName):
        continue

      # read file
      f = open(trajFileName, 'r')
      assignments = f.readlines()
      f.close()

      # get assignments
      trajLen = len(assignments)
      trajAssign = zeros([trajLen], int32)
      i = 0
      while i < trajLen:
        state = int(assignments[i].strip().split()[self.col])

        # store state to trajectory
        trajAssign[i] = state

        i += 1

      # store trajectory to matrix of assignments
      assignList.append(trajAssign.copy())

    return assignList

  def getRandomConfs(self, N=20, timePerXtc=None, trjconvExec="$MSMBUILDERHOME/Extras/trjconv/trjconv", tprFn="topol.tpr", ndxFn="index.ndx", outDir=".", singleState=None, filetype=".gro"):
    """Get N randomly selected conformations from each state.  Name them run0.gro to runX.gro where X=N*(number of states)-1.

    ARGUMENTS:
      N = Number of conformations to choose from each state (int).
      timePerXtc = length of each xtc file in ps (int)
      trjconvExec = trjconv executable (string).
      tprFn = path to tpr file (string).
      ndxFn = path to index file (string).  Should just have one group.
      outDir = Directory to write the celected conformations to (string).
      singleState = if None then get random confs from every state, otherwise just get random confs from specified state (int).
    """

    # get the state assignment for every trajectory
    assignments = self.readAssignments()

    # make a directory to put the starting confs in
    startConfDir = os.path.abspath(outDir)
    startConfDir = os.path.abspath(startConfDir)
    if not os.path.exists(startConfDir):
      os.mkdir(startConfDir)

    # get the number of trajectories
    numTraj = len(assignments)

    # get the list of trajectory filenames, will need this for finding xtc files
    f = open(self.trajListFn, 'r')
    trajListFileNames = f.readlines()
    f.close()

    # togles whether getting confs from all states or just one
    if singleState != None:
      startState = singleState
      finalState = singleState + 1
    else:
      startState = 0
      finalState = self.nStates

    # iterate over each state, picking N random conformations from each
    currConfNum = 0  # configuration currently generating
    for state in range(startState, finalState):
      print "Getting random conformations from state %d" % state

      # get indices of snapshots in given state
      trajAndSnapshotTuples = []   # list of tuples (trajectory index, snapshot index)
      trajInd = 0
      # loop over trajectories
      while trajInd < numTraj:
        # get indices where in given states
        indices = where(assignments[trajInd] == state)[0]

        # if list is empty move on to next trajectory
        if len(indices) == 0:
          trajInd += 1
          continue

        # convert indices to list of tuples of (trajInd, snapshot)
        # and concatenate to result
        tuples = map(self.makeTuple, trajInd*ones([len(indices)], int32), indices)
        map(trajAndSnapshotTuples.append, tuples)

        trajInd += 1

      # determine number of snapshots to pick.
      # basically, if there are at least N snapshots then pick N of them,
      # otherwise pick all of them
      nSnapshotsPick = min(len(trajAndSnapshotTuples), N)
      if nSnapshotsPick < N:
        print "WARNING: there were only %d snapshots in state %d, so only choosing %d starting conformations." % (nSnapshotsPick, state, nSnapshotsPick)

      # choose random snapshots
      trajAndSnapshotTuples = random.sample(trajAndSnapshotTuples, nSnapshotsPick)

      # create gro file for each one
      for tuple in trajAndSnapshotTuples:
        # make sure things are integers
        trajInd = int(tuple[0])
        snapshotInd = int(tuple[1])
        trajTime = snapshotInd * self.dt

        # get output gro file name
        outputGroFn = os.path.join(startConfDir, "run" + str(currConfNum) + filetype)

        # find xtc file snapshot is in.
        # first get trajectory file name it's in
        trajFn = os.path.join(self.headDir, "trajectories", trajListFileNames[trajInd].strip())
        trajFn = os.path.abspath(trajFn)

        # get list of xtc files corresponding to this trajectory
        f = open(trajFn, 'r')
        xtcFileNames = f.readlines()
        f.close()

        # find xtc file this snapshot is in
        xtcInd = int(math.floor(float(trajTime)/timePerXtc))
        xtcFn = xtcFileNames[xtcInd].strip()
        xtcFn = os.path.join(self.headDir, xtcFn)
        xtcFn = os.path.abspath(xtcFn)

        # find time (in ps) of this snapshot relative to this xtc file
#        time = int(trajTime % timePerXtc)
        time = int(trajTime)

        # get absolute paths to tpr and ndx files
        tprFn = os.path.abspath(tprFn)
        ndxFn = os.path.abspath(ndxFn)

        # generate new gro file
        cmd = trjconvExec
        cmd += " -f %s -o %s -s %s -n %s" % (xtcFn, outputGroFn, tprFn, ndxFn)
        cmd += " -dump %d" % time
#        cmd += " -dumpN %d" % (float(time)/timePerXtc * 500)
        print cmd
        os.system(cmd)

        # move on to next starting conformation
        currConfNum += 1

  def makeTuple(self, x, y):
    """Returns a tuple (x,y).  Used by getRandomConfs.

    ARGUMENTS:
      x, y = items to pair together in tuple

    RETURN: tuple (x,y)
    """

    return (x, y)

  def buildModelsAsVaryLagTime(self, lagTimes=[1], nEig=100, nBootstrap=0):
    """Build models for a range of lag times.  Useful for determining the  appropriate number of macro states and lag time to use for a Markov model.

    ARGUMENTS:
      lagTimes = list of lag times to build models for (list of floats)
      nEig = number of largest timescales to get for each model (int)
      nBootstrap = number of iterations of bootstrapping to do (int)
    """

    origTrajList = list(self.trajList)
    nTraj = len(origTrajList)

    # build model for each lag time and get implied timescales
    for lagT in lagTimes:

      # build n models
      impliedTimes = None
      if nBootstrap > 0:
        impliedTimes = zeros([nBootstrap, nEig-1], float64)
        for i in range(nBootstrap):
          print "Building model with lag time of %f entries" % lagT
          self.lagTime = lagT
          self.trajList = self.getSubSampleTrajData(nTraj) 

          self.getTransitionMatrix()
          self.impliedTimescales(nEig)
          impliedTimes[i] = self.tau.copy()

          # reset trajlist for next run
          self.trajList = list(origTrajList)

      else:
          impliedTimes = zeros([1, nEig-1], float64)
          print "Building model with lag time of %f entries" % lagT
          self.lagTime = lagT
          self.getTransitionMatrix()
          self.impliedTimescales(nEig)
          impliedTimes[0] = self.tau.copy()

      # get mean and std
      meanImpliedTimes = mean(impliedTimes, 0)
      stdImpliedTimes = std(impliedTimes, 0)

      # print to file
      fn = "lag." + str(lagT) + ".tau.dat"
      f = open(fn, 'w')
      for i in range(nEig-1):
        line = "%d %f %f\n" %(lagT*self.dt, meanImpliedTimes[i], stdImpliedTimes[i])
        f.write(line)
      f.close()

  def getQ(self):
    """Get the metastability.

    RETURN: metastability (float)
    """

    return self.tProb.diagonal().sum()

  def determinePerronClusterEigenvalues(self, n):
    """Used for determining the number of eigenvalues in the PerronCluster.  That is, the number of eigenvalues that are almost 1.

   ARGUMENTS:
     n = number of eigenavlues to get (int)
   """

    # get n eigenvalues, or as many as possible if matrix smaller than 50 by 50
    if n > self.nStates:
      print "There are only %d states, getting %d eigenvalues." % (self.nStates, self.nStates)
      n = self.nStates

    eigSolution = self.getRightEigSolution(n)
    print "The %d largest eigenvalues are:" % n
    print eigSolution[0]

    #print out all the eigenvalues
    feig = open('eigenvalues.dat','w')
    for ie in range(len(eigSolution[0])):
      line = "%d %5.3f\n" %(ie, sort(eigSolution[0])[-(ie+1)])
      feig.write(line)
    feig.close()

  def getSubSampleTrajData(self, N):
    """ Returns a list of N random trajectories (with repeats) drawn from trajList.

    ARGUMENTS:
      N = number of trajectories to choose (int)

    RETURN: list of trajectory names chosen
    """

    subSample = []
    i = 0
    # choose N random trajectories and append to subSample
    while i < N:
      subSample.append(random.choice(self.trajList))
      i += 1

    return subSample

  def getStationaryDist(self):
    """Get the stationary distribution of the transition probability matrix.
    """

    # get first left eigenvector and normalize.
  # Bug in Scipy.arpack.eigen when k = 1 so we get 3 eigenvectors/values for now.  This workaround will eventually be fixed by a newer version of scpiy.
    temp = self.getLeftEigSolution(3)
    firstEigVec = temp[1][:,0]
    firstEigVec /= sum(firstEigVec)

    return transpose(firstEigVec)

  def getPopStatsUsingNoeMethod(self, nIter=1e7, freqSample=1e4):
    """Use Noe method to get the mean and standard deviation of the population of each state.

    ARGUMENTS:
      nIter = Number iteration Noe sampling to do, only matters if useNoe is true (int).
      freqSample = Frequency to store samples from Noe Markov chain, only matters if useNoe is true (int).  Stores every freqSample'th step.

    RETURN: tuple where first element is vector of mean population of each state, second element is vector of standard deviation in population of each state.
    """

    # use Noe method to get transition probablity matrix and sample equlibrium distribution
    self.getAssignFileList()
    self.getTransitionMatrix(subsample=True, useNoe=True, nIter=nIter, freqSample=freqSample)

    # calculate mean and standard dev of equilibrium dist.
    # Get equilibrium distributions throughout run, leave out first point, and compute average/std.
    equilDistList = self.noeResults["Equilibrium distribution"][1:]
    print "num: " + str(len(equilDistList))
    meanPop = mean(equilDistList,0)
    meanPop = meanPop / sum(meanPop) # normalize
    print equilDistList
    stdPop = std(equilDistList,0)

    # print to file
    f = open("populations.dat", 'w')
    for i in range(self.nStates):
      line = "%f %f" % (meanPop[i], stdPop[i])
      f.write(line + "\n")
    f.close()

    return (meanPop, stdPop)

  def compareRawData(self, nSteps, observableFn=None):
    """Compare the evolution of the population of some set of states as a function of time from the raw data and the MSM.  The raw data is output to rawData.dat with each line containg "step# population_state0 population_stat1...".  The msm data is output to msmData.dat with the same format.

If the value of some observable for each state is specified in the observableFn file then the average from the msm may also be calculated.

This function equires that you've already calculated the transition probability matrix.

    ARGUMENTS:
      nSteps = number of steps of size lagTime to consider (int)
    """

    # get the state assignment for every trajectory
    assignments = self.readAssignments()

    # read in observable if specified
    observable = None
    if observableFn != None:
      observable = zeros([2,self.nStates])
      f = open(observableFn, 'r')
      i = 0
      while i < self.nStates:
        line = f.readline().strip().split()
        observable[0,i] = float(line[0])
        observable[1,i] = float(line[1])
        i += 1
      f.close()


    # get time series from raw data
    i = 0
#    f = open("rawData.dat", 'w')
    if observableFn != None:
      rawObserveF = open("rawObservableData.dat", 'w')
    while i < nSteps:
      # get position in traj from step number
      pos = i * self.lagTime

      # get probability each state at pos
      j = 0
      rawData = zeros(self.nStates)
      for j in range(len(assignments)):
        # check traj has data at pos, otherwise move on
        if len(assignments[j]) > pos:

          rawData[assignments[j][pos]] += 1

      # calculate probability of each state, avoiding divide by 0 errors.
      # concurrently print to file
      mySum = sum(rawData)
#      f.write("%f " % (i*self.lagTime))
      for j in range(self.nStates):
        if mySum > 0:
          rawData[j] = rawData[j] / mySum
#        f.write("%f " % rawData[j])
#      f.write("\n")

      # write average observable if specified
      if observableFn != None:
        obs = sum(rawData * observable[0])
        obsSquared = sum(rawData * observable[1])
        obsStandDev = sqrt(obsSquared - obs*obs)
        rawObserveF.write("%f " % (i*self.lagTime))
        rawObserveF.write("%f %f" % (obs, obsStandDev))
        rawObserveF.write("\n")

      i += 1
#    f.close()
    if observableFn != None:
      rawObserveF.close()

    # get initial state probability vector from first entry of each traj.
    # needed for getting populations at each time point from msm
    initStatePops = zeros(self.nStates)
    for j in range(len(assignments)):
      initStatePops[assignments[j][0]] += 1
    # normalize state populations
    print initStatePops
    totCount = sum(initStatePops)
    initStatePops /= totCount
    print "Initial state"
    print initStatePops

    # get prob each state at each step of size lagTime by multiplying by tProb
#    f = open("msmData.dat", 'w')
    if observableFn != None:
      msmObserveF = open("msmObservableData.dat", 'w')

    curStatePops=initStatePops.copy()
    for i in range(nSteps):
      print "Doing step %d" % i

      # calculate probability of each state
      # concurrently print to file
#      f.write("%f " % (i*self.lagTime))
#      for j in range(self.nStates):
#        f.write("%f " % curStatePops[j])
#      f.write("\n")

      # write average observable if specified
      if observableFn != None:
        obs = sum(curStatePops * observable[0])
        obsSquared = sum(curStatePops * observable[1])
        obsStandDev = sqrt(obsSquared - obs*obs)
        msmObserveF.write("%f " % (i*self.lagTime))
        msmObserveF.write("%f %f" % (obs, obsStandDev))
        msmObserveF.write("\n")

      # do next time step
      curStatePops=self.rightMultiplyVec(curStatePops,self.tProb)
      i += 1

#    f.close()
    if observableFn != None:
      msmObserveF.close()

    # print tProb to file
#    self.printTransitionMatrices()

